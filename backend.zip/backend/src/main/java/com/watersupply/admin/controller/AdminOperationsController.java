package com.watersupply.admin.controller;

import com.watersupply.admin.dto.ScheduleAssignmentDTO;
import com.watersupply.admin.service.BillingService;
import com.watersupply.admin.service.ScheduleAssignmentService;
import com.watersupply.common.dto.ApiResponse;
import com.watersupply.common.entity.DeliverySchedule;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CompletableFuture;
import java.util.Map;
import com.watersupply.common.entity.User;
import com.watersupply.admin.dto.SalaryPayoutRequest;
import com.watersupply.common.service.UserService;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000")
@org.springframework.security.access.prepost.PreAuthorize("hasRole('ADMIN')")
public class AdminOperationsController {

    @Autowired
    private ScheduleAssignmentService scheduleService;

    @Autowired
    private BillingService billingService;

    @Autowired
    private com.watersupply.common.service.NotificationService notificationService;

    @Autowired
    private UserService userService;

    @PostMapping("/schedules/assign")
    public ResponseEntity<ApiResponse<DeliverySchedule>> assignDelivery(
            @Valid @RequestBody ScheduleAssignmentDTO dto) {
        DeliverySchedule schedule = scheduleService.assignDelivery(dto);

        if (schedule.getOrder() != null && schedule.getOrder().getUser() != null) {
            notificationService.notifyUser(
                    schedule.getOrder().getUser(),
                    "Your Order #" + schedule.getOrder().getId() + " has been assigned to a delivery agent.",
                    "INFO",
                    "ORDER",
                    schedule.getOrder().getId());
        }

        return ResponseEntity.ok(ApiResponse.success("Delivery assigned successfully", schedule));
    }

    @PostMapping("/billing/generate")
    public ResponseEntity<ApiResponse<String>> generateBills(
            @RequestParam int month,
            @RequestParam int year) {
        CompletableFuture<String> future = billingService.generateMonthlyBills(month, year);
        return ResponseEntity.ok(ApiResponse.success(
                "Bill generation started in background",
                "Processing..."));
    }

    @Autowired
    private com.watersupply.admin.service.AdminDashboardService adminService;

    @PutMapping("/orders/{id}/status")
    public ResponseEntity<ApiResponse<Void>> updateOrderStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        adminService.updateOrderStatus(id, status);
        return ResponseEntity.ok(ApiResponse.success("Order status updated", null));
    }

    @PutMapping("/complaints/{id}/assign")
    public ResponseEntity<ApiResponse<Void>> assignComplaint(
            @PathVariable Long id,
            @RequestParam Long employeeId) {
        adminService.assignComplaint(id, employeeId);
        return ResponseEntity.ok(ApiResponse.success("Complaint assigned", null));
    }

    @PutMapping("/complaints/{id}/resolve")
    public ResponseEntity<ApiResponse<Void>> resolveComplaint(
            @PathVariable Long id,
            @RequestParam String notes) {
        adminService.resolveComplaint(id, notes);
        return ResponseEntity.ok(ApiResponse.success("Complaint resolved", null));
    }

    @PutMapping("/complaints/{id}/in-progress")
    public ResponseEntity<ApiResponse<Void>> markComplaintInProgress(
            @PathVariable Long id) {
        adminService.markComplaintInProgress(id);
        return ResponseEntity.ok(ApiResponse.success("Complaint marked as in progress", null));
    }

    @PostMapping("/complaints/{id}/message")
    public ResponseEntity<ApiResponse<Void>> sendMessageToUser(
            @PathVariable Long id,
            @RequestParam String message) {
        adminService.sendMessageToUser(id, message);
        return ResponseEntity.ok(ApiResponse.success("Message sent to user", null));
    }

    @PostMapping("/employees")
    public ResponseEntity<ApiResponse<com.watersupply.common.entity.User>> createEmployee(
            @Valid @RequestBody com.watersupply.common.dto.RegisterRequest request) {
        com.watersupply.common.entity.User employee = adminService.createEmployee(request);
        return ResponseEntity.ok(ApiResponse.success("Employee created successfully", employee));
    }

    @PutMapping("/employees/{id}")
    public ResponseEntity<ApiResponse<com.watersupply.common.entity.User>> updateEmployee(
            @PathVariable Long id,
            @Valid @RequestBody com.watersupply.common.dto.RegisterRequest request) {
        com.watersupply.common.entity.User employee = adminService.updateEmployee(id, request);
        return ResponseEntity.ok(ApiResponse.success("Employee updated successfully", employee));
    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteEmployee(@PathVariable Long id) {
        adminService.deleteEmployee(id);
        return ResponseEntity.ok(ApiResponse.success("Employee deactivated successfully", null));
    }

    @PostMapping("/users/{id}/deactivate")
    public ResponseEntity<?> deactivateUser(@PathVariable Long id) {
        userService.deactivateUser(id);
        return ResponseEntity.ok().body(Map.of("message", "User deactivated successfully"));
    }

    @GetMapping("/employees/{id}/unpaid-earnings")
    public ResponseEntity<?> getUnpaidEarnings(@PathVariable Long id) {
        return ResponseEntity.ok(adminService.getUnpaidEarnings(id));
    }

    @PostMapping("/employees/pay-salary")
    public ResponseEntity<?> paySalary(@RequestBody SalaryPayoutRequest request,
            jakarta.servlet.http.HttpServletRequest httpRequest) {
        Long adminId = (Long) httpRequest.getAttribute("userId");
        User admin = userService.findById(adminId);
        return ResponseEntity.ok(adminService.processSalaryPayout(request, admin));
    }
}
