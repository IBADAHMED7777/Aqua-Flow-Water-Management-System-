package com.watersupply.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsDTO {
    private long totalCustomers;
    private long totalEmployees;
    private long activeConnections;
    private long totalOrders;
    private double monthlyRevenue;
    private double yearlyRevenue;
    private double monthOverMonthGrowth;
    private ComplaintStatsDTO complaintStats;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ComplaintStatsDTO {
        private long open;
        private long inProgress;
        private long resolved;
    }
}
