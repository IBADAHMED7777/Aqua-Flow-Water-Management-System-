package com.watersupply.admin.controller;

import com.watersupply.admin.dto.DashboardStatsDTO;
import com.watersupply.admin.dto.RevenueTrendDTO;
import com.watersupply.admin.service.AdminDashboardService;
import com.watersupply.common.dto.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/dashboard")
@CrossOrigin(origins = "http://localhost:3000")
@org.springframework.security.access.prepost.PreAuthorize("hasRole('ADMIN')")
public class AdminDashboardController {

    @Autowired
    private AdminDashboardService dashboardService;

    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<DashboardStatsDTO>> getDashboardStats() {
        DashboardStatsDTO stats = dashboardService.getDashboardStats();
        return ResponseEntity.ok(ApiResponse.success("Dashboard stats retrieved", stats));
    }

    @GetMapping("/revenue-trend")
    public ResponseEntity<ApiResponse<List<RevenueTrendDTO>>> getRevenueTrend() {
        List<RevenueTrendDTO> trend = dashboardService.getRevenueTrend();
        return ResponseEntity.ok(ApiResponse.success("Revenue trend retrieved", trend));
    }

    @GetMapping("/activity-logs")
    public ResponseEntity<ApiResponse<List<com.watersupply.admin.entity.AdminActivityLog>>> getRecentActivityLogs() {
        List<com.watersupply.admin.entity.AdminActivityLog> logs = dashboardService.getRecentActivityLogs();
        return ResponseEntity.ok(ApiResponse.success("Activity logs retrieved", logs));
    }
}
