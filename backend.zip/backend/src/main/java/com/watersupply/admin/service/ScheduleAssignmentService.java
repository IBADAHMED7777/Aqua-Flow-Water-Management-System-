package com.watersupply.admin.service;

import com.watersupply.admin.dto.ScheduleAssignmentDTO;
import com.watersupply.common.entity.DeliverySchedule;
import com.watersupply.common.entity.Order;
import com.watersupply.common.entity.User;
import com.watersupply.common.exception.DataConflictException;
import com.watersupply.common.exception.ResourceNotFoundException;
import com.watersupply.common.exception.ValidationException;
import com.watersupply.common.repository.DeliveryScheduleRepository;
import com.watersupply.common.repository.OrderRepository;
import com.watersupply.common.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * Schedule assignment service with synchronized methods
 * Demonstrates: Synchronization, Exception Handling
 */
@Service
public class ScheduleAssignmentService {

    private static final Logger logger = LoggerFactory.getLogger(ScheduleAssignmentService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DeliveryScheduleRepository scheduleRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private com.watersupply.common.service.NotificationService notificationService;

    /**
     * Assign delivery to employee with synchronization to prevent conflicts
     * Synchronized to prevent double-assignment race conditions
     */
    @Transactional
    public synchronized DeliverySchedule assignDelivery(ScheduleAssignmentDTO dto) {
        logger.info("Assigning order {} to employee {}", dto.getOrderId(), dto.getEmployeeId());

        // Validate order exists and is in PLACED status
        Order order = orderRepository.findById(dto.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));

        if (order.getStatus() != Order.OrderStatus.PLACED) {
            throw new ValidationException("Order is not in PLACED status");
        }

        // Validate employee exists and has EMPLOYEE role
        User employee = userRepository.findById(dto.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        if (employee.getRole() != User.Role.EMPLOYEE) {
            throw new ValidationException("User is not an employee");
        }

        // Check if order is already assigned (prevent double assignment)
        if (order.getAssignedEmployee() != null) {
            throw new DataConflictException("Order is already assigned to another employee");
        }

        // Create delivery schedule
        DeliverySchedule schedule = new DeliverySchedule();
        schedule.setEmployee(employee);
        schedule.setOrder(order);
        schedule.setScheduledDate(dto.getScheduledDate());
        schedule.setRouteInformation(dto.getRouteInformation());
        schedule.setStatus(DeliverySchedule.ScheduleStatus.PENDING);

        scheduleRepository.save(schedule);

        // Update order status and assignment
        order.setStatus(Order.OrderStatus.ASSIGNED);
        order.setAssignedEmployee(employee);
        order.setAssignedAt(LocalDateTime.now());
        orderRepository.save(order);

        // Notify employee about the new schedule assignment
        notificationService.notifyUser(
                employee,
                "You have been assigned a new delivery schedule for Order #" + order.getId() + " on "
                        + dto.getScheduledDate(),
                "SCHEDULE_ASSIGNMENT",
                "SCHEDULE",
                schedule.getId());

        logger.info("Successfully assigned order {} to employee {}", order.getId(), employee.getEmail());
        return schedule;
    }
}
