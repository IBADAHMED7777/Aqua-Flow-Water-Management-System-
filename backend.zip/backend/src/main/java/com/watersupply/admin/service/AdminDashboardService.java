package com.watersupply.admin.service;

import com.watersupply.admin.dto.DashboardStatsDTO;
import com.watersupply.admin.dto.RevenueTrendDTO;
import com.watersupply.common.entity.Complaint;
import com.watersupply.common.entity.Order;
import com.watersupply.common.entity.User;
import com.watersupply.common.repository.BillRepository;
import com.watersupply.common.repository.ComplaintRepository;
import com.watersupply.common.repository.OrderRepository;
import com.watersupply.common.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class AdminDashboardService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ComplaintRepository complaintRepository;

    @Autowired
    private BillRepository billRepository;

    @Autowired
    private com.watersupply.admin.repository.AdminActivityLogRepository activityLogRepository;

    @Autowired
    private com.watersupply.admin.repository.NotificationRepository notificationRepository;

    @Autowired
    private com.watersupply.common.repository.EmployeeEarningsRepository earningsRepository;

    @Autowired
    private com.watersupply.common.repository.SalaryPaymentRepository salaryPaymentRepository;

    @Autowired
    private com.watersupply.common.service.PDFService pdfService;

    @Autowired
    private com.watersupply.common.service.NotificationService notificationService;

    /**
     * Get dashboard statistics
     * Returns immutable statistics snapshot
     */
    public DashboardStatsDTO getDashboardStats() {
        long totalCustomers = userRepository.countByRole(User.Role.USER);
        long totalEmployees = userRepository.countByRole(User.Role.EMPLOYEE);
        long activeConnections = orderRepository.countByStatus(Order.OrderStatus.PLACED) +
                orderRepository.countByStatus(Order.OrderStatus.ASSIGNED);

        long totalOrders = orderRepository.count();

        // Calculate revenues efficiently using DB queries
        double currentMonthRevenue = calculateCurrentMonthRevenue();
        double lastMonthRevenue = calculateLastMonthRevenue();
        double yearlyRevenue = calculateYearlyRevenue();
        double growth = lastMonthRevenue > 0 ? ((currentMonthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100 : 0;

        // Complaint statistics
        DashboardStatsDTO.ComplaintStatsDTO complaintStats = new DashboardStatsDTO.ComplaintStatsDTO(
                complaintRepository.countByStatus(Complaint.ComplaintStatus.OPEN),
                complaintRepository.countByStatus(Complaint.ComplaintStatus.IN_PROGRESS),
                complaintRepository.countByStatus(Complaint.ComplaintStatus.RESOLVED));

        return new DashboardStatsDTO(
                totalCustomers,
                totalEmployees,
                activeConnections,
                totalOrders,
                currentMonthRevenue,
                yearlyRevenue,
                growth,
                complaintStats);
    }

    /**
     * Get revenue trend for the last 6 months
     */
    public List<RevenueTrendDTO> getRevenueTrend() {
        List<RevenueTrendDTO> trend = new ArrayList<>();
        LocalDate now = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yyyy");

        for (int i = 5; i >= 0; i--) {
            LocalDate month = now.minusMonths(i);
            Double revenue = billRepository.calculateMonthlyRevenue(month.getMonthValue(), month.getYear());
            trend.add(new RevenueTrendDTO(month.format(formatter), revenue != null ? revenue : 0.0));
        }

        return trend;
    }

    public List<com.watersupply.admin.entity.AdminActivityLog> getRecentActivityLogs() {
        return activityLogRepository.findTop10ByOrderByTimestampDesc();
    }

    public void logActivity(Long adminId, String action, String entityType, String entityId, String details,
            String ipAddress) {
        User admin = userRepository.findById(adminId).orElseThrow(() -> new RuntimeException("Admin not found"));

        com.watersupply.admin.entity.AdminActivityLog log = new com.watersupply.admin.entity.AdminActivityLog();
        log.setAdmin(admin);
        log.setAction(action);
        log.setEntityType(entityType);
        log.setEntityId(entityId);
        log.setDetails(details);
        log.setIpAddress(ipAddress != null ? ipAddress : "N/A");

        activityLogRepository.save(log);
    }

    public org.springframework.data.domain.Page<User> getAllUsers(org.springframework.data.domain.Pageable pageable) {
        return userRepository.findByRole(User.Role.USER, pageable);
    }

    public org.springframework.data.domain.Page<User> getAllEmployees(
            org.springframework.data.domain.Pageable pageable) {
        return userRepository.findByRole(User.Role.EMPLOYEE, pageable);
    }

    public org.springframework.data.domain.Page<Order> getAllOrders(org.springframework.data.domain.Pageable pageable) {
        return orderRepository.findAll(pageable);
    }

    public org.springframework.data.domain.Page<Complaint> getAllComplaints(
            org.springframework.data.domain.Pageable pageable) {
        return complaintRepository.findAll(pageable);
    }

    public org.springframework.data.domain.Page<Complaint> getCustomerComplaints(
            org.springframework.data.domain.Pageable pageable) {
        // Customer complaints are those not assigned to any employee
        return complaintRepository.findByAssignedEmployeeIsNull(pageable);
    }

    public org.springframework.data.domain.Page<Complaint> getEmployeeComplaints(
            org.springframework.data.domain.Pageable pageable) {
        // Employee complaints are those assigned to an employee
        return complaintRepository.findByAssignedEmployeeIsNotNull(pageable);
    }

    public org.springframework.data.domain.Page<com.watersupply.common.entity.Bill> getAllBills(
            org.springframework.data.domain.Pageable pageable) {
        return billRepository.findAll(pageable);
    }

    public void updateOrderStatus(Long orderId, String status) {
        Order order = orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(Order.OrderStatus.valueOf(status));
        if ("DELIVERED".equals(status)) {
            order.setDeliveredAt(java.time.LocalDateTime.now());
        }
        orderRepository.save(order);
    }

    public void assignComplaint(Long complaintId, Long employeeId) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));
        User employee = userRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        complaint.setAssignedEmployee(employee);
        complaint.setStatus(Complaint.ComplaintStatus.IN_PROGRESS);
        complaint.setInProgressAt(java.time.LocalDateTime.now());
        complaintRepository.save(complaint);
    }

    public void resolveComplaint(Long complaintId, String resolutionNotes) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setStatus(Complaint.ComplaintStatus.RESOLVED);
        complaint.setResolutionNotes(resolutionNotes);
        complaint.setResolvedAt(java.time.LocalDateTime.now());
        complaintRepository.save(complaint);

        notificationService.notifyUser(
                complaint.getUser(),
                "Your complaint '" + complaint.getSubject() + "' has been RESOLVED. Notes: " + resolutionNotes,
                "SUCCESS",
                "COMPLAINT",
                complaint.getId());
    }

    public void markComplaintInProgress(Long complaintId) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setStatus(Complaint.ComplaintStatus.IN_PROGRESS);
        complaint.setInProgressAt(java.time.LocalDateTime.now());
        complaintRepository.save(complaint);
    }

    public void sendMessageToUser(Long complaintId, String message) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));

        complaint.setResolutionNotes(message); // Save the latest message as the admin reply
        complaintRepository.save(complaint);

        notificationService.notifyUser(
                complaint.getUser(),
                "New update on your complaint: " + message,
                "INFO",
                "COMPLAINT",
                complaint.getId());

        // Also log as activity
        User admin = userRepository.findByRole(User.Role.ADMIN, org.springframework.data.domain.PageRequest.of(0, 1))
                .getContent().get(0);
        logActivity(admin.getId(), "MESSAGE_SENT", "COMPLAINT", String.valueOf(complaintId),
                "Message to user: " + message, null);
    }

    @Autowired
    private org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

    public User createEmployee(com.watersupply.common.dto.RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode("Employee@123")); // Default password
        user.setPhone(request.getPhone());
        user.setRole(User.Role.EMPLOYEE);
        user.setActive(true);
        user.setPaymentRate(request.getPaymentRate() != null ? request.getPaymentRate() : 0.0);

        return userRepository.save(user);
    }

    public User updateEmployee(Long id, com.watersupply.common.dto.RegisterRequest request) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));

        user.setName(request.getName());
        user.setPhone(request.getPhone());
        if (request.getPaymentRate() != null) {
            user.setPaymentRate(request.getPaymentRate());
        }

        return userRepository.save(user);
    }

    public void deleteEmployee(Long id) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        user.setActive(false); // Soft delete
        userRepository.save(user);
    }

    private double calculateCurrentMonthRevenue() {
        LocalDate now = LocalDate.now();
        Double revenue = billRepository.calculateMonthlyRevenue(now.getMonthValue(), now.getYear());
        return revenue != null ? revenue : 0.0;
    }

    private double calculateLastMonthRevenue() {
        LocalDate lastMonth = LocalDate.now().minusMonths(1);
        Double revenue = billRepository.calculateMonthlyRevenue(lastMonth.getMonthValue(), lastMonth.getYear());
        return revenue != null ? revenue : 0.0;
    }

    private double calculateYearlyRevenue() {
        LocalDate now = LocalDate.now();
        Double revenue = billRepository.calculateYearlyRevenue(now.getYear());
        return revenue != null ? revenue : 0.0;
    }

    public List<com.watersupply.common.entity.EmployeeEarnings> getUnpaidEarnings(Long employeeId) {
        return earningsRepository.findByEmployeeIdAndPaidFalseOrderByEarnedAtAsc(employeeId);
    }

    @org.springframework.transaction.annotation.Transactional
    public com.watersupply.common.entity.SalaryPayment processSalaryPayout(
            com.watersupply.admin.dto.SalaryPayoutRequest request, User admin) {
        User employee = userRepository.findById(request.getEmployeeId())
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        List<com.watersupply.common.entity.EmployeeEarnings> earnings = earningsRepository
                .findAllById(request.getEarningIds());

        if (earnings.isEmpty()) {
            throw new RuntimeException("No earnings selected for payout");
        }

        double totalAmount = 0;
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        LocalDate start = LocalDate.MAX;
        LocalDate end = LocalDate.MIN;

        for (com.watersupply.common.entity.EmployeeEarnings earning : earnings) {
            if (earning.getPaid()) {
                throw new RuntimeException("Earning ID " + earning.getId() + " is already paid.");
            }
            if (!earning.getEmployee().getId().equals(employee.getId())) {
                throw new RuntimeException("Earning ID " + earning.getId() + " does not belong to this employee.");
            }
            totalAmount += earning.getEarningAmount();

            LocalDate earningDate = earning.getEarnedAt().toLocalDate();
            if (earningDate.isBefore(start))
                start = earningDate;
            if (earningDate.isAfter(end))
                end = earningDate;
        }

        com.watersupply.common.entity.SalaryPayment payment = new com.watersupply.common.entity.SalaryPayment();
        payment.setEmployee(employee);
        payment.setAmount(totalAmount);
        payment.setBasicSalary(request.getBasicSalary() != null ? request.getBasicSalary() : totalAmount);
        payment.setAllowances(request.getAllowances() != null ? request.getAllowances() : 0.0);
        payment.setDeductions(request.getDeductions() != null ? request.getDeductions() : 0.0);
        payment.setPaymentMethod(request.getPaymentMethod() != null ? request.getPaymentMethod() : "CASH");
        payment.setAuthorizedBy(admin);
        payment.setPaymentDate(now);
        payment.setPeriodStart(start);
        payment.setPeriodEnd(end);

        // Generate PDF
        try {
            byte[] pdfBytes = pdfService.generateSalarySlip(payment);
            String fileName = "salary_" + employee.getId() + "_" + System.currentTimeMillis() + ".pdf";
            payment.setPdfPath(fileName);
        } catch (java.io.IOException e) {
            throw new RuntimeException("Failed to generate PDF", e);
        }

        payment = salaryPaymentRepository.save(payment);

        for (com.watersupply.common.entity.EmployeeEarnings earning : earnings) {
            earning.setPaid(true);
            earning.setPaidAt(now);
            earning.setSalaryPayment(payment);
            earningsRepository.save(earning);
        }

        notificationService.notifyUser(
                employee,
                "Salary Payment of PKR " + payment.getAmount() + " has been processed.",
                "SALARY",
                "PAYMENT",
                payment.getId());

        return payment;
    }
}