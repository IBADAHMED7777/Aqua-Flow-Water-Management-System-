package com.watersupply.admin.service;

import com.watersupply.common.entity.Bill;
import com.watersupply.common.entity.User;
import com.watersupply.common.entity.WaterConsumption;
import com.watersupply.common.exception.ValidationException;
import com.watersupply.common.repository.BillRepository;
import com.watersupply.common.repository.UserRepository;
import com.watersupply.common.repository.WaterConsumptionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Billing service with multithreaded bill generation
 * Demonstrates: Multithreading, Exception Handling, Immutability
 */
@Service
public class BillingService {

    private static final Logger logger = LoggerFactory.getLogger(BillingService.class);
    private static final double RATE_PER_UNIT = 5.0; // PKR per unit

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BillRepository billRepository;

    @Autowired
    private WaterConsumptionRepository consumptionRepository;

    /**
     * Generate bills for all users asynchronously
     * Uses multithreading for performance
     */
    @Async("taskExecutor")
    public CompletableFuture<String> generateMonthlyBills(int month, int year) {
        logger.info("Starting bill generation for {}/{} in background thread", month, year);

        List<User> users = userRepository.findByRole(User.Role.USER);
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger errorCount = new AtomicInteger(0);

        // Process bills in parallel using streams
        users.parallelStream().forEach(user -> {
            try {
                generateBillForUser(user, month, year);
                successCount.incrementAndGet();
            } catch (Exception e) {
                logger.error("Error generating bill for user {}: {}", user.getEmail(), e.getMessage());
                errorCount.incrementAndGet();
            }
        });

        String result = String.format("Bill generation completed. Success: %d, Errors: %d",
                successCount.get(), errorCount.get());
        logger.info(result);

        return CompletableFuture.completedFuture(result);
    }

    /**
     * Generate bill for a single user
     * Creates immutable bill record
     */
    private void generateBillForUser(User user, int month, int year) {
        // Check if bill already exists
        if (billRepository.findByUserAndBillingMonthAndBillingYear(user, month, year).isPresent()) {
            throw new ValidationException("Bill already exists for this period");
        }

        // Calculate consumption for the month
        LocalDate startDate = LocalDate.of(year, month, 1);
        LocalDate endDate = startDate.plusMonths(1).minusDays(1);

        Double totalConsumption = consumptionRepository.sumConsumptionByUserAndDateRange(
                user, startDate, endDate);

        if (totalConsumption == null) {
            totalConsumption = 0.0;
        }

        // Create immutable bill
        Bill bill = new Bill();
        bill.setUser(user);
        bill.setBillingMonth(month);
        bill.setBillingYear(year);
        bill.setConsumptionAmount(totalConsumption);
        bill.setRatePerUnit(RATE_PER_UNIT);
        bill.setTotalAmount(totalConsumption * RATE_PER_UNIT);
        bill.setDueDate(LocalDate.of(year, month, 1).plusMonths(1).plusDays(15));
        bill.setPaid(false);
        bill.setImmutable(true); // Mark as immutable

        billRepository.save(bill);
        logger.info("Generated bill for user {} - Amount: PKR {}", user.getEmail(), bill.getTotalAmount());
    }
}
