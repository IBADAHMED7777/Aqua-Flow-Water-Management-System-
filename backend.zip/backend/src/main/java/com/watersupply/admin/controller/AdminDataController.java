package com.watersupply.admin.controller;

import com.watersupply.admin.service.AdminDashboardService;
import com.watersupply.common.dto.ApiResponse;
import com.watersupply.common.entity.Complaint;
import com.watersupply.common.entity.Order;
import com.watersupply.common.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000")
@PreAuthorize("hasRole('ADMIN')")
public class AdminDataController {

    @Autowired
    private AdminDashboardService adminService;

    @GetMapping("/users")
    public ResponseEntity<ApiResponse<Page<User>>> getUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sort,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sorting = Sort.by(Sort.Direction.fromString(direction), sort);
        Pageable pageable = PageRequest.of(page, size, sorting);
        return ResponseEntity.ok(ApiResponse.success("Users retrieved", adminService.getAllUsers(pageable)));
    }

    @GetMapping("/employees")
    public ResponseEntity<ApiResponse<Page<User>>> getEmployees(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by("name"));
        return ResponseEntity.ok(ApiResponse.success("Employees retrieved", adminService.getAllEmployees(pageable)));
    }

    @GetMapping("/orders")
    public ResponseEntity<ApiResponse<Page<Order>>> getOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "placedAt") String sort,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sorting = Sort.by(Sort.Direction.fromString(direction), sort);
        Pageable pageable = PageRequest.of(page, size, sorting);
        return ResponseEntity.ok(ApiResponse.success("Orders retrieved", adminService.getAllOrders(pageable)));
    }

    @GetMapping("/complaints")
    public ResponseEntity<ApiResponse<Page<Complaint>>> getComplaints(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sort,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sorting = Sort.by(Sort.Direction.fromString(direction), sort); // Assuming Complaint has createdAt, if not
                                                                            // check entity
        Pageable pageable = PageRequest.of(page, size, sorting);
        return ResponseEntity.ok(ApiResponse.success("Complaints retrieved", adminService.getAllComplaints(pageable)));
    }

    @GetMapping("/bills")
    public ResponseEntity<ApiResponse<Page<com.watersupply.common.entity.Bill>>> getBills(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueDate") String sort,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sorting = Sort.by(Sort.Direction.fromString(direction), sort);
        Pageable pageable = PageRequest.of(page, size, sorting);
        return ResponseEntity.ok(ApiResponse.success("Bills retrieved", adminService.getAllBills(pageable)));
    }

    @Autowired
    private com.watersupply.common.service.PDFService pdfService;

    @Autowired
    private com.watersupply.common.repository.BillRepository billRepository;

    @Autowired
    private com.watersupply.common.repository.OrderRepository orderRepository;

    @GetMapping("/bills/{id}/pdf")
    public ResponseEntity<byte[]> getBillPdf(@PathVariable Long id) {
        com.watersupply.common.entity.Bill bill = billRepository.findById(id)
                .orElseThrow(() -> new com.watersupply.common.exception.ResourceNotFoundException("Bill not found"));

        try {
            byte[] pdfBytes = pdfService.generateBillPdf(bill);
            return ResponseEntity.ok()
                    .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=bill_" + bill.getBillingMonth() + "_" + bill.getBillingYear()
                                    + ".pdf")
                    .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                    .body(pdfBytes);
        } catch (java.io.IOException e) {
            throw new RuntimeException("Failed to generate PDF", e);
        }
    }

    @GetMapping("/orders/{id}/invoice-pdf")
    public ResponseEntity<byte[]> getOrderInvoicePdf(@PathVariable Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new com.watersupply.common.exception.ResourceNotFoundException("Order not found"));

        try {
            byte[] pdfBytes = pdfService.generateOrderInvoice(order);
            return ResponseEntity.ok()
                    .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=invoice_" + order.getId() + ".pdf")
                    .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                    .body(pdfBytes);
        } catch (java.io.IOException e) {
            throw new RuntimeException("Failed to generate invoice PDF", e);
        }
    }

    @GetMapping("/complaints/customer")
    public ResponseEntity<ApiResponse<Page<Complaint>>> getCustomerComplaints(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sort,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sorting = Sort.by(Sort.Direction.fromString(direction), sort);
        Pageable pageable = PageRequest.of(page, size, sorting);
        return ResponseEntity.ok(ApiResponse.success("Customer complaints retrieved",
                adminService.getCustomerComplaints(pageable)));
    }

    @GetMapping("/complaints/employee")
    public ResponseEntity<ApiResponse<Page<Complaint>>> getEmployeeComplaints(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sort,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sorting = Sort.by(Sort.Direction.fromString(direction), sort);
        Pageable pageable = PageRequest.of(page, size, sorting);
        return ResponseEntity.ok(ApiResponse.success("Employee complaints retrieved",
                adminService.getEmployeeComplaints(pageable)));
    }
}