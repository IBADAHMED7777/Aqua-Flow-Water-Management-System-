package com.watersupply.admin.dto;

import lombok.Data;
import java.util.List;

@Data
public class SalaryPayoutRequest {
    private Long employeeId;
    private List<Long> earningIds;
    private Double basicSalary;
    private Double allowances;
    private Double deductions;
    private String paymentMethod;
}
