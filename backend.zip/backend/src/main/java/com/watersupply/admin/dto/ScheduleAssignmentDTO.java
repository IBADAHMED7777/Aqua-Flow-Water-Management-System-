package com.watersupply.admin.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleAssignmentDTO {

    @NotNull(message = "Order ID is required")
    private Long orderId;

    @NotNull(message = "Employee ID is required")
    private Long employeeId;

    @NotNull(message = "Scheduled date is required")
    private LocalDate scheduledDate;

    private String routeInformation;
}
