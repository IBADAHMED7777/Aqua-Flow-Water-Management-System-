package com.watersupply.user.service;

import com.watersupply.common.entity.Order;
import com.watersupply.common.entity.User;
import com.watersupply.common.exception.ResourceNotFoundException;
import com.watersupply.common.exception.ValidationException;
import com.watersupply.common.repository.OrderRepository;
import com.watersupply.common.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for managing user billing and payments
 */
@Service
public class UserBillingService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Get all orders (bills) for a user
     */
    public List<Order> getUserOrders(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return orderRepository.findByUserOrderByPlacedAtDesc(user);
    }

    /**
     * Get unpaid orders for a user
     */
    public List<Order> getUnpaidOrders(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return orderRepository.findByUserOrderByPlacedAtDesc(user).stream()
                .filter(order -> !order.getPaid() && order.getStatus() != Order.OrderStatus.CANCELLED)
                .toList();
    }

    /**
     * Mark an order as paid
     */
    @Transactional
    public Order payOrder(Long userId, Long orderId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));

        // Verify the order belongs to the user
        if (!order.getUser().getId().equals(userId)) {
            throw new ValidationException("Order does not belong to this user");
        }

        // Check if already paid
        if (order.getPaid()) {
            throw new ValidationException("Order is already paid");
        }

        order.setPaid(true);
        order.setPaidAt(LocalDateTime.now());

        return orderRepository.save(order);
    }

    /**
     * Get total unpaid amount for a user
     */
    public Double getTotalUnpaidAmount(Long userId) {
        return getUnpaidOrders(userId).stream()
                .mapToDouble(Order::getTotalAmount)
                .sum();
    }
}
