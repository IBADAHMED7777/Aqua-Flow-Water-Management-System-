package com.watersupply.user.service;

import com.watersupply.common.entity.Order;
import com.watersupply.common.entity.OrderItem;
import com.watersupply.common.entity.Product;
import com.watersupply.common.entity.User;
import com.watersupply.common.exception.ResourceNotFoundException;
import com.watersupply.common.exception.ValidationException;
import com.watersupply.common.repository.OrderRepository;
import com.watersupply.common.service.NotificationService;
import com.watersupply.common.repository.ProductRepository;
import com.watersupply.common.repository.UserRepository;
import com.watersupply.user.dto.CreateOrderDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * User order service
 * Demonstrates: Synchronization (stock updates), Exception Handling,
 * Immutability
 */
@Service
public class UserOrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Create order with synchronized stock updates
     */
    @Transactional
    public synchronized Order createOrder(Long userId, CreateOrderDTO dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Order order = new Order();
        order.setUser(user);
        order.setStatus(Order.OrderStatus.PLACED);

        // Handle Payment Method
        if (dto.getPaymentMethod() != null) {
            try {
                order.setPaymentMethod(Order.PaymentMethod.valueOf(dto.getPaymentMethod()));
            } catch (IllegalArgumentException e) {
                // Default or Error
                order.setPaymentMethod(Order.PaymentMethod.CASH_ON_DELIVERY);
            }
        } else {
            order.setPaymentMethod(Order.PaymentMethod.CASH_ON_DELIVERY);
        }

        // Online payment is paid immediately (mocked)
        if (order.getPaymentMethod() == Order.PaymentMethod.ONLINE_PAYMENT) {
            order.setPaid(true);
            order.setPaidAt(java.time.LocalDateTime.now());
        }

        double totalAmount = 0.0;

        for (CreateOrderDTO.OrderItemDTO itemDto : dto.getItems()) {
            Product product = productRepository.findById(itemDto.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found"));

            // Validate stock availability
            if (product.getStockQuantity() < itemDto.getQuantity()) {
                throw new ValidationException("Insufficient stock for product: " + product.getName());
            }

            // Create order item
            OrderItem item = new OrderItem();
            item.setProduct(product);
            item.setQuantity(itemDto.getQuantity());
            item.setUnitPrice(product.getPrice());
            item.setSubtotal(product.getPrice() * itemDto.getQuantity());

            order.addItem(item);
            totalAmount += item.getSubtotal();

            // Update stock (synchronized to prevent race conditions)
            product.setStockQuantity(product.getStockQuantity() - itemDto.getQuantity());
            productRepository.save(product);
        }

        order.setTotalAmount(totalAmount);

        // Create immutable order summary
        order.setOrderSummary(generateOrderSummary(order));

        if (dto.getAddress() != null && !dto.getAddress().isBlank()) {
            order.setDeliveryAddress(dto.getAddress());
        } else {
            order.setDeliveryAddress(user.getAddress());
        }

        order = orderRepository.save(order);

        notificationService.notifyAdmin(
                "New Order #" + order.getId() + " placed by " + user.getName(),
                "INFO",
                "ORDER",
                order.getId());

        return order;
    }

    private String generateOrderSummary(Order order) {
        StringBuilder summary = new StringBuilder();
        summary.append("Order Total: PKR ").append(order.getTotalAmount()).append("\n");
        summary.append("Items:\n");
        for (OrderItem item : order.getItems()) {
            summary.append("- ").append(item.getProduct().getName())
                    .append(" x").append(item.getQuantity())
                    .append(" = PKR ").append(item.getSubtotal()).append("\n");
        }
        return summary.toString();
    }

    /**
     * Cancel an order
     */
    @Transactional
    public synchronized Order cancelOrder(Long userId, Long orderId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));

        if (!order.getUser().getId().equals(user.getId())) {
            throw new ValidationException("Order does not belong to user");
        }

        if (order.getStatus() != Order.OrderStatus.PLACED) {
            throw new ValidationException("Only PLACED orders can be cancelled");
        }

        order.setStatus(Order.OrderStatus.CANCELLED);

        // Refund Logic (Mocked)
        if (order.getPaymentMethod() == Order.PaymentMethod.ONLINE_PAYMENT) {
            // Assume refund process is initiated here
            System.out.println("Processing refund for Order ID: " + orderId);
        }

        // Restore Stock
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            product.setStockQuantity(product.getStockQuantity() + item.getQuantity());
            productRepository.save(product);
        }

        return orderRepository.save(order);
    }
}
