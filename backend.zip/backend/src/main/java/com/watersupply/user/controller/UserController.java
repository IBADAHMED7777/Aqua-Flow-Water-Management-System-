package com.watersupply.user.controller;

import com.watersupply.common.dto.ApiResponse;
import com.watersupply.common.entity.Complaint;
import com.watersupply.common.entity.Order;
import com.watersupply.common.entity.Product;
import com.watersupply.common.entity.User;
import com.watersupply.common.repository.ComplaintRepository;
import com.watersupply.common.repository.OrderRepository;
import com.watersupply.common.repository.ProductRepository;
import com.watersupply.common.repository.UserRepository;
import com.watersupply.user.dto.CreateComplaintDTO;
import com.watersupply.user.dto.CreateOrderDTO;
import com.watersupply.user.service.UserOrderService;
import com.watersupply.common.service.PDFService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserOrderService orderService;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ComplaintRepository complaintRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private com.watersupply.common.service.NotificationService notificationService;

    @Autowired
    private PDFService pdfService;

    @GetMapping("/products")
    public ResponseEntity<ApiResponse<List<Product>>> getProducts() {
        List<Product> products = productRepository.findByActiveTrue();
        return ResponseEntity.ok(ApiResponse.success("Products retrieved", products));
    }

    @PostMapping("/orders")
    public ResponseEntity<ApiResponse<Order>> createOrder(
            @Valid @RequestBody CreateOrderDTO dto,
            HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        Order order = orderService.createOrder(userId, dto);
        return ResponseEntity.ok(ApiResponse.success("Order placed successfully", order));
    }

    @GetMapping("/orders")
    public ResponseEntity<ApiResponse<List<Order>>> getMyOrders(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        User user = userRepository.findById(userId).orElseThrow();
        List<Order> orders = orderRepository.findByUserOrderByPlacedAtDesc(user);
        return ResponseEntity.ok(ApiResponse.success("Orders retrieved", orders));
    }

    @PostMapping("/complaints")
    public ResponseEntity<ApiResponse<Complaint>> createComplaint(
            @Valid @RequestBody CreateComplaintDTO dto,
            HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        User user = userRepository.findById(userId).orElseThrow();

        Complaint complaint = new Complaint();
        complaint.setUser(user);
        complaint.setSubject(dto.getSubject());
        complaint.setType(dto.getType());
        complaint.setDescription(dto.getDescription());
        complaint.setStatus(Complaint.ComplaintStatus.OPEN);

        complaintRepository.save(complaint);

        notificationService.notifyAdmin(
                "New complaint submitted by " + user.getName() + ": " + dto.getType(),
                "WARNING",
                "COMPLAINT",
                complaint.getId());

        return ResponseEntity.ok(ApiResponse.success("Complaint submitted successfully", complaint));
    }

    @GetMapping("/complaints")
    public ResponseEntity<ApiResponse<List<Complaint>>> getMyComplaints(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        User user = userRepository.findById(userId).orElseThrow();
        List<Complaint> complaints = complaintRepository.findByUserOrderByCreatedAtDesc(user);
        return ResponseEntity.ok(ApiResponse.success("Complaints retrieved", complaints));
    }

    @Autowired
    private com.watersupply.user.service.UserBillingService billingService;

    @GetMapping("/bills")
    public ResponseEntity<ApiResponse<List<Order>>> getMyBills(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        List<Order> orders = billingService.getUserOrders(userId);
        return ResponseEntity.ok(ApiResponse.success("Bills retrieved", orders));
    }

    @GetMapping("/bills/unpaid")
    public ResponseEntity<ApiResponse<List<Order>>> getUnpaidBills(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        List<Order> unpaidOrders = billingService.getUnpaidOrders(userId);
        return ResponseEntity.ok(ApiResponse.success("Unpaid bills retrieved", unpaidOrders));
    }

    @PostMapping("/bills/{orderId}/pay")
    public ResponseEntity<ApiResponse<Order>> payBill(
            @PathVariable Long orderId,
            HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        Order paidOrder = billingService.payOrder(userId, orderId);
        return ResponseEntity.ok(ApiResponse.success("Payment successful. Status updated to PAID.", paidOrder));
    }

    @GetMapping("/bills/total-unpaid")
    public ResponseEntity<ApiResponse<Double>> getTotalUnpaid(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        Double total = billingService.getTotalUnpaidAmount(userId);
        return ResponseEntity.ok(ApiResponse.success("Total unpaid amount", total));
    }

    @GetMapping("/orders/{id}/invoice")
    public ResponseEntity<byte[]> downloadInvoice(@PathVariable Long id, HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        Order order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));

        if (!order.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized");
        }

        try {
            byte[] pdfBytes = pdfService.generateOrderInvoice(order);
            return ResponseEntity.ok()
                    .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=invoice_" + id + ".pdf")
                    .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                    .body(pdfBytes);
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate PDF", e);
        }
    }

    @PostMapping("/orders/{id}/cancel")
    public ResponseEntity<ApiResponse<Order>> cancelOrder(@PathVariable Long id, HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        Order cancelledOrder = orderService.cancelOrder(userId, id);
        return ResponseEntity.ok(ApiResponse.success("Order cancelled successfully", cancelledOrder));
    }
}
