package com.watersupply.employee.controller;

import com.watersupply.common.entity.Complaint;
import com.watersupply.common.entity.DeliverySchedule;
import com.watersupply.common.entity.EmployeeEarnings;
import com.watersupply.common.entity.User;
import com.watersupply.employee.service.EmployeeService;
import com.watersupply.common.repository.UserRepository;
import com.watersupply.common.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private com.watersupply.common.service.PDFService pdfService;

    @GetMapping("/dashboard/summary")
    public ResponseEntity<?> getDashboardStats() {
        User employee = getAuthenticatedEmployee();
        Map<String, Object> stats = employeeService.getDashboardStats(employee.getId());
        return ResponseEntity.ok(createResponse("Dashboard stats fetched successfully", stats));
    }

    @GetMapping("/schedules")
    public ResponseEntity<?> getMySchedules() {
        User employee = getAuthenticatedEmployee();
        List<DeliverySchedule> schedules = employeeService.getMySchedules(employee.getId());
        return ResponseEntity.ok(createResponse("Schedules fetched successfully", schedules));
    }

    @GetMapping("/earnings")
    public ResponseEntity<?> getMyEarnings() {
        User employee = getAuthenticatedEmployee();
        List<EmployeeEarnings> earnings = employeeService.getMyEarnings(employee.getId());
        return ResponseEntity.ok(createResponse("Earnings fetched successfully", earnings));
    }

    @Autowired
    private com.watersupply.common.repository.SalaryPaymentRepository salaryPaymentRepository;

    @GetMapping("/salaries")
    public ResponseEntity<?> getMySalaryPayments() {
        User employee = getAuthenticatedEmployee();
        List<com.watersupply.common.entity.SalaryPayment> payments = salaryPaymentRepository
                .findByEmployeeIdOrderByPaymentDateDesc(employee.getId());
        return ResponseEntity.ok(createResponse("Salary payments fetched successfully", payments));
    }

    @GetMapping("/salaries/{id}/pdf")
    public ResponseEntity<byte[]> downloadSalarySlip(@PathVariable Long id) {
        User employee = getAuthenticatedEmployee();
        com.watersupply.common.entity.SalaryPayment payment = salaryPaymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Salary payment not found"));

        if (!payment.getEmployee().getId().equals(employee.getId())) {
            throw new IllegalArgumentException("Unauthorized access to salary slip");
        }

        try {
            byte[] pdfBytes = pdfService.generateSalarySlip(payment);
            return ResponseEntity.ok()
                    .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=salary_slip_" + payment.getPeriodStart() + ".pdf")
                    .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                    .body(pdfBytes);
        } catch (java.io.IOException e) {
            throw new RuntimeException("Failed to generate PDF", e);
        }
    }

    @PostMapping("/schedules/{id}/start")
    public ResponseEntity<?> startDelivery(@PathVariable Long id) {
        User employee = getAuthenticatedEmployee();
        DeliverySchedule schedule = employeeService.startDelivery(id, employee.getId());
        return ResponseEntity.ok(createResponse("Delivery started", schedule));
    }

    @PostMapping("/schedules/{id}/complete")
    public ResponseEntity<?> completeDelivery(@PathVariable Long id) {
        User employee = getAuthenticatedEmployee();
        DeliverySchedule schedule = employeeService.completeDelivery(id, employee.getId());
        return ResponseEntity.ok(createResponse("Delivery completed successfully", schedule));
    }

    @PostMapping("/issues")
    public ResponseEntity<?> reportIssue(@RequestBody Map<String, String> payload) {
        User employee = getAuthenticatedEmployee();
        String type = payload.get("type");
        String description = payload.get("description");
        String location = payload.get("location");

        Complaint complaint = employeeService.reportIssue(employee.getId(), type, description, location);
        return ResponseEntity.ok(createResponse("Issue reported successfully", complaint));
    }

    @GetMapping("/issues")
    public ResponseEntity<?> getMyComplaints() {
        User employee = getAuthenticatedEmployee();
        List<Complaint> complaints = employeeService.getMyComplaints(employee.getId());
        return ResponseEntity.ok(createResponse("Complaints fetched successfully", complaints));
    }

    private User getAuthenticatedEmployee() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
    }

    private Map<String, Object> createResponse(String message, Object data) {
        return Map.of(
                "message", message,
                "data", data,
                "success", true);
    }
}
