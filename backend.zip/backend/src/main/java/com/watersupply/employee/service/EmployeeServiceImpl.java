package com.watersupply.employee.service;

import com.watersupply.common.entity.*;
import com.watersupply.common.entity.DeliverySchedule.ScheduleStatus;
import com.watersupply.common.repository.DeliveryScheduleRepository;
import com.watersupply.common.repository.EmployeeEarningsRepository;
import com.watersupply.common.repository.ComplaintRepository;
import com.watersupply.common.repository.UserRepository;
import com.watersupply.common.repository.OrderRepository;
import com.watersupply.common.exception.ResourceNotFoundException;
import com.watersupply.common.exception.UnauthorizedException;
import com.watersupply.common.exception.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private DeliveryScheduleRepository scheduleRepository;

    @Autowired
    private EmployeeEarningsRepository earningsRepository;

    @Autowired
    private ComplaintRepository complaintRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private com.watersupply.common.service.NotificationService notificationService;

    @Override
    public Map<String, Object> getDashboardStats(Long employeeId) {
        Map<String, Object> stats = new HashMap<>();

        LocalDate today = LocalDate.now();
        YearMonth thisMonth = YearMonth.now();

        long pendingCount = scheduleRepository.countByEmployeeIdAndStatus(employeeId, ScheduleStatus.PENDING);
        long completedToday = scheduleRepository.countByEmployeeIdAndStatusAndScheduledDate(employeeId,
                ScheduleStatus.COMPLETED, today);

        Double dailyEarnings = earningsRepository.calculateEarnings(employeeId, today.atStartOfDay(),
                today.plusDays(1).atStartOfDay());
        Double monthlyEarnings = earningsRepository.calculateEarnings(employeeId, thisMonth.atDay(1).atStartOfDay(),
                thisMonth.plusMonths(1).atDay(1).atStartOfDay());

        stats.put("pendingSchedules", pendingCount);
        stats.put("completedToday", completedToday);
        stats.put("dailyEarnings", dailyEarnings);
        stats.put("monthlyEarnings", monthlyEarnings);

        return stats;
    }

    @Override
    public List<DeliverySchedule> getMySchedules(Long employeeId) {
        return scheduleRepository.findByEmployeeIdOrderByScheduledDateDesc(employeeId);
    }

    @Override
    public List<EmployeeEarnings> getMyEarnings(Long employeeId) {
        return earningsRepository.findByEmployeeIdOrderByEarnedAtDesc(employeeId);
    }

    @Override
    @Transactional
    public DeliverySchedule startDelivery(Long scheduleId, Long employeeId) {
        DeliverySchedule schedule = getScheduleWithAccessCheck(scheduleId, employeeId);

        if (schedule.getStatus() != ScheduleStatus.PENDING) {
            throw new BusinessException("Delivery must be PENDING to start.");
        }

        schedule.setStatus(ScheduleStatus.IN_PROGRESS);
        schedule.setStartedAt(LocalDateTime.now());

        updateOrder(schedule.getOrder(), Order.OrderStatus.OUT_FOR_DELIVERY);

        return scheduleRepository.save(schedule);
    }

    // Synchronized to prevent double completion and earnings duplication
    @Override
    @Transactional
    public synchronized DeliverySchedule completeDelivery(Long scheduleId, Long employeeId) {
        DeliverySchedule schedule = getScheduleWithAccessCheck(scheduleId, employeeId);

        if (schedule.getStatus() == ScheduleStatus.COMPLETED) {
            throw new BusinessException("Delivery is already COMPLETED.");
        }

        if (schedule.getStatus() != ScheduleStatus.IN_PROGRESS) {
            throw new BusinessException("Delivery must be IN_PROGRESS to complete."); // Or PENDING if you allow instant
                                                                                      // completion
        }

        schedule.setStatus(ScheduleStatus.COMPLETED);
        schedule.setCompletedAt(LocalDateTime.now());

        updateOrder(schedule.getOrder(), Order.OrderStatus.DELIVERED);

        scheduleRepository.save(schedule);

        // Generate Immutable Earning Record
        // Generate Immutable Earning Record
        generateEarning(schedule);

        // Notify User
        if (schedule.getOrder() != null && schedule.getOrder().getUser() != null) {
            notificationService.notifyUser(
                    schedule.getOrder().getUser(),
                    "Your Order #" + schedule.getOrder().getId() + " has been successfully delivered!",
                    "SUCCESS",
                    "ORDER",
                    schedule.getOrder().getId());

            // Notify Admin
            notificationService.notifyAdmin(
                    "Order #" + schedule.getOrder().getId() + " delivered by " + schedule.getEmployee().getName(),
                    "SUCCESS",
                    "ORDER",
                    schedule.getOrder().getId());
        }

        return schedule;
    }

    @Override
    @Transactional
    public DeliverySchedule submitMeterReading(Long scheduleId, Long employeeId, Double reading) {
        if (reading < 0) {
            throw new BusinessException("Meter reading cannot be negative.");
        }

        DeliverySchedule schedule = getScheduleWithAccessCheck(scheduleId, employeeId);
        schedule.setMeterReading(reading);
        return scheduleRepository.save(schedule);
    }

    @Override
    @Transactional
    public Complaint reportIssue(Long employeeId, String typeStr, String description, String location) {
        User employee = userRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        Complaint complaint = new Complaint();
        try {
            complaint.setType(Complaint.ComplaintType.valueOf(typeStr.toUpperCase()));
        } catch (IllegalArgumentException e) {
            complaint.setType(Complaint.ComplaintType.OTHER);
        }

        complaint.setUser(employee); // In this context, the employee is the "user" reporting the issue from the
                                     // field
        // Ideally, if it's about a customer order, we might link to customer, but
        // keeping it simple as per requirements

        complaint.setSubject(typeStr.replace("_", " ") + " Report");
        complaint.setDescription(description + " [Location: " + location + "]");
        complaint.setStatus(Complaint.ComplaintStatus.OPEN);
        complaint.setAssignedEmployee(employee); // Self-assigned or just reporter? Requirement says "visible to admin".
                                                 // sticking to basic.

        complaintRepository.save(complaint);

        // Notify Admin
        notificationService.notifyAdmin(
                "New complaint submitted by employee " + employee.getName() + ": " + complaint.getType(),
                "WARNING",
                "COMPLAINT",
                complaint.getId());

        return complaint;
    }

    @Override
    public List<Complaint> getMyComplaints(Long employeeId) {
        User employee = userRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        // Assuming we want complaints where the employee is the SUBMITTER (user_id =
        // employee_id)
        // Since in reportIssue we set complaint.setUser(employee)
        return complaintRepository.findByUserOrderByCreatedAtDesc(employee);
    }

    private DeliverySchedule getScheduleWithAccessCheck(Long scheduleId, Long employeeId) {
        DeliverySchedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ResourceNotFoundException("Schedule not found"));

        if (!schedule.getEmployee().getId().equals(employeeId)) {
            throw new UnauthorizedException("You are not authorized to access this schedule.");
        }
        return schedule;
    }

    private void generateEarning(DeliverySchedule schedule) {
        User employee = schedule.getEmployee();
        Double rate = employee.getPaymentRate() != null ? employee.getPaymentRate() : 500.0; // Default rate

        EmployeeEarnings earnings = new EmployeeEarnings();
        earnings.setEmployee(employee);
        earnings.setDeliverySchedule(schedule);
        earnings.setEarningAmount(rate);
        earnings.setPaid(false);
        earnings.setImmutable(true); // Mark as immutable

        earningsRepository.save(earnings);
    }

    private void updateOrder(Order order, Order.OrderStatus status) {
        if (order != null) {
            order.setStatus(status);
            if (status == Order.OrderStatus.DELIVERED) {
                order.setDeliveredAt(LocalDateTime.now());

                // Mark as Paid if COD or Card (Employee collected it)
                if (!order.getPaid()) {
                    order.setPaid(true);
                    order.setPaidAt(LocalDateTime.now());
                }
            }
            orderRepository.save(order);
        }
    }
}
