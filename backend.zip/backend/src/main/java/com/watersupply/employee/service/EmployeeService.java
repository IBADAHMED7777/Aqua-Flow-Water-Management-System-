package com.watersupply.employee.service;

import com.watersupply.common.entity.Complaint;
import com.watersupply.common.entity.DeliverySchedule;
import com.watersupply.common.entity.EmployeeEarnings;
import com.watersupply.common.entity.User;

import java.util.List;
import java.util.Map;

public interface EmployeeService {

    Map<String, Object> getDashboardStats(Long employeeId);

    List<DeliverySchedule> getMySchedules(Long employeeId);

    List<EmployeeEarnings> getMyEarnings(Long employeeId);

    DeliverySchedule startDelivery(Long scheduleId, Long employeeId);

    DeliverySchedule completeDelivery(Long scheduleId, Long employeeId);

    DeliverySchedule submitMeterReading(Long scheduleId, Long employeeId, Double reading);

    Complaint reportIssue(Long employeeId, String type, String description, String location);

    List<Complaint> getMyComplaints(Long employeeId);
}
