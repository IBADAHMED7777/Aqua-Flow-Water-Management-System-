package com.watersupply.common.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Automatically fixes database schema issues on startup
 */
@Component
public class DatabaseFixer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseFixer.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        logger.info("Checking database schema for required columns...");

        fixOrdersTable();
        fixComplaintsTable();

        logger.info("Database schema check completed.");
    }

    private void fixOrdersTable() {
        try {
            // Check if 'paid' column exists
            Integer paidExists = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'paid'",
                    Integer.class);

            if (paidExists != null && paidExists == 0) {
                logger.info("Adding missing 'paid' column to orders table...");
                jdbcTemplate.execute("ALTER TABLE orders ADD COLUMN paid BOOLEAN NOT NULL DEFAULT FALSE");
                logger.info("Added 'paid' column.");
            }

            // Check if 'paid_at' column exists
            Integer paidAtExists = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'paid_at'",
                    Integer.class);

            if (paidAtExists != null && paidAtExists == 0) {
                logger.info("Adding missing 'paid_at' column to orders table...");
                jdbcTemplate.execute("ALTER TABLE orders ADD COLUMN paid_at DATETIME NULL");
                logger.info("Added 'paid_at' column.");
            }
        } catch (Exception e) {
            logger.error("Failed to fix orders table: " + e.getMessage());
        }
    }

    private void fixComplaintsTable() {
        try {
            // Check if 'subject' column exists
            Integer subjectExists = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'complaints' AND COLUMN_NAME = 'subject'",
                    Integer.class);

            // Note: The user reported 'subject' cannot be null, so it likely exists but we
            // ensure it matches
            if (subjectExists != null && subjectExists == 0) {
                logger.info("Adding missing 'subject' column to complaints table...");
                jdbcTemplate.execute(
                        "ALTER TABLE complaints ADD COLUMN subject VARCHAR(255) NOT NULL DEFAULT 'No Subject'");
                logger.info("Added 'subject' column.");
            }
        } catch (Exception e) {
            logger.error("Failed to fix complaints table: " + e.getMessage());
        }
    }
}
