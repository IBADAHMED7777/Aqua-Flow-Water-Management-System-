package com.watersupply.common.service;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.LineSeparator;
import com.watersupply.common.entity.Bill;
import com.watersupply.common.entity.Order;
import com.watersupply.common.entity.SalaryPayment;
import com.watersupply.common.entity.User;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.awt.Color;

@Service
public class PDFService {

    private static final Font TITLE_FONT = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
    private static final Font HEADER_FONT = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
    private static final Font NORMAL_FONT = FontFactory.getFont(FontFactory.HELVETICA, 10);
    private static final Color PRIMARY_COLOR = new Color(0, 102, 204);

    public byte[] generateOrderInvoice(Order order) throws IOException {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document();
            PdfWriter.getInstance(document, out);
            document.open();

            addLogoAndHeader(document, "OFFICIAL INVOICE");

            // Info Table
            PdfPTable infoTable = new PdfPTable(2);
            infoTable.setWidthPercentage(100);
            infoTable.setSpacingBefore(10);

            addCell(infoTable, "Invoice Number: INV-" + order.getId(), true);
            addCell(infoTable, "Order ID: #" + order.getId(), false);
            addCell(infoTable,
                    "Billing Date: " + order.getPlacedAt().format(DateTimeFormatter.ofPattern("dd MMM yyyy")), true);
            addCell(infoTable, "Payment Status: " + (order.getPaid() ? "PAID" : "UNPAID"), false);

            document.add(infoTable);

            // Customer Info
            Paragraph customerHeader = new Paragraph("\nBILL TO:", HEADER_FONT);
            document.add(customerHeader);
            Paragraph customerDetails = new Paragraph(
                    order.getUser().getName() + "\n" +
                            "Phone: " + order.getUser().getPhone() + "\n" +
                            "Delivery Address: "
                            + (order.getDeliveryAddress() != null ? order.getDeliveryAddress() : "Standard Address"),
                    NORMAL_FONT);
            document.add(customerDetails);

            // Item Table
            PdfPTable itemTable = new PdfPTable(4);
            itemTable.setWidthPercentage(100);
            itemTable.setSpacingBefore(20);
            itemTable.setWidths(new float[] { 5, 2, 2, 2 });

            addHeaderCell(itemTable, "Product Name");
            addHeaderCell(itemTable, "Price");
            addHeaderCell(itemTable, "Quantity");
            addHeaderCell(itemTable, "Subtotal");

            if (order.getItems() != null && !order.getItems().isEmpty()) {
                order.getItems().forEach(item -> {
                    addCell(itemTable, item.getProduct().getName(), false);
                    addCell(itemTable, formatCurrency(item.getUnitPrice()), false);
                    addCell(itemTable, String.valueOf(item.getQuantity()), false);
                    addCell(itemTable, formatCurrency(item.getSubtotal()), false);
                });
            } else {
                addCell(itemTable, "Water Supply Services", false);
                addCell(itemTable, "-", false);
                addCell(itemTable, "1", false);
                addCell(itemTable, formatCurrency(order.getTotalAmount()), false);
            }

            document.add(itemTable);

            // Totals
            PdfPTable totalsTable = new PdfPTable(2);
            totalsTable.setWidthPercentage(40);
            totalsTable.setHorizontalAlignment(Element.ALIGN_RIGHT);
            totalsTable.setSpacingBefore(10);

            addTotalRow(totalsTable, "Subtotal:",
                    order.getTotalAmount() - (order.getTax() != null ? order.getTax() : 0.0)
                            - (order.getDeliveryCharges() != null ? order.getDeliveryCharges() : 0.0));
            addTotalRow(totalsTable, "Tax:", order.getTax() != null ? order.getTax() : 0.0);
            addTotalRow(totalsTable, "Delivery:",
                    order.getDeliveryCharges() != null ? order.getDeliveryCharges() : 0.0);
            addTotalRow(totalsTable, "Total Amount:", order.getTotalAmount());

            document.add(totalsTable);

            Paragraph paymentMethod = new Paragraph("\nPayment Method: " + order.getPaymentMethod(), NORMAL_FONT);
            document.add(paymentMethod);

            Paragraph orderStatus = new Paragraph("Order Status: " + order.getStatus(), NORMAL_FONT);
            document.add(orderStatus);

            addFooter(document);
            document.close();
            return out.toByteArray();
        }
    }

    public byte[] generateSalarySlip(SalaryPayment salary) throws IOException {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document();
            PdfWriter.getInstance(document, out);
            document.open();

            addLogoAndHeader(document, "SALARY SLIP");

            // Employee & Period
            PdfPTable empTable = new PdfPTable(2);
            empTable.setWidthPercentage(100);
            empTable.setSpacingBefore(10);

            User emp = salary.getEmployee();
            addCell(empTable, "Employee Name: " + emp.getName(), true);
            addCell(empTable, "Employee ID: EMP-" + emp.getId(), false);
            addCell(empTable, "Designation: " + emp.getRole(), true);
            addCell(empTable, "Salary Period: " + salary.getPeriodStart() + " to " + salary.getPeriodEnd(), false);

            document.add(empTable);

            // Financials Table
            PdfPTable finTable = new PdfPTable(2);
            finTable.setWidthPercentage(100);
            finTable.setSpacingBefore(20);
            finTable.setWidths(new float[] { 7, 3 });

            addHeaderCell(finTable, "Description");
            addHeaderCell(finTable, "Amount");

            addCell(finTable, "Basic Salary", false);
            addCell(finTable, formatCurrency(salary.getBasicSalary()), false);

            addCell(finTable, "Allowances", false);
            addCell(finTable, formatCurrency(salary.getAllowances()), false);

            addCell(finTable, "Deductions", false);
            addCell(finTable, "-" + formatCurrency(salary.getDeductions()), false);

            document.add(finTable);

            // Net Pay
            PdfPTable netTable = new PdfPTable(2);
            netTable.setWidthPercentage(100);
            netTable.setSpacingBefore(10);

            addCell(netTable, "Net Salary Paid:", true);
            PdfPCell amountCell = new PdfPCell(new Phrase(formatCurrency(salary.getAmount()), HEADER_FONT));
            amountCell.setBorder(Rectangle.NO_BORDER);
            amountCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            netTable.addCell(amountCell);

            document.add(netTable);

            // Payment Details
            Paragraph paymentDetails = new Paragraph(
                    "\nPayment Date: " + salary.getPaymentDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
                            + "\n" +
                            "Payment Method: " + salary.getPaymentMethod() + "\n" +
                            "Status: Paid",
                    NORMAL_FONT);
            document.add(paymentDetails);

            if (salary.getAuthorizedBy() != null) {
                Paragraph auth = new Paragraph("\nAuthorized By: " + salary.getAuthorizedBy().getName() + " (Admin)",
                        NORMAL_FONT);
                auth.setAlignment(Element.ALIGN_RIGHT);
                document.add(auth);
            }

            addFooter(document);
            document.close();
            return out.toByteArray();
        }
    }

    private void addLogoAndHeader(Document document, String docType) throws DocumentException {
        Paragraph company = new Paragraph("WATER SUPPLY MANAGEMENT", TITLE_FONT);
        company.setAlignment(Element.ALIGN_CENTER);
        company.getFont().setColor(PRIMARY_COLOR);
        document.add(company);

        Paragraph tagline = new Paragraph("Professional & Reliable Service", NORMAL_FONT);
        tagline.setAlignment(Element.ALIGN_CENTER);
        document.add(tagline);

        LineSeparator ls = new LineSeparator();
        ls.setLineColor(PRIMARY_COLOR);
        document.add(new Chunk(ls));

        Paragraph subtitle = new Paragraph(docType, HEADER_FONT);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingBefore(10);
        subtitle.setSpacingAfter(10);
        document.add(subtitle);
    }

    private void addFooter(Document document) throws DocumentException {
        Paragraph footer = new Paragraph("\n\nThis is a computer-generated document. No signature required.",
                FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 8));
        footer.setAlignment(Element.ALIGN_CENTER);
        document.add(footer);
    }

    private void addHeaderCell(PdfPTable table, String text) {
        PdfPCell cell = new PdfPCell(
                new Phrase(text.toUpperCase(), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.WHITE)));
        cell.setBackgroundColor(PRIMARY_COLOR);
        cell.setPadding(8);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(cell);
    }

    private void addCell(PdfPTable table, String text, boolean bold) {
        PdfPCell cell = new PdfPCell(new Phrase(text, bold ? HEADER_FONT : NORMAL_FONT));
        cell.setPadding(5);
        cell.setBorder(Rectangle.NO_BORDER);
        table.addCell(cell);
    }

    private void addTotalRow(PdfPTable table, String label, Double value) {
        PdfPCell labelCell = new PdfPCell(new Phrase(label, NORMAL_FONT));
        labelCell.setBorder(Rectangle.NO_BORDER);
        table.addCell(labelCell);

        PdfPCell valueCell = new PdfPCell(new Phrase(formatCurrency(value), HEADER_FONT));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        table.addCell(valueCell);
    }

    public byte[] generateBillPdf(Bill bill) throws IOException {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document();
            PdfWriter.getInstance(document, out);
            document.open();

            addLogoAndHeader(document, "MONTHLY WATER BILL");

            // Bill Info Table
            PdfPTable infoTable = new PdfPTable(2);
            infoTable.setWidthPercentage(100);
            infoTable.setSpacingBefore(10);

            addCell(infoTable, "Bill ID: #" + bill.getId(), true);
            addCell(infoTable, "Billing Month: " + bill.getBillingMonth() + "/" + bill.getBillingYear(), false);
            addCell(infoTable,
                    "Issue Date: " + bill.getGeneratedAt().format(DateTimeFormatter.ofPattern("dd MMM yyyy")),
                    true);
            addCell(infoTable, "Due Date: " + bill.getDueDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy")),
                    false);

            document.add(infoTable);

            // Customer Info
            Paragraph customerHeader = new Paragraph("\nBILL TO:", HEADER_FONT);
            document.add(customerHeader);
            Paragraph customerDetails = new Paragraph(
                    bill.getUser().getName() + "\n" +
                            "Phone: " + bill.getUser().getPhone() + "\n" +
                            "Address: " + bill.getUser().getAddress(),
                    NORMAL_FONT);
            document.add(customerDetails);

            // Consumption Table
            PdfPTable consTable = new PdfPTable(4);
            consTable.setWidthPercentage(100);
            consTable.setSpacingBefore(20);
            consTable.setWidths(new float[] { 5, 2, 2, 2 });

            addHeaderCell(consTable, "Description");
            addHeaderCell(consTable, "Units");
            addHeaderCell(consTable, "Rate");
            addHeaderCell(consTable, "Amount");

            addCell(consTable, "Water Consumption Charge", false);
            addCell(consTable, String.valueOf(bill.getConsumptionAmount()), false);
            addCell(consTable, formatCurrency(bill.getRatePerUnit()), false);
            addCell(consTable, formatCurrency(bill.getTotalAmount()), false);

            document.add(consTable);

            // Totals
            PdfPTable totalsTable = new PdfPTable(2);
            totalsTable.setWidthPercentage(40);
            totalsTable.setHorizontalAlignment(Element.ALIGN_RIGHT);
            totalsTable.setSpacingBefore(10);

            addTotalRow(totalsTable, "Current Charges:", bill.getTotalAmount());
            addTotalRow(totalsTable, "Payable Amount:", bill.getTotalAmount());

            document.add(totalsTable);

            Paragraph status = new Paragraph("\nPayment Status: " + (bill.getPaid() ? "PAID" : "UNPAID"), NORMAL_FONT);
            document.add(status);

            addFooter(document);
            document.close();
            return out.toByteArray();
        }
    }

    private String formatCurrency(Double amount) {
        if (amount == null)
            amount = 0.0;
        return "PKR " + NumberFormat.getNumberInstance(Locale.US).format(amount);
    }
}
