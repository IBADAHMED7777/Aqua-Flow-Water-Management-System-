package com.watersupply.common.repository;

import com.watersupply.common.entity.EmployeeEarnings;
import com.watersupply.common.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EmployeeEarningsRepository extends JpaRepository<EmployeeEarnings, Long> {

        List<EmployeeEarnings> findByEmployee(User employee);

        List<EmployeeEarnings> findByEmployeeAndEarnedAtBetween(User employee, LocalDateTime startDate,
                        LocalDateTime endDate);

        @Query("SELECT SUM(e.earningAmount) FROM EmployeeEarnings e WHERE e.employee = :employee AND e.earnedAt BETWEEN :startDate AND :endDate")
        Double sumEarningsByEmployeeAndDateRange(@Param("employee") User employee,
                        @Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);

        @Query("SELECT COALESCE(SUM(e.earningAmount), 0) FROM EmployeeEarnings e WHERE e.employee.id = :employeeId AND e.earnedAt BETWEEN :startDate AND :endDate")
        Double calculateEarnings(@Param("employeeId") Long employeeId, @Param("startDate") LocalDateTime startDate,
                        @Param("endDate") LocalDateTime endDate);

        List<EmployeeEarnings> findByEmployeeIdOrderByEarnedAtDesc(Long employeeId);

        List<EmployeeEarnings> findByEmployeeIdAndPaidFalseOrderByEarnedAtAsc(Long employeeId);
}
