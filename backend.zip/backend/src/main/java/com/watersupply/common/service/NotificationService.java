package com.watersupply.common.service;

import com.watersupply.admin.entity.Notification;
import com.watersupply.admin.repository.NotificationRepository;
import com.watersupply.common.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;

    @Transactional
    public void notifyAdmin(String message, String type, String relatedEntity, Long relatedEntityId) {
        Notification notification = new Notification();
        notification.setMessage(message);
        notification.setType(type);
        notification.setRecipient(null); // Admin broadcast
        notification.setRelatedEntity(relatedEntity);
        notification.setRelatedEntityId(relatedEntityId);
        notificationRepository.save(notification);
    }

    @Transactional
    public void notifyUser(User recipient, String message, String type, String relatedEntity, Long relatedEntityId) {
        Notification notification = new Notification();
        notification.setMessage(message);
        notification.setType(type);
        notification.setRecipient(recipient);
        notification.setRelatedEntity(relatedEntity);
        notification.setRelatedEntityId(relatedEntityId);
        notificationRepository.save(notification);
    }
}
