package com.watersupply.common.repository;

import com.watersupply.common.entity.User;
import com.watersupply.common.entity.WaterConsumption;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface WaterConsumptionRepository extends JpaRepository<WaterConsumption, Long> {

    List<WaterConsumption> findByUser(User user);

    List<WaterConsumption> findByUserAndDateBetween(User user, LocalDate startDate, LocalDate endDate);

    @Query("SELECT SUM(w.consumptionAmount) FROM WaterConsumption w WHERE w.user = :user AND w.date BETWEEN :startDate AND :endDate")
    Double sumConsumptionByUserAndDateRange(@Param("user") User user, @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate);
}
