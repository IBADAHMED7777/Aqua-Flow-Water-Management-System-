package com.watersupply.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class FileStorageConfig implements WebMvcConfigurer {

    @Value("${file.upload-dir:uploads}")
    private String uploadDir;

    public String getUploadDir() {
        return uploadDir;
    }

    @PostConstruct
    public void init() {
        try {
            Path profilePath = Paths.get(uploadDir, "profiles");
            Path productPath = Paths.get(uploadDir, "products");

            if (!Files.exists(profilePath)) {
                Files.createDirectories(profilePath);
            }
            if (!Files.exists(productPath)) {
                Files.createDirectories(productPath);
            }
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload directory!", e);
        }
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:" + uploadDir + "/");
    }
}
