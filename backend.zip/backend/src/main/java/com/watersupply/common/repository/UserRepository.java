package com.watersupply.common.repository;

import com.watersupply.common.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    List<User> findByRole(User.Role role);

    org.springframework.data.domain.Page<User> findByRole(User.Role role,
            org.springframework.data.domain.Pageable pageable);

    long countByRole(User.Role role);

    boolean existsByEmail(String email);

    boolean existsByUsername(String username);

    Optional<User> findByUsername(String username);
}
