package com.watersupply.common.repository;

import com.watersupply.common.entity.Complaint;
import com.watersupply.common.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Long> {

    List<Complaint> findByUser(User user);

    List<Complaint> findByUserOrderByCreatedAtDesc(User user);

    List<Complaint> findByStatus(Complaint.ComplaintStatus status);

    long countByStatus(Complaint.ComplaintStatus status);

    List<Complaint> findByAssignedEmployee(User employee);

    org.springframework.data.domain.Page<Complaint> findByAssignedEmployeeIsNull(
            org.springframework.data.domain.Pageable pageable);

    org.springframework.data.domain.Page<Complaint> findByAssignedEmployeeIsNotNull(
            org.springframework.data.domain.Pageable pageable);
}