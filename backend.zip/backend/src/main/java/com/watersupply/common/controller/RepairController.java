package com.watersupply.common.controller;

import com.watersupply.common.dto.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@RequestMapping("/api/public")
@CrossOrigin(origins = "http://localhost:3000")
public class RepairController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/repair-db")
    public ApiResponse<String> repairDatabase() {
        try {
            // Fix Orders
            try {
                jdbcTemplate.execute("ALTER TABLE orders ADD COLUMN paid BOOLEAN NOT NULL DEFAULT FALSE");
            } catch (Exception e) {
                /* Ignore if exists */ }

            try {
                jdbcTemplate.execute("ALTER TABLE orders ADD COLUMN paid_at DATETIME NULL");
            } catch (Exception e) {
                /* Ignore if exists */ }

            // Fix Complaints
            try {
                jdbcTemplate.execute(
                        "ALTER TABLE complaints ADD COLUMN subject VARCHAR(255) NOT NULL DEFAULT 'No Subject'");
            } catch (Exception e) {
                /* Ignore if exists */ }

            return ApiResponse.success("Database repair attempted successfully", "OK");
        } catch (Exception e) {
            return ApiResponse.error("Repair failed: " + e.getMessage());
        }
    }
}
