package com.watersupply.common.controller;

import com.watersupply.common.dto.ApiResponse;
import com.watersupply.common.dto.AuthRequest;
import com.watersupply.common.dto.AuthResponse;
import com.watersupply.common.entity.User;
import com.watersupply.common.repository.UserRepository;
import com.watersupply.common.security.JwtTokenProvider;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenProvider tokenProvider;

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@Valid @RequestBody AuthRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BadCredentialsException("Invalid credentials");
        }

        if (!user.getActive()) {
            throw new BadCredentialsException("Account is inactive");
        }

        String token = tokenProvider.generateToken(user.getEmail(), user.getRole().name(), user.getId());

        AuthResponse authResponse = new AuthResponse(
                token,
                user.getEmail(),
                user.getName(),
                user.getRole().name());

        return ResponseEntity.ok(ApiResponse.success("Login successful", authResponse));
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<AuthResponse>> register(
            @Valid @RequestBody com.watersupply.common.dto.RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Email already exists"));
        }

        User user = new User();
        user.setName(request.getName());
        user.setUsername(request.getName()); // Default username is full name
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setAddress(request.getAddress());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(User.Role.USER);
        user.setActive(true);

        userRepository.save(user);

        // Auto-login after registration
        String token = tokenProvider.generateToken(user.getEmail(), user.getRole().name(), user.getId());
        AuthResponse authResponse = new AuthResponse(token, user.getEmail(), user.getName(), user.getRole().name());

        return ResponseEntity.ok(ApiResponse.success("Registration successful", authResponse));
    }
}
