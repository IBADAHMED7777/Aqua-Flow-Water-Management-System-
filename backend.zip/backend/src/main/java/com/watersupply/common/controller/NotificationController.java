package com.watersupply.common.controller;

import com.watersupply.admin.entity.Notification;
import com.watersupply.common.dto.ApiResponse;
import com.watersupply.common.entity.User;
import com.watersupply.admin.repository.NotificationRepository;
import com.watersupply.common.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import com.watersupply.common.repository.UserRepository;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "http://localhost:3000")
public class NotificationController {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/unread")
    public ResponseEntity<List<Notification>> getUnreadNotifications(@AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) {
            return ResponseEntity.ok(List.of());
        }

        String username = userDetails.getUsername();
        User currentUser = userRepository.findByEmail(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // This logic is a bit simple, it assumes we fetch ALL notifications and filter
        // in memory.
        // In prod, we should use a custom repository method.
        // We need notifications where:
        // (recipient is null AND user is ADMIN) OR (recipient id == user id)
        // AND isRead is false

        boolean isAdmin = currentUser.getRole().name().equals("ADMIN");

        List<Notification> allNotifications = notificationRepository.findByIsReadFalseOrderByCreatedAtDesc();

        List<Notification> filtered = allNotifications.stream()
                .filter(n -> {
                    if (n.getRecipient() == null) {
                        return isAdmin; // Admin only for broadcast
                    }
                    return n.getRecipient().getId().equals(currentUser.getId());
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(filtered);
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<ApiResponse<Void>> markAsRead(@PathVariable Long id) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));

        notification.setIsRead(true);
        notificationRepository.save(notification);

        return ResponseEntity.ok(ApiResponse.success("Marked as read", null));
    }
}
