package com.watersupply.common.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
@com.fasterxml.jackson.annotation.JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private Double totalAmount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private OrderStatus status = OrderStatus.PLACED;

    @Enumerated(EnumType.STRING)
    @Column(length = 50)
    private PaymentMethod paymentMethod = PaymentMethod.CASH_ON_DELIVERY;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_employee_id")
    private User assignedEmployee;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderItem> items = new ArrayList<>();

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime placedAt;

    private LocalDateTime assignedAt;

    private LocalDateTime deliveredAt;

    @Column(nullable = false)
    private Boolean paid = false;

    private LocalDateTime paidAt;

    @Column(length = 1000)
    private String orderSummary; // Immutable summary once completed

    private Double tax = 0.0;

    private Double deliveryCharges = 0.0;

    @Column(length = 500)
    private String deliveryAddress;

    public enum OrderStatus {
        PLACED, ASSIGNED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
    }

    public enum PaymentMethod {
        CASH_ON_DELIVERY, CARD_PAYMENT, ONLINE_PAYMENT
    }

    public void addItem(OrderItem item) {
        items.add(item);
        item.setOrder(this);
    }
}
