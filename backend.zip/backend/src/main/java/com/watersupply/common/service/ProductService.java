package com.watersupply.common.service;

import com.watersupply.common.entity.Product;
import com.watersupply.common.exception.BusinessException;
import com.watersupply.common.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public List<Product> getAllProducts(boolean activeOnly) {
        if (activeOnly) {
            return productRepository.findByActiveTrue();
        }
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new BusinessException("Product not found with ID: " + id));
    }

    @Transactional
    public Product createProduct(Product product) {
        return createProduct(product, null);
    }

    @Transactional
    public Product createProduct(Product product, org.springframework.web.multipart.MultipartFile image) {
        // Basic validation
        if (product.getPrice() < 0) {
            throw new BusinessException("Price cannot be negative");
        }

        if (image != null && !image.isEmpty()) {
            try {
                String filename = saveImage(image);
                product.setImagePath("products/" + filename);
            } catch (java.io.IOException e) {
                throw new BusinessException("Failed to save product image: " + e.getMessage());
            }
        }

        return productRepository.save(product);
    }

    @Transactional
    public Product updateProduct(Long id, Product details) {
        return updateProduct(id, details, null);
    }

    @Transactional
    public Product updateProduct(Long id, Product details, org.springframework.web.multipart.MultipartFile image) {
        Product product = getProductById(id);

        product.setName(details.getName());
        product.setDescription(details.getDescription());
        product.setPrice(details.getPrice());
        product.setStockQuantity(details.getStockQuantity());
        product.setCategory(details.getCategory());
        product.setActive(details.getActive());

        if (image != null && !image.isEmpty()) {
            try {
                // Delete old image if exists
                if (product.getImagePath() != null) {
                    deleteImageFile(product.getImagePath());
                }
                String filename = saveImage(image);
                product.setImagePath("products/" + filename);
            } catch (java.io.IOException e) {
                throw new BusinessException("Failed to save product image: " + e.getMessage());
            }
        }

        return productRepository.save(product);
    }

    private final com.watersupply.common.config.FileStorageConfig fileStorageConfig;

    private String saveImage(org.springframework.web.multipart.MultipartFile file) throws java.io.IOException {
        String originalFilename = file.getOriginalFilename();
        String extension = originalFilename.substring(originalFilename.lastIndexOf(".")).toLowerCase();
        String filename = java.util.UUID.randomUUID().toString() + extension;

        java.nio.file.Path uploadPath = java.nio.file.Paths.get(fileStorageConfig.getUploadDir(), "products");
        java.nio.file.Path filePath = uploadPath.resolve(filename);

        java.nio.file.Files.copy(file.getInputStream(), filePath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        return filename;
    }

    private void deleteImageFile(String path) {
        try {
            java.nio.file.Path filePath = java.nio.file.Paths.get(fileStorageConfig.getUploadDir()).resolve(path);
            java.nio.file.Files.deleteIfExists(filePath);
        } catch (java.io.IOException e) {
            System.err.println("Error deleting product image: " + e.getMessage());
        }
    }

    @Transactional
    public void deleteProduct(Long id) {
        Product product = getProductById(id);
        if (product.getImagePath() != null) {
            deleteImageFile(product.getImagePath());
        }
        productRepository.delete(product);
    }
}
