package com.watersupply.common.controller;

import com.watersupply.common.dto.ChangePasswordRequest;
import com.watersupply.common.dto.ProfileDTO;
import com.watersupply.common.dto.UpdateProfileRequest;
import com.watersupply.common.service.ProfileService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/profile")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ProfileController {

    private final ProfileService profileService;
    private final com.watersupply.common.repository.UserRepository userRepository;

    @GetMapping
    public ResponseEntity<ProfileDTO> getCurrentUserProfile(Authentication authentication) {
        Long userId = getUserIdFromAuthentication(authentication);
        ProfileDTO profile = profileService.getUserProfile(userId);
        return ResponseEntity.ok(profile);
    }

    @PutMapping("/update")
    public ResponseEntity<Map<String, Object>> updateProfile(
            @Valid @RequestBody UpdateProfileRequest request,
            Authentication authentication) {

        Long userId = getUserIdFromAuthentication(authentication);
        ProfileDTO updatedProfile = profileService.updateProfile(userId, request);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Profile updated successfully");
        response.put("profile", updatedProfile);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/change-password")
    public ResponseEntity<Map<String, String>> changePassword(
            @Valid @RequestBody ChangePasswordRequest request,
            Authentication authentication) {

        Long userId = getUserIdFromAuthentication(authentication);
        profileService.changePassword(userId, request);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Password changed successfully");

        return ResponseEntity.ok(response);
    }

    @PostMapping(value = "/upload-image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> uploadProfileImage(
            @RequestParam("file") MultipartFile file,
            Authentication authentication) throws IOException {

        Long userId = getUserIdFromAuthentication(authentication);
        ProfileDTO updatedProfile = profileService.uploadProfileImage(userId, file);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Profile image uploaded successfully");
        response.put("profile", updatedProfile);

        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/image/{userId}", produces = { MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_PNG_VALUE })
    public ResponseEntity<byte[]> getProfileImage(@PathVariable Long userId) throws IOException {
        byte[] image = profileService.getProfileImage(userId);
        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(image);
    }

    @DeleteMapping("/image")
    public ResponseEntity<Map<String, String>> deleteProfileImage(Authentication authentication) {
        Long userId = getUserIdFromAuthentication(authentication);
        profileService.deleteProfileImage(userId);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Profile image deleted successfully");

        return ResponseEntity.ok(response);
    }

    private Long getUserIdFromAuthentication(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new IllegalStateException("User not authenticated");
        }

        String email = null;
        if (authentication.getPrincipal() instanceof UserDetails) {
            email = ((UserDetails) authentication.getPrincipal()).getUsername();
        } else {
            email = authentication.getName();
        }

        return userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalStateException("User not found"))
                .getId();
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleIllegalArgument(IllegalArgumentException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", ex.getMessage());
        return ResponseEntity.badRequest().body(error);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<Map<String, String>> handleIOException(IOException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "File upload failed: " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }
}
