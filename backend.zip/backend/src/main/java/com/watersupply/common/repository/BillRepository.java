package com.watersupply.common.repository;

import com.watersupply.common.entity.Bill;
import com.watersupply.common.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillRepository extends JpaRepository<Bill, Long> {

    List<Bill> findByUser(User user);

    List<Bill> findByUserOrderByGeneratedAtDesc(User user);

    Optional<Bill> findByUserAndBillingMonthAndBillingYear(User user, Integer month, Integer year);

    List<Bill> findByPaidFalse();

    @org.springframework.data.jpa.repository.Query("SELECT SUM(b.totalAmount) FROM Bill b WHERE b.billingMonth = :month AND b.billingYear = :year")
    Double calculateMonthlyRevenue(@org.springframework.data.repository.query.Param("month") Integer month,
            @org.springframework.data.repository.query.Param("year") Integer year);

    @org.springframework.data.jpa.repository.Query("SELECT SUM(b.totalAmount) FROM Bill b WHERE b.billingYear = :year")
    Double calculateYearlyRevenue(@org.springframework.data.repository.query.Param("year") Integer year);
}
