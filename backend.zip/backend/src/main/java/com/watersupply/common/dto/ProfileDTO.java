package com.watersupply.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProfileDTO {
    private Long id;
    private String email;
    private String username;
    private String name;
    private String phone;
    private String role;
    private String address;
    private String profileImagePath;
    private boolean hasProfileImage;
}
