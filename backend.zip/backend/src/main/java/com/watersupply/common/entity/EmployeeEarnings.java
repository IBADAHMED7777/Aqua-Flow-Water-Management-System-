package com.watersupply.common.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "employee_earnings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeEarnings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private User employee;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "delivery_schedule_id", nullable = false)
    private DeliverySchedule deliverySchedule;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "salary_payment_id")
    private SalaryPayment salaryPayment;

    @Column(nullable = false)
    private Double earningAmount;

    @Column(nullable = false)
    private Boolean paid = false;

    private LocalDateTime paidAt;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime earnedAt;

    @Column(nullable = false)
    private Boolean immutable = false; // Immutable completed delivery records
}
