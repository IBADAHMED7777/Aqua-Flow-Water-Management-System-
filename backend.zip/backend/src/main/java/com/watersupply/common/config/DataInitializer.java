package com.watersupply.common.config;

import com.watersupply.common.entity.*;
import com.watersupply.common.repository.*;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Component
public class DataInitializer {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostConstruct
    public void init() {
        // Initialize Admin if not exists
        if (!userRepository.existsByEmail("admin@gmail.com")) {
            logger.info("Seeding Admin User: admin@gmail.com");
            createUser("admin@gmail.com", "1234", "System Administrator", "0000000000", "Main Office, Islamabad",
                    User.Role.ADMIN, null);
        } else {
            logger.info("Admin user 'admin@gmail.com' already exists.");
        }

        // Create basic products for testing
        if (productRepository.count() == 0) {
            createProduct("20L Water Bottle", "Pure drinking water in 20-liter bottle", 150.0, 100,
                    Product.Category.BOTTLE);
            createProduct("Water Tanker (1000L)", "Water delivery tanker service", 5000.0, 10, Product.Category.TANKER);
        } else {
            logger.info("Products already seeded, skipping.");
        }

        logger.info("Clean database initialization completed successfully");
    }

    private User createUser(String email, String password, String name, String phone, String address, User.Role role,
            Double paymentRate) {
        User user = new User();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(password));
        user.setName(name);
        user.setPhone(phone);
        user.setAddress(address);
        user.setRole(role);
        user.setActive(true);
        user.setPaymentRate(paymentRate);
        return userRepository.save(user);
    }

    private void createProduct(String name, String description, Double price, Integer stock,
            Product.Category category) {
        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        product.setStockQuantity(stock);
        product.setCategory(category);
        product.setActive(true);
        productRepository.save(product);
    }
}
