package com.watersupply.common.repository;

import com.watersupply.common.entity.DeliverySchedule;
import com.watersupply.common.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface DeliveryScheduleRepository extends JpaRepository<DeliverySchedule, Long> {

    List<DeliverySchedule> findByEmployee(User employee);

    List<DeliverySchedule> findByEmployeeAndScheduledDate(User employee, LocalDate date);

    List<DeliverySchedule> findByStatus(DeliverySchedule.ScheduleStatus status);

    long countByEmployeeAndStatus(User employee, DeliverySchedule.ScheduleStatus status);

    List<DeliverySchedule> findByEmployeeIdAndScheduledDate(Long employeeId, LocalDate date);

    List<DeliverySchedule> findByEmployeeIdOrderByScheduledDateDesc(Long employeeId);

    long countByEmployeeIdAndStatus(Long employeeId, DeliverySchedule.ScheduleStatus status);

    long countByEmployeeIdAndStatusAndScheduledDate(Long employeeId, DeliverySchedule.ScheduleStatus status,
            LocalDate date);
}
