import api from './api';

export const adminService = {
    // Stats & Analytics
    fetchDashboardStats: async () => {
        const response = await api.get('/admin/dashboard/stats');
        return response.data.data;
    },

    fetchRevenueTrend: async () => {
        const response = await api.get('/admin/dashboard/revenue-trend');
        return response.data.data;
    },

    fetchActivityLogs: async () => {
        const response = await api.get('/admin/dashboard/activity-logs');
        return response.data.data;
    },

    // Data Lists with Pagination
    fetchUsers: async (page = 0, size = 10, sort = 'createdAt', direction = 'desc') => {
        const response = await api.get(`/admin/users?page=${page}&size=${size}&sort=${sort}&direction=${direction}`);
        return response.data.data;
    },

    fetchEmployees: async (page = 0, size = 10) => {
        const response = await api.get(`/admin/employees?page=${page}&size=${size}`);
        return response.data.data;
    },

    fetchOrders: async (page = 0, size = 10, sort = 'placedAt', direction = 'desc') => {
        const response = await api.get(`/admin/orders?page=${page}&size=${size}&sort=${sort}&direction=${direction}`);
        return response.data.data;
    },

    fetchComplaints: async (page = 0, size = 10, sort = 'createdAt', direction = 'desc') => {
        const response = await api.get(`/admin/complaints?page=${page}&size=${size}&sort=${sort}&direction=${direction}`);
        return response.data.data;
    },

    fetchCustomerComplaints: async (page = 0, size = 10, sort = 'createdAt', direction = 'desc') => {
        const response = await api.get(`/admin/complaints/customer?page=${page}&size=${size}&sort=${sort}&direction=${direction}`);
        return response.data.data;
    },

    fetchEmployeeComplaints: async (page = 0, size = 10, sort = 'createdAt', direction = 'desc') => {
        const response = await api.get(`/admin/complaints/employee?page=${page}&size=${size}&sort=${sort}&direction=${direction}`);
        return response.data.data;
    },

    fetchBills: async (page = 0, size = 10, sort = 'issueDate', direction = 'desc') => {
        const response = await api.get(`/admin/bills?page=${page}&size=${size}&sort=${sort}&direction=${direction}`);
        return response.data.data;
    },

    fetchBillPdf: async (id) => {
        const response = await api.get(`/admin/bills/${id}/pdf`, { responseType: 'blob' });
        return response.data;
    },

    fetchOrderInvoicePdf: async (id) => {
        const response = await api.get(`/admin/orders/${id}/invoice-pdf`, { responseType: 'blob' });
        return response.data;
    },

    // Operations
    generateMonthlyBills: async (month, year) => {
        const response = await api.post(`/admin/billing/generate?month=${month}&year=${year}`);
        return response.data;
    },

    assignSchedule: async (data) => {
        const response = await api.post('/admin/schedules/assign', data);
        return response.data;
    },

    updateOrderStatus: async (id, status) => {
        const response = await api.put(`/admin/orders/${id}/status?status=${status}`);
        return response.data;
    },

    assignComplaint: async (id, employeeId) => {
        const response = await api.put(`/admin/complaints/${id}/assign?employeeId=${employeeId}`);
        return response.data;
    },

    resolveComplaint: async (id, notes) => {
        const response = await api.put(`/admin/complaints/${id}/resolve?notes=${encodeURIComponent(notes)}`);
        return response.data;
    },

    markComplaintInProgress: async (id) => {
        const response = await api.put(`/admin/complaints/${id}/in-progress`);
        return response.data;
    },

    sendMessageToComplainant: async (id, message) => {
        const response = await api.post(`/admin/complaints/${id}/message?message=${encodeURIComponent(message)}`);
        return response.data;
    },

    // Product / Inventory Management
    getProducts: async () => {
        const response = await api.get('/admin/products');
        return response.data;
    },

    createProduct: async (productData, imageFile) => {
        const formData = new FormData();
        formData.append('product', new Blob([JSON.stringify(productData)], { type: 'application/json' }));
        if (imageFile) {
            formData.append('image', imageFile);
        }
        const response = await api.post('/admin/products', formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
        });
        return response.data;
    },

    updateProduct: async (id, productData, imageFile) => {
        const formData = new FormData();
        formData.append('product', new Blob([JSON.stringify(productData)], { type: 'application/json' }));
        if (imageFile) {
            formData.append('image', imageFile);
        }
        const response = await api.put(`/admin/products/${id}`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
        });
        return response.data;
    },

    deleteProduct: async (id) => {
        await api.delete(`/admin/products/${id}`);
    },

    // Salary Management
    getUnpaidEarnings: async (employeeId) => {
        const response = await api.get(`/admin/employees/${employeeId}/unpaid-earnings`);
        return response.data;
    },

    paySalary: async (data) => {
        const response = await api.post('/admin/employees/pay-salary', data);
        return response.data;
    }
};
