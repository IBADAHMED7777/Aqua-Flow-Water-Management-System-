import api from './api';

export const employeeService = {
    // Dashboard Stats
    getDashboardStats: async () => {
        const response = await api.get('/employee/dashboard/summary');
        return response.data.data;
    },

    // Schedules
    getMySchedules: async () => {
        const response = await api.get('/employee/schedules');
        // Sort explicitly if needed, though backend handles it
        return response.data.data;
    },

    startDelivery: async (scheduleId) => {
        const response = await api.post(`/employee/schedules/${scheduleId}/start`);
        return response.data.data;
    },

    completeDelivery: async (scheduleId) => {
        const response = await api.post(`/employee/schedules/${scheduleId}/complete`);
        return response.data.data;
    },

    submitMeterReading: async (scheduleId, reading) => {
        const response = await api.post(`/employee/schedules/${scheduleId}/meter-reading`, null, {
            params: { reading }
        });
        return response.data.data;
    },

    // Earnings
    getMyEarnings: async () => {
        const response = await api.get('/employee/earnings');
        return response.data.data;
    },

    // Issues
    reportIssue: async (type, description, location) => {
        const response = await api.post('/employee/issues', { type, description, location });
        return response.data.data;
    },

    getMyComplaints: async () => {
        const response = await api.get('/employee/issues');
        return response.data.data;
    },

    getMySalaries: async () => {
        const response = await api.get('/employee/salaries');
        return response.data.data;
    },

    downloadSalarySlip: async (id) => {
        const response = await api.get(`/employee/salaries/${id}/pdf`, {
            responseType: 'blob'
        });
        return response.data;
    },

    // Notifications
    getUnreadNotifications: async () => {
        const response = await api.get('/notifications/unread');
        return response.data;
    },

    markNotificationAsRead: async (id) => {
        const response = await api.put(`/notifications/${id}/read`);
        return response.data;
    }
};
