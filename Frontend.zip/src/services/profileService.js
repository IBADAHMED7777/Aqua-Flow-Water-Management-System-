import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

// Create axios instance with default config
const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Add auth token to requests
apiClient.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

const profileService = {
    // Get current user profile
    getProfile: async () => {
        const response = await apiClient.get('/profile');
        return response.data;
    },

    // Update profile (username, name, phone)
    updateProfile: async (profileData) => {
        const response = await apiClient.put('/profile/update', profileData);
        return response.data;
    },

    // Change password
    changePassword: async (passwordData) => {
        const response = await apiClient.post('/profile/change-password', passwordData);
        return response.data;
    },

    // Upload profile image
    uploadProfileImage: async (file) => {
        const formData = new FormData();
        formData.append('file', file);

        const response = await apiClient.post('/profile/upload-image', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        return response.data;
    },

    // Get profile image URL
    getProfileImageUrl: (path) => {
        if (!path) return null;
        return `${API_BASE_URL.replace('/api', '')}/uploads/${path}`;
    },

    // Delete profile image
    deleteProfileImage: async () => {
        const response = await apiClient.delete('/profile/image');
        return response.data;
    },
};

export default profileService;