import React, { useState, useEffect } from 'react';
import { Loader } from 'lucide-react';

const AuthGuard = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        // Mock Authentication Check
        const checkAuth = () => {
            // In a real app, you would check localStorage token or API
            // const token = localStorage.getItem('token');
            const token = true; // Simulating logged in

            setTimeout(() => {
                if (token) {
                    setIsAuthenticated(true);
                } else {
                    // Redirect logic would go here
                    // window.location.href = '/login';
                    setIsAuthenticated(false);
                }
                setIsLoading(false);
            }, 500); // Small delay to show looking up auth
        };

        checkAuth();
    }, []);

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center">
                    <Loader className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-2" />
                    <p className="text-sm text-gray-500 font-medium">Verifying Credentials...</p>
                </div>
            </div>
        );
    }

    if (!isAuthenticated) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="bg-white p-8 rounded-xl shadow-lg max-w-sm w-full text-center border border-gray-100">
                    <h2 className="text-xl font-bold text-gray-800 mb-2">Access Denied</h2>
                    <p className="text-gray-500 mb-6">You do not have permission to view this dashboard.</p>
                    <button
                        onClick={() => window.location.reload()}
                        className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition w-full font-medium"
                    >
                        Return to Login
                    </button>
                </div>
            </div>
        );
    }

    return <>{children}</>;
};

export default AuthGuard;
