import React from 'react';
import { CheckCircle, XCircle, AlertCircle, Info, X } from 'lucide-react';

const StatusModal = ({
    isOpen,
    onClose,
    onConfirm,
    title,
    message,
    type = 'success',
    confirmText = 'Confirm',
    cancelText = 'Cancel',
    showCancel = false,
    showInput = false,
    onInputChange,
    inputValue = '',
    placeholder = 'Type your message here...'
}) => {
    if (!isOpen) return null;

    const iconMap = {
        success: <CheckCircle className="text-green-500" size={48} />,
        error: <XCircle className="text-red-500" size={48} />,
        warning: <AlertCircle className="text-orange-500" size={48} />,
        info: <Info className="text-blue-500" size={48} />,
        confirm: <AlertCircle className="text-blue-500" size={48} />
    };

    const bgMap = {
        success: 'bg-green-500/10 border-green-500/20',
        error: 'bg-red-500/10 border-red-500/20',
        warning: 'bg-orange-500/10 border-orange-500/20',
        info: 'bg-blue-500/10 border-blue-500/20',
        confirm: 'bg-blue-500/10 border-blue-500/20'
    };

    return (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl animate-in fade-in zoom-in duration-300 relative">
                <button
                    onClick={onClose}
                    className="absolute right-4 top-4 text-gray-400 hover:text-gray-600 transition"
                >
                    <X size={20} />
                </button>

                <div className={`w-20 h-20 ${bgMap[type]} rounded-full flex items-center justify-center mx-auto mb-6 border`}>
                    {iconMap[type]}
                </div>

                <h2 className="text-2xl font-bold text-gray-800 mb-2">{title}</h2>
                <p className="text-gray-500 mb-4">{message}</p>

                {showInput && (
                    <div className="mb-6">
                        <textarea
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all min-h-[120px] resize-none text-gray-700 placeholder:text-gray-400"
                            placeholder={placeholder}
                            value={inputValue}
                            onChange={(e) => onInputChange(e.target.value)}
                            autoFocus
                        />
                    </div>
                )}

                <div className="flex gap-3">
                    {showCancel && (
                        <button
                            onClick={onClose}
                            className="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition"
                        >
                            {cancelText}
                        </button>
                    )}
                    <button
                        onClick={onConfirm || onClose}
                        className={`flex-1 py-3 ${type === 'error' ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'} text-white font-bold rounded-2xl transition shadow-xl shadow-blue-500/20`}
                    >
                        {confirmText}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default StatusModal;
