import React, { useState, useEffect, useRef } from 'react';
import { Menu, Search, Settings, LogOut, User, ChevronDown } from 'lucide-react';
import ProfileModal from './ProfileModal';
import OrderDetailsModal from './OrderDetailsModal';
import SalaryCelebrationModal from './SalaryCelebrationModal';
import profileService from '../services/profileService';
import api from '../services/api';

const Header = ({ isSidebarOpen, setIsSidebarOpen, activeTab }) => {
    const [isProfileOpen, setIsProfileOpen] = useState(false);
    const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
    const [userProfile, setUserProfile] = useState(null);
    const [selectedOrder, setSelectedOrder] = useState(null);
    const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

    // Celebration state
    const [isCelebrationOpen, setIsCelebrationOpen] = useState(false);
    const [celebrationAmount, setCelebrationAmount] = useState(0);

    const dropdownRef = useRef(null);

    useEffect(() => {
        loadUserProfile();
    }, []);

    const loadUserProfile = async () => {
        try {
            const profile = await profileService.getProfile();
            setUserProfile(profile);
        } catch (error) {
            console.error('Failed to load profile:', error);
        }
    };

    const handleProfileUpdate = () => {
        loadUserProfile();
        window.dispatchEvent(new Event('profileUpdated'));
    };

    const getTitle = () => {
        switch (activeTab) {
            case 'dashboard': return 'Dashboard Overview';
            case 'customers': return 'Customer Management';
            case 'employees': return 'Employee Directory';
            case 'inventory': return 'Inventory Management';
            case 'orders': return 'Order Management';
            case 'billing':
            case 'bills': return 'Billing Records';
            case 'complaints': return 'Complaint Center';
            case 'products': return 'Order Water';
            case 'earnings': return 'Salary & Earnings'; // Updated title
            default: return 'Admin Portal';
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('userRole');
        window.location.href = '/';
    };

    const getUserInitials = () => {
        if (!userProfile) return 'AD';
        const name = userProfile.name || userProfile.email || 'Admin';
        return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    };

    const getProfileImageUrl = () => {
        if (userProfile && userProfile.profileImagePath) {
            return profileService.getProfileImageUrl(userProfile.profileImagePath);
        }
        return null;
    };

    return (
        <>
            <ProfileModal
                isOpen={isProfileModalOpen}
                onClose={() => setIsProfileModalOpen(false)}
                onProfileUpdate={handleProfileUpdate}
                userRole="ADMIN"
            />

            <OrderDetailsModal
                isOpen={isOrderModalOpen}
                onClose={() => setIsOrderModalOpen(false)}
                order={selectedOrder}
            />

            <SalaryCelebrationModal
                isOpen={isCelebrationOpen}
                onClose={() => setIsCelebrationOpen(false)}
                salaryAmount={celebrationAmount}
            />

            <header className="bg-white border-b border-gray-100 px-6 py-4 sticky top-0 z-30 shadow-sm/50 backdrop-blur-xl bg-white/80">
                <div className="flex items-center justify-between max-w-[1920px] mx-auto">

                    {/* Left: Mobile Toggle & Title */}
                    <div className="flex items-center gap-6">
                        <button
                            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                            className="p-2 -ml-2 text-gray-500 hover:bg-gray-100 rounded-xl transition lg:hidden"
                        >
                            <Menu className="w-6 h-6" />
                        </button>
                        <div>
                            <h2 className="text-xl font-bold text-gray-800 tracking-tight">
                                {getTitle()}
                            </h2>
                            <p className="text-xs text-gray-400 font-medium hidden sm:block mt-0.5">
                                {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                            </p>
                        </div>
                    </div>

                    {/* Right: Actions */}
                    <div className="flex items-center gap-3 sm:gap-4">

                        {/* Search (Desktop) */}
                        <div className="relative hidden md:block">
                            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                            <input
                                type="text"
                                placeholder="Type to search..."
                                className="pl-10 pr-4 py-2.5 bg-gray-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-blue-500/20 focus:bg-white transition-all w-64 hover:bg-gray-100"
                            />
                        </div>


                        {/* Profile */}
                        <div className="relative">
                            <button
                                onClick={() => {
                                    setIsProfileOpen(!isProfileOpen);
                                }}
                                className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-xl hover:bg-gray-50 transition-all border border-transparent hover:border-gray-200"
                            >
                                {getProfileImageUrl() ? (
                                    <img
                                        src={getProfileImageUrl()}
                                        alt="Profile"
                                        className="w-9 h-9 rounded-full object-cover ring-2 ring-white shadow-sm"
                                    />
                                ) : (
                                    <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-sm font-bold text-white shadow-sm ring-2 ring-white">
                                        {getUserInitials()}
                                    </div>
                                )}
                                <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${isProfileOpen ? 'rotate-180' : ''}`} />
                            </button>

                            {isProfileOpen && (
                                <div className="absolute right-0 mt-3 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden animate-in fade-in slide-in-from-top-2 origin-top-right">
                                    <div className="p-4 border-b border-gray-50">
                                        <p className="font-bold text-gray-900">{userProfile?.username || 'Set Username'}</p>
                                        <p className="text-sm text-gray-600 mt-0.5">{userProfile?.name || 'Admin User'}</p>
                                        <p className="text-xs text-gray-500 mt-0.5">{userProfile?.email || 'Loading...'}</p>
                                    </div>
                                    <div className="p-2 space-y-1">
                                        <button
                                            onClick={() => {
                                                setIsProfileOpen(false);
                                                setIsProfileModalOpen(true);
                                            }}
                                            className="flex items-center gap-3 w-full px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-lg transition-colors"
                                        >
                                            <User size={16} />
                                            Profile
                                        </button>
                                        <div className="h-px bg-gray-50 my-1"></div>
                                        <button
                                            onClick={handleLogout}
                                            className="flex items-center gap-3 w-full px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                        >
                                            <LogOut size={16} />
                                            Log Out
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Click outside to close dropdowns */}
                {isProfileOpen && (
                    <div
                        className="fixed inset-0 z-20"
                        onClick={() => {
                            setIsProfileOpen(false);
                        }}
                    ></div>
                )}
            </header>
        </>
    );
};

export default Header;