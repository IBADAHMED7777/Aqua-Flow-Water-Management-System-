import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { X, Gift } from 'lucide-react';

const SalaryCelebrationModal = ({ isOpen, onClose, salaryAmount }) => {
    const [audio] = useState(new Audio('/sounds/celebration.mp3'));

    useEffect(() => {
        if (isOpen) {
            // Play sound
            audio.play().catch(e => console.log("Audio play failed", e));

            // Fire confetti
            const duration = 5 * 1000;
            const animationEnd = Date.now() + duration;
            const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

            const randomInRange = (min, max) => Math.random() * (max - min) + min;

            const interval = setInterval(function () {
                const timeLeft = animationEnd - Date.now();

                if (timeLeft <= 0) {
                    return clearInterval(interval);
                }

                const particleCount = 50 * (timeLeft / duration);
                // since particles fall down, start a bit higher than random
                confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
                confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
            }, 250);

            return () => {
                clearInterval(interval);
                audio.pause();
                audio.currentTime = 0;
            };
        }
    }, [isOpen, audio]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden relative transform transition-all scale-100 animate-in zoom-in-95 duration-300 border-4 border-yellow-400">
                {/* Close button */}
                <button
                    onClick={onClose}
                    className="absolute top-4 right-4 p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors z-10"
                >
                    <X className="w-5 h-5 text-gray-500" />
                </button>

                {/* Content */}
                <div className="p-8 text-center bg-gradient-to-b from-yellow-50 to-white">
                    <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner animate-bounce">
                        <Gift className="w-10 h-10 text-yellow-600" />
                    </div>

                    <h2 className="text-3xl font-black text-gray-900 mb-2">Congratulations!</h2>
                    <p className="text-lg text-gray-600 font-medium mb-6">
                        The admin appreciates your hard work.
                    </p>

                    <div className="bg-green-50 rounded-2xl p-6 border border-green-100 mb-6 transform rotate-1 hover:rotate-0 transition-transform duration-300 shadow-sm">
                        <p className="text-sm font-semibold text-green-600 uppercase tracking-wider mb-1">Total Salary Received</p>
                        <p className="text-4xl font-black text-green-700">
                            PKR {salaryAmount?.toLocaleString()}
                        </p>
                    </div>

                    <p className="text-sm text-gray-400 italic">
                        "Your dedication drives our success!"
                    </p>
                </div>

                {/* Footer action */}
                <div className="p-4 bg-gray-50 border-t border-gray-100">
                    <button
                        onClick={onClose}
                        className="w-full py-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold rounded-xl shadow-lg shadow-orange-200 hover:shadow-orange-300 transform hover:-translate-y-0.5 transition-all"
                    >
                        Awesome, Thanks!
                    </button>
                </div>
            </div>
        </div>
    );
};

export default SalaryCelebrationModal;
