import React, { useState } from 'react';
import { CreditCard, Lock, CheckCircle, ShieldCheck } from 'lucide-react';

const PaymentGatewayModal = ({ isOpen, onClose, onPaymentSuccess, amount }) => {
    const [cardName, setCardName] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [expiry, setExpiry] = useState('');
    const [cvv, setCvv] = useState('');
    const [processing, setProcessing] = useState(false);
    const [step, setStep] = useState('input'); // input, processing, success

    if (!isOpen) return null;

    const handleSubmit = (e) => {
        e.preventDefault();
        setProcessing(true);
        setStep('processing');

        // Simulate API call
        setTimeout(() => {
            setStep('success');
            setTimeout(() => {
                onPaymentSuccess();
            }, 1500);
        }, 2000);
    };

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => !processing && onClose()} />

            <div className="relative bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-200">

                {step === 'processing' && (
                    <div className="p-12 flex flex-col items-center justify-center text-center">
                        <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-6"></div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">Processing Payment</h3>
                        <p className="text-gray-500">Securely communicating with bank...</p>
                    </div>
                )}

                {step === 'success' && (
                    <div className="p-12 flex flex-col items-center justify-center text-center">
                        <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6 animate-in zoom-in duration-300">
                            <CheckCircle size={32} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">Payment Successful</h3>
                        <p className="text-gray-500">Your transaction has been approved.</p>
                    </div>
                )}

                {step === 'input' && (
                    <form onSubmit={handleSubmit}>
                        <div className="bg-gray-900 p-6 text-white overflow-hidden relative">
                            <div className="absolute top-0 right-0 p-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
                            <div className="relative z-10">
                                <div className="flex justify-between items-start mb-6">
                                    <ShieldCheck className="w-8 h-8 text-blue-400" />
                                    <span className="font-mono text-xl font-bold">VISA</span>
                                </div>
                                <div className="mb-4">
                                    <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Card Number</p>
                                    <p className="font-mono text-xl tracking-widest">{cardNumber || '•••• •••• •••• ••••'}</p>
                                </div>
                                <div className="flex justify-between">
                                    <div>
                                        <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Card Holder</p>
                                        <p className="font-medium uppercase">{cardName || 'YOUR NAME'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Expires</p>
                                        <p className="font-mono">{expiry || 'MM/YY'}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="p-6 space-y-4">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-lg font-bold text-gray-800">Payment Details</h2>
                                <span className="text-lg font-bold text-blue-600">PKR {amount.toFixed(2)}</span>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Card Number</label>
                                <div className="relative">
                                    <CreditCard className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                    <input
                                        type="text"
                                        placeholder="0000 0000 0000 0000"
                                        className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all font-mono"
                                        value={cardNumber}
                                        onChange={(e) => setCardNumber(e.target.value)}
                                        maxLength="19"
                                        required
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Card Holder Name</label>
                                <input
                                    type="text"
                                    placeholder="JOHN DOE"
                                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all uppercase"
                                    value={cardName}
                                    onChange={(e) => setCardName(e.target.value)}
                                    required
                                />
                            </div>

                            <div className="flex gap-4">
                                <div className="flex-1">
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Expiry Date</label>
                                    <input
                                        type="text"
                                        placeholder="MM/YY"
                                        className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all font-mono"
                                        value={expiry}
                                        onChange={(e) => setExpiry(e.target.value)}
                                        maxLength="5"
                                        required
                                    />
                                </div>
                                <div className="w-1/3">
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">CVV</label>
                                    <div className="relative">
                                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                        <input
                                            type="text"
                                            placeholder="123"
                                            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all font-mono"
                                            value={cvv}
                                            onChange={(e) => setCvv(e.target.value)}
                                            maxLength="3"
                                            required
                                        />
                                    </div>
                                </div>
                            </div>

                            <button
                                type="submit"
                                className="w-full py-3.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition shadow-lg shadow-blue-200 mt-2 flex items-center justify-center gap-2"
                            >
                                Pay PKR {amount.toFixed(2)}
                            </button>

                            <button
                                type="button"
                                onClick={onClose}
                                className="w-full py-2 text-sm font-medium text-gray-500 hover:text-gray-700 transition"
                            >
                                Cancel Transaction
                            </button>
                        </div>
                    </form>
                )}
            </div>
        </div>
    );
};

export default PaymentGatewayModal;
