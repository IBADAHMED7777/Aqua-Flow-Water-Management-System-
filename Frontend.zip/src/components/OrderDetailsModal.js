import React from 'react';
import { X, Package, Calendar, User, MapPin, DollarSign } from 'lucide-react';

const OrderDetailsModal = ({ isOpen, onClose, order }) => {
    if (!isOpen || !order) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
                {/* Header */}
                <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                    <div>
                        <h3 className="text-xl font-bold text-gray-800">Order #{order.id}</h3>
                        <p className="text-sm text-gray-500 mt-1">
                            Placed on {new Date(order.placedAt).toLocaleDateString()} at {new Date(order.placedAt).toLocaleTimeString()}
                        </p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400 hover:text-gray-600">
                        <X size={20} />
                    </button>
                </div>

                {/* Body */}
                <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
                    {/* Status Badge */}
                    <div className="flex justify-between items-center bg-blue-50 p-4 rounded-xl border border-blue-100">
                        <span className="text-sm font-semibold text-blue-700 uppercase tracking-wide">Status</span>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold border ${order.status === 'DELIVERED' ? 'bg-green-100 text-green-700 border-green-200' :
                                order.status === 'ASSIGNED' ? 'bg-yellow-100 text-yellow-700 border-yellow-200' :
                                    order.status === 'OUT_FOR_DELIVERY' ? 'bg-purple-100 text-purple-700 border-purple-200' :
                                        'bg-blue-100 text-blue-700 border-blue-200'
                            }`}>
                            {order.status.replace(/_/g, ' ')}
                        </span>
                    </div>

                    {/* Customer Info */}
                    <div className="flex gap-4">
                        <div className="p-3 bg-gray-50 rounded-xl h-fit">
                            <User size={20} className="text-gray-500" />
                        </div>
                        <div>
                            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Customer</p>
                            <p className="font-semibold text-gray-800">{order.user?.name}</p>
                            <p className="text-sm text-gray-500">{order.user?.email}</p>
                            <p className="text-sm text-gray-500">{order.user?.phoneNumber}</p>
                        </div>
                    </div>

                    {/* Delivery Info */}
                    {order.assignedEmployee && (
                        <div className="flex gap-4">
                            <div className="p-3 bg-gray-50 rounded-xl h-fit">
                                <Package size={20} className="text-gray-500" />
                            </div>
                            <div>
                                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Assigned Agent</p>
                                <p className="font-semibold text-gray-800">{order.assignedEmployee.name}</p>
                                {order.deliveredAt && (
                                    <p className="text-sm text-green-600 font-medium mt-1">
                                        Delivered at {new Date(order.deliveredAt).toLocaleString()}
                                    </p>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Items List */}
                    <div>
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Order Items</p>
                        <div className="bg-gray-50 rounded-xl border border-gray-100 overflow-hidden">
                            {order.items?.map((item, index) => (
                                <div key={index} className="flex justify-between items-center p-4 border-b border-gray-100 last:border-0 hover:bg-white transition-colors">
                                    <div className="flex items-center gap-3">
                                        <span className="font-bold text-gray-400 w-6 text-center">{item.quantity}x</span>
                                        <span className="font-medium text-gray-700">{item.product?.name}</span>
                                    </div>
                                    <span className="font-semibold text-gray-800">PKR {item.subtotal}</span>
                                </div>
                            ))}
                            <div className="p-4 bg-gray-100/50 flex justify-between items-center">
                                <span className="font-bold text-gray-600">Total Amount</span>
                                <span className="text-lg font-bold text-blue-600">PKR {order.totalAmount}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="p-4 border-t border-gray-100 bg-gray-50/50 flex justify-end">
                    <button onClick={onClose} className="px-6 py-2 bg-white border border-gray-200 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors shadow-sm">
                        Close
                    </button>
                </div>
            </div>
        </div>
    );
};

export default OrderDetailsModal;
