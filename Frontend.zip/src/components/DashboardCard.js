import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

const DashboardCard = ({ title, value, icon, trend, color = 'blue' }) => {

    const getColorStyles = (c) => {
        switch (c) {
            case 'blue': return {
                bg: 'bg-gradient-to-br from-indigo-500 to-blue-600',
                shadow: 'shadow-blue-200',
                iconBg: 'bg-white/20',
                text: 'text-indigo-50'
            };
            case 'cyan': return {
                bg: 'bg-gradient-to-br from-cyan-400 to-blue-500',
                shadow: 'shadow-cyan-200',
                iconBg: 'bg-white/20',
                text: 'text-cyan-50'
            };
            case 'green': return {
                bg: 'bg-gradient-to-br from-emerald-400 to-teal-600',
                shadow: 'shadow-emerald-200',
                iconBg: 'bg-white/20',
                text: 'text-emerald-50'
            };
            case 'purple': return {
                bg: 'bg-gradient-to-br from-violet-400 to-purple-600',
                shadow: 'shadow-violet-200',
                iconBg: 'bg-white/20',
                text: 'text-violet-50'
            };
            case 'orange': return {
                bg: 'bg-gradient-to-br from-orange-400 to-red-500',
                shadow: 'shadow-orange-200',
                iconBg: 'bg-white/20',
                text: 'text-orange-50'
            };
            case 'yellow': return {
                bg: 'bg-gradient-to-br from-amber-400 to-orange-500',
                shadow: 'shadow-amber-200',
                iconBg: 'bg-white/20',
                text: 'text-amber-50'
            };
            default: return {
                bg: 'bg-gradient-to-br from-gray-500 to-gray-600',
                shadow: 'shadow-gray-200',
                iconBg: 'bg-white/20',
                text: 'text-gray-100'
            };
        }
    };

    const styles = getColorStyles(color);

    return (
        <div className={`${styles.bg} rounded-2xl p-6 shadow-lg ${styles.shadow} hover:shadow-xl hover:translate-y-[-2px] transition-all group relative overflow-hidden`}>
            {/* Decorative Background Circle */}
            <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>

            <div className="relative z-10">
                <div className="flex justify-between items-start mb-4">
                    <div className={`p-3 ${styles.iconBg} text-white rounded-xl backdrop-blur-sm shadow-inner`}>
                        <span className="text-xl">{icon}</span>
                    </div>
                    {trend && (
                        <span className={`flex items-center text-xs font-bold px-2.5 py-1 rounded-full backdrop-blur-sm ${trend.positive ? 'bg-white/20 text-white' : 'bg-red-500/20 text-red-50'}`}>
                            {trend.positive ? <ArrowUpRight size={14} className="mr-1" /> : <ArrowDownRight size={14} className="mr-1" />}
                            {trend.value}
                        </span>
                    )}
                </div>

                <h3 className="text-3xl font-extrabold text-white mb-1 tracking-tight">{value}</h3>
                <p className={`text-sm font-semibold ${styles.text} opacity-90`}>{title}</p>
            </div>
        </div>
    );
};

export default DashboardCard;
