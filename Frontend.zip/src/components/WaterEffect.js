import React, { useEffect, useRef, useState } from 'react';
import './WaterEffect.css';

const WaterEffect = () => {
    const canvasRef = useRef(null);
    const [ripples, setRipples] = useState([]);
    const trail = useRef([]); // Stores {x, y, age}
    const maxTrailAge = 40;

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        let animationId;

        const resizeCanvas = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };

        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();

        const handleMouseMove = (e) => {
            trail.current.push({ x: e.clientX, y: e.clientY, age: 0 });
        };

        const handleClick = (e) => {
            const newRipple = {
                id: Date.now(),
                x: e.clientX,
                y: e.clientY
            };
            setRipples(prev => [...prev, newRipple]);
            setTimeout(() => {
                setRipples(prev => prev.filter(r => r.id !== newRipple.id));
            }, 800);
        };

        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mousedown', handleClick);

        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            if (trail.current.length > 2) {
                for (let i = 1; i < trail.current.length; i++) {
                    const p1 = trail.current[i - 1];
                    const p2 = trail.current[i];

                    // Update age
                    p1.age++;

                    const life = 1 - (p1.age / maxTrailAge);
                    if (life <= 0) {
                        trail.current.splice(i - 1, 1);
                        i--;
                        continue;
                    }

                    // 1. "Frosty" Glass Base (Thick, very faint, with glow)
                    ctx.beginPath();
                    ctx.lineCap = 'round';
                    ctx.lineJoin = 'round';
                    ctx.moveTo(p1.x, p1.y);
                    ctx.lineTo(p2.x, p2.y);
                    ctx.lineWidth = life * 22;
                    ctx.shadowBlur = 10;
                    ctx.shadowColor = `rgba(255, 255, 255, ${life * 0.2})`;
                    ctx.strokeStyle = `rgba(255, 255, 255, ${life * 0.08})`; // Frosty white
                    ctx.stroke();

                    // 2. Liquid Core (Medium, glassy cyan)
                    ctx.beginPath();
                    ctx.shadowBlur = 0; // Reset for core
                    ctx.moveTo(p1.x, p1.y);
                    ctx.lineTo(p2.x, p2.y);
                    ctx.lineWidth = life * 10;
                    ctx.strokeStyle = `rgba(186, 230, 253, ${life * 0.15})`; // Glassy cyan
                    ctx.stroke();

                    // 3. Specular Highlight (Sharp, bright white "rim")
                    ctx.beginPath();
                    ctx.moveTo(p1.x, p1.y);
                    ctx.lineTo(p2.x, p2.y);
                    ctx.lineWidth = life * 3;
                    ctx.strokeStyle = `rgba(255, 255, 255, ${life * 0.5})`; // Bright white edge
                    ctx.stroke();
                }
            }

            animationId = requestAnimationFrame(animate);
        };

        animate();

        return () => {
            window.removeEventListener('resize', resizeCanvas);
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mousedown', handleClick);
            cancelAnimationFrame(animationId);
        };
    }, []);

    return (
        <div className="water-effect-container">
            <canvas ref={canvasRef} />
            {ripples.map(ripple => (
                <div
                    key={ripple.id}
                    className="ripple"
                    style={{ left: ripple.x, top: ripple.y }}
                />
            ))}
        </div>
    );
};

export default WaterEffect;