import React from 'react';
import { X, ShoppingCart, Check } from 'lucide-react';

const OrderConfirmationModal = ({ isOpen, onClose, onConfirm, cart, products, total }) => {
    const [selectedMethod, setSelectedMethod] = React.useState('CASH_ON_DELIVERY');
    const [address, setAddress] = React.useState('');

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
            {/* Backdrop */}
            <div
                className="absolute inset-0 bg-black/50 backdrop-blur-sm"
                onClick={onClose}
            />

            {/* Modal */}
            <div className="relative bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200">
                {/* Header */}
                <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 text-white">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                                <ShoppingCart className="w-6 h-6" />
                            </div>
                            <div>
                                <h2 className="text-xl font-bold">Confirm Your Order</h2>
                                <p className="text-blue-100 text-sm">Review your items before placing order</p>
                            </div>
                        </div>
                        <button
                            onClick={onClose}
                            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/20 transition"
                        >
                            <X className="w-5 h-5" />
                        </button>
                    </div>
                </div>

                {/* Content */}
                <div className="p-6 max-h-[400px] overflow-y-auto">
                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">Order Summary</h3>

                    <div className="space-y-3">
                        {Object.entries(cart).map(([productId, quantity]) => {
                            const product = products.find(p => p.id === parseInt(productId));
                            if (!product) return null;

                            return (
                                <div key={productId} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                                    <div className="flex items-center gap-3 flex-1">
                                        {product.imagePath ? (
                                            <img
                                                src={`http://localhost:8080/uploads/${product.imagePath}`}
                                                alt={product.name}
                                                className="w-12 h-12 rounded-lg object-cover border border-gray-200"
                                            />
                                        ) : (
                                            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                                <ShoppingCart className="w-6 h-6 text-blue-600" />
                                            </div>
                                        )}
                                        <div className="flex-1">
                                            <p className="font-semibold text-gray-800">{product.name}</p>
                                            <p className="text-xs text-gray-500">PKR {product.price} × {quantity}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-bold text-gray-900">PKR {(product.price * quantity).toFixed(2)}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    {/* Total */}
                    <div className="mt-6 pt-4 border-t border-gray-200">
                        <div className="flex items-center justify-between">
                            <span className="text-lg font-bold text-gray-800">Total Amount</span>
                            <span className="text-2xl font-bold text-blue-600">PKR {total.toFixed(2)}</span>
                        </div>
                    </div>
                </div>

                {/* Payment Method Selection */}
                <div className="px-6 pb-2">
                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-3">Payment Method</h3>
                    <div className="space-y-2">
                        <div className="relative">
                            <select
                                value={selectedMethod}
                                onChange={(e) => setSelectedMethod(e.target.value)}
                                className="w-full p-3 pl-4 pr-10 border border-gray-200 rounded-xl appearance-none bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all font-medium text-gray-700 cursor-pointer"
                            >
                                <option value="CASH_ON_DELIVERY">Cash on Delivery</option>
                                <option value="CARD_PAYMENT">Card Payment</option>
                                <option value="ONLINE_PAYMENT">Online Payment</option>
                            </select>
                            <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-gray-500">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Address Override */}
                <div className="px-6 pb-2">
                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-3">Delivery Address</h3>
                    <textarea
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="Enter delivery address (leave empty to use profile address)"
                        className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all font-medium text-gray-700 resize-none"
                        rows="2"
                    />
                </div>

                {/* Footer */}
                <div className="p-6 bg-gray-50 border-t border-gray-200 flex gap-3">
                    <button
                        onClick={onClose}
                        className="flex-1 px-6 py-3 bg-white border-2 border-gray-200 text-gray-700 font-bold rounded-xl hover:bg-gray-100 transition"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={() => onConfirm(selectedMethod, address)}
                        className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold rounded-xl hover:from-blue-700 hover:to-blue-800 transition shadow-lg shadow-blue-200 flex items-center justify-center gap-2"
                    >
                        {selectedMethod === 'ONLINE_PAYMENT' ? (
                            <>Proceed to Payment <Check className="w-5 h-5" /></>
                        ) : (
                            <>Confirm Order <Check className="w-5 h-5" /></>
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default OrderConfirmationModal;
