import React, { useState, useEffect } from 'react';
import Sidebar from '../../components/Sidebar';
import Header from '../../components/Header';
import DashboardCard from '../../components/DashboardCard';
import api from '../../services/api';
import OrderWater from './components/OrderWater';
import BillingTab from './components/BillingTab';
import ComplaintsTab from './components/ComplaintsTab';
import confetti from 'canvas-confetti';
import { Loader, ShoppingBag, AlertTriangle, Package, Clock, AlertCircle, CreditCard } from 'lucide-react';
import StatusModal from '../../components/StatusModal';

const UserDashboard = () => {
    const [orders, setOrders] = useState([]);
    const [complaints, setComplaints] = useState([]);
    const [unpaidAmount, setUnpaidAmount] = useState(0);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('dashboard');
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    // Modal states for cancellation
    const [cancelModal, setCancelModal] = useState({
        showConfirm: false,
        showSuccess: false,
        showCashback: false,
        targetOrder: null
    });

    useEffect(() => {
        // Auto-run repair on load to ensure DB is consistent
        api.get('/public/repair-db').catch(e => console.log('Auto-repair skipped', e));
        fetchDashboardData();
    }, []);

    const handleRepair = async () => {
        if (!window.confirm("Run system diagnosis and repair?")) return;
        try {
            await api.get('/public/repair-db');
            alert("System repair completed. Reloading...");
            window.location.reload();
        } catch (e) {
            alert("Repair failed. Please contact support.");
        }
    };

    const fetchDashboardData = async () => {
        try {
            const [ordersRes, complaintsRes, unpaidRes] = await Promise.all([
                api.get('/user/orders'),
                api.get('/user/complaints'),
                api.get('/user/bills/total-unpaid')
            ]);

            setOrders(ordersRes.data.data || []);
            setComplaints(complaintsRes.data.data || []);
            setUnpaidAmount(unpaidRes.data.data || 0);
        } catch (error) {
            console.error('Error fetching dashboard data:', error);
        } finally {
            setLoading(false);
        }
    };

    const handlePayBill = async (orderId) => {
        if (!window.confirm("Confirm payment for this order?")) return;
        try {
            await api.post(`/user/bills/${orderId}/pay`);
            alert("Payment successful!");
            fetchDashboardData();
        } catch (error) {
            alert("Payment failed: " + (error.response?.data?.message || error.message));
        }
    };

    const handleCancelOrder = (order) => {
        setCancelModal({
            ...cancelModal,
            showConfirm: true,
            targetOrder: order
        });
    };

    const confirmCancelOrder = async () => {
        const order = cancelModal.targetOrder;
        if (!order) return;

        try {
            await api.post(`/user/orders/${order.id}/cancel`);

            // Show cancellation success modal
            setCancelModal(prev => ({
                ...prev,
                showConfirm: false,
                showSuccess: true
            }));

            fetchDashboardData();
        } catch (error) {
            alert("Cancellation failed: " + (error.response?.data?.message || error.message));
            setCancelModal(prev => ({ ...prev, showConfirm: false }));
        }
    };

    const handleCancelSuccessClose = () => {
        const order = cancelModal.targetOrder;
        if (order?.paymentMethod === 'ONLINE_PAYMENT') {
            // Success Effects for Cashback
            const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3');
            audio.play().catch(e => console.log('Audio play failed', e));

            confetti({
                particleCount: 150,
                spread: 70,
                origin: { y: 0.6 }
            });

            setCancelModal(prev => ({
                ...prev,
                showSuccess: false,
                showCashback: true
            }));
        } else {
            setCancelModal({
                showConfirm: false,
                showSuccess: false,
                showCashback: false,
                targetOrder: null
            });
        }
    };

    const recentOrders = orders.slice(0, 5);
    const pendingOrders = orders.filter(o => o.status === 'PLACED').length;
    const openComplaints = complaints.filter(c => c.status === 'OPEN').length;

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center space-y-4">
                <Loader className="w-12 h-12 text-blue-600 animate-spin" />
                <p className="text-gray-500 font-medium">Loading Dashboard...</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 flex font-sans">
            <Sidebar
                role="USER"
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                isOpen={isSidebarOpen}
                setIsSidebarOpen={setIsSidebarOpen}
            />

            <div className="flex-1 flex flex-col transition-all duration-300 min-w-0 h-screen overflow-hidden">
                <Header
                    isSidebarOpen={isSidebarOpen}
                    setIsSidebarOpen={setIsSidebarOpen}
                    activeTab={activeTab}
                />

                <div className="bg-red-50 p-2 text-center text-xs text-red-600 font-bold cursor-pointer hover:bg-red-100" onClick={handleRepair}>
                    Click here if you are facing issues (System Repair)
                </div>

                <main className="flex-1 overflow-y-auto p-4 md:p-8 max-w-[1920px] mx-auto w-full">
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                        {activeTab === 'products' && <OrderWater />}

                        {activeTab === 'dashboard' && (
                            <>
                                <div className="mb-8">
                                    <h1 className="text-2xl font-bold text-gray-800">My Dashboard</h1>
                                    <p className="text-gray-500">Welcome to Aqua Flow Customer Portal</p>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                                    <DashboardCard
                                        title="Total Orders"
                                        value={orders.length}
                                        icon={<ShoppingBag size={24} />}
                                        color="blue"
                                    />
                                    <DashboardCard
                                        title="Pending Orders"
                                        value={pendingOrders}
                                        icon={<Clock size={24} />}
                                        color="cyan"
                                    />
                                    <DashboardCard
                                        title="Open Complaints"
                                        value={openComplaints}
                                        icon={<AlertCircle size={24} />}
                                        color="orange"
                                    />
                                    <DashboardCard
                                        title="Unpaid Bills"
                                        value={`PKR ${unpaidAmount.toFixed(2)}`}
                                        icon={<CreditCard size={24} />}
                                        color="green"
                                    />
                                </div>

                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                                        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                                            <ShoppingBag className="w-5 h-5 text-blue-500" />
                                            Recent Orders
                                        </h3>
                                        {recentOrders.length === 0 ? (
                                            <p className="text-center py-10 text-gray-400">
                                                No orders yet. Start ordering water products!
                                            </p>
                                        ) : (
                                            <div className="overflow-x-auto">
                                                <table className="w-full">
                                                    <thead>
                                                        <tr className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-gray-100">
                                                            <th className="pb-3 pl-2">ID</th>
                                                            <th className="pb-3">Date</th>
                                                            <th className="pb-3">Amount</th>
                                                            <th className="pb-3">Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="divide-y divide-gray-50">
                                                        {recentOrders.map((order) => (
                                                            <tr key={order.id} className="text-sm text-gray-700 hover:bg-gray-50">
                                                                <td className="py-3 pl-2 font-medium">#{order.id}</td>
                                                                <td className="py-3">{new Date(order.placedAt).toLocaleDateString()}</td>
                                                                <td className="py-3">PKR {order.totalAmount.toFixed(2)}</td>
                                                                <td className="py-3">
                                                                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${order.status === 'DELIVERED' ? 'bg-green-100 text-green-700' :
                                                                        order.status === 'ASSIGNED' ? 'bg-yellow-100 text-yellow-700' :
                                                                            'bg-blue-100 text-blue-700'
                                                                        }`}>
                                                                        {order.status}
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        )}
                                    </div>

                                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                                        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                                            <AlertTriangle className="w-5 h-5 text-purple-500" />
                                            Recent Complaints
                                        </h3>
                                        {complaints.length === 0 ? (
                                            <p className="text-center py-10 text-gray-400">
                                                No complaints submitted
                                            </p>
                                        ) : (
                                            <div className="space-y-3">
                                                {complaints.slice(0, 5).map((complaint) => (
                                                    <div key={complaint.id} className="p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition">
                                                        <div className="flex justify-between items-start mb-2">
                                                            <span className="font-semibold text-sm text-gray-800">{complaint.type.replace('_', ' ')}</span>
                                                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${complaint.status === 'RESOLVED' ? 'bg-green-200 text-green-800' :
                                                                complaint.status === 'IN_PROGRESS' ? 'bg-yellow-200 text-yellow-800' :
                                                                    'bg-red-200 text-red-800'
                                                                }`}>
                                                                {complaint.status}
                                                            </span>
                                                        </div>
                                                        <p className="text-xs text-gray-500 line-clamp-2">
                                                            {complaint.description}
                                                        </p>
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </>
                        )}
                        {activeTab === 'orders' && (
                            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                                <div className="mb-6 flex justify-between items-center">
                                    <h2 className="text-xl font-bold text-gray-800">My Orders</h2>
                                    <button onClick={fetchDashboardData} className="text-sm text-blue-600 hover:text-blue-700 font-medium">Refresh</button>
                                </div>
                                {orders.length === 0 ? (
                                    <div className="text-center py-20">
                                        <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                                        <p className="text-gray-500">You haven't placed any orders yet.</p>
                                    </div>
                                ) : (
                                    <div className="overflow-x-auto">
                                        <table className="w-full">
                                            <thead>
                                                <tr className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-gray-100">
                                                    <th className="pb-4 pl-4">Order ID</th>
                                                    <th className="pb-4">Date</th>
                                                    <th className="pb-4">Product Details</th>
                                                    <th className="pb-4">Total Amount</th>
                                                    <th className="pb-4">Payment</th>
                                                    <th className="pb-4">Status</th>
                                                    <th className="pb-4">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-gray-50">
                                                {orders.map((order) => (
                                                    <tr key={order.id} className="text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                                        <td className="py-4 pl-4 font-bold">#{order.id}</td>
                                                        <td className="py-4">{new Date(order.placedAt).toLocaleString()}</td>
                                                        <td className="py-4">
                                                            <div className="max-w-xs">
                                                                {order.items?.map((item, idx) => (
                                                                    <div key={idx} className="text-xs text-gray-600 truncate">
                                                                        {item.product?.name} (x{item.quantity})
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </td>
                                                        <td className="py-4 font-semibold text-gray-900">PKR {order.totalAmount.toFixed(2)}</td>
                                                        <td className="py-4">
                                                            <span className="text-xs font-semibold text-gray-600 bg-gray-100 px-2 py-1 rounded">
                                                                {(order.paymentMethod || 'COD').replace(/_/g, ' ')}
                                                            </span>
                                                        </td>
                                                        <td className="py-4">
                                                            {order.status !== 'CANCELLED' ? (
                                                                <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${order.status === 'DELIVERED' ? 'bg-green-100 text-green-700' :
                                                                    order.status === 'ASSIGNED' ? 'bg-yellow-100 text-yellow-700' :
                                                                        'bg-blue-100 text-blue-700'
                                                                    }`}>
                                                                    {order.status}
                                                                </span>
                                                            ) : null}
                                                        </td>
                                                        <td className="py-4 pl-4 space-x-2">
                                                            {order.status === 'PLACED' && (
                                                                <button
                                                                    onClick={() => handleCancelOrder(order)}
                                                                    className="px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-lg hover:bg-red-700 transition shadow-sm"
                                                                >
                                                                    Cancel
                                                                </button>
                                                            )}
                                                            {order.status === 'DELIVERED' && !order.paid && (
                                                                <button
                                                                    onClick={() => handlePayBill(order.id)}
                                                                    className="px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700 transition shadow-sm"
                                                                >
                                                                    Pay Now
                                                                </button>
                                                            )}
                                                            {order.paid && order.status !== 'CANCELLED' && (
                                                                <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-bold rounded">Paid</span>
                                                            )}
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </div>
                        )}

                        {activeTab === 'bills' && <BillingTab />}

                        {activeTab === 'complaints' && <ComplaintsTab />}
                    </div>
                </main>
            </div>

            {/* Order Cancellation Modals */}
            <StatusModal
                isOpen={cancelModal.showConfirm}
                onClose={() => setCancelModal(prev => ({ ...prev, showConfirm: false }))}
                onConfirm={confirmCancelOrder}
                title="Cancel Order?"
                message={`Are you sure you want to cancel order #${cancelModal.targetOrder?.id}?`}
                type="confirm"
                confirmText="Yes, Cancel"
                cancelText="No, Keep"
                showCancel={true}
            />

            <StatusModal
                isOpen={cancelModal.showSuccess}
                onClose={handleCancelSuccessClose}
                title="Order Canceled"
                message="Your order has been canceled successfully."
                type="success"
                confirmText="Ok"
            />

            <StatusModal
                isOpen={cancelModal.showCashback}
                onClose={() => setCancelModal({ ...cancelModal, showCashback: false, targetOrder: null })}
                title="Cashback Received!"
                message={`A refund of PKR ${cancelModal.targetOrder?.totalAmount.toFixed(2)} has been credited to your account.`}
                type="success"
                confirmText="Great!"
            />
        </div>
    );
};

export default UserDashboard;