import React, { useState, useEffect } from 'react';
import { ShoppingCart, Plus, Minus, Info, Check } from 'lucide-react';
import api from '../../../services/api';
import OrderConfirmationModal from '../../../components/OrderConfirmationModal';
import PaymentGatewayModal from '../../../components/PaymentGatewayModal';
import StatusModal from '../../../components/StatusModal';
import confetti from 'canvas-confetti';

const OrderWater = () => {
    const [products, setProducts] = useState([]);
    const [cart, setCart] = useState({});
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [notification, setNotification] = useState(null);
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [pendingPaymentMethod, setPendingPaymentMethod] = useState(null);
    const [showSuccessModal, setShowSuccessModal] = useState(false);

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            const response = await api.get('/products'); // Maps to /api/products
            setProducts(response.data);
        } catch (error) {
            console.error('Failed to load products', error);
        } finally {
            setLoading(false);
        }
    };

    const addToCart = (product) => {
        setCart(prev => ({
            ...prev,
            [product.id]: (prev[product.id] || 0) + 1
        }));
    };

    const removeFromCart = (product) => {
        setCart(prev => {
            const newCount = (prev[product.id] || 0) - 1;
            if (newCount <= 0) {
                const newCart = { ...prev };
                delete newCart[product.id];
                return newCart;
            }
            return { ...prev, [product.id]: newCount };
        });
    };

    const getCartTotal = () => {
        return Object.entries(cart).reduce((total, [id, qty]) => {
            const product = products.find(p => p.id === parseInt(id));
            return total + (product ? product.price * qty : 0);
        }, 0);
    };

    const handleCheckout = () => {
        if (Object.keys(cart).length === 0) return;
        setShowConfirmModal(true);
    };

    const handleConfirmOrder = (paymentMethod, address) => {
        if (paymentMethod === 'ONLINE_PAYMENT') {
            // If online payment, close confirm modal and open payment gateway
            // Ask for explicit confirmation via window.confirm as requested
            if (window.confirm("Do you want to proceed to secure online payment?")) {
                setPendingPaymentMethod(paymentMethod);
                setShowConfirmModal(false);
                setShowPaymentModal(true);
            }
        } else {
            // For COD or Card on Delivery, place order immediately
            placeOrder(paymentMethod, address);
        }
    };

    const handlePaymentSuccess = () => {
        setShowPaymentModal(false);
        placeOrder('ONLINE_PAYMENT');
    };

    const placeOrder = async (paymentMethod, address) => {
        setShowConfirmModal(false);
        setSubmitting(true);
        try {
            const items = Object.entries(cart).map(([id, qty]) => ({
                productId: parseInt(id),
                quantity: qty
            }));

            await api.post('/user/orders', { items, paymentMethod, address });

            setCart({});

            // Success Effects
            const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3');
            audio.play().catch(e => console.log('Audio play failed', e));

            confetti({
                particleCount: 150,
                spread: 70,
                origin: { y: 0.6 }
            });

            setShowSuccessModal(true);
        } catch (error) {
            console.error('Order failed', error);
            alert('Failed to place order. ' + (error.response?.data?.message || ''));
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) return <div className="p-8 text-center text-gray-500">Loading products...</div>;

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800">Order Water</h1>
                    <p className="text-gray-500">Select products to add to your delivery</p>
                </div>
                {/* Cart Summary (Desktop) */}
                {Object.keys(cart).length > 0 && (
                    <div className="hidden md:flex items-center gap-4 bg-white p-3 rounded-xl border border-blue-100 shadow-sm">
                        <div className="text-right">
                            <p className="text-xs text-gray-500 uppercase font-bold">Total</p>
                            <p className="text-lg font-bold text-blue-600">PKR {getCartTotal().toFixed(2)}</p>
                        </div>
                        <button
                            onClick={handleCheckout}
                            disabled={submitting}
                            className="px-6 py-2.5 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition shadow-lg shadow-blue-200 disabled:opacity-70"
                        >
                            {submitting ? 'Placing Order...' : 'Place Order'}
                        </button>
                    </div>
                )}
            </div>

            {notification && (
                <div className="bg-green-100 border border-green-200 text-green-800 p-4 rounded-xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                    <Check className="w-5 h-5 bg-green-200 rounded-full p-0.5" />
                    {notification}
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.filter(p => p.active).map(product => {
                    const quantityInCart = cart[product.id] || 0;
                    return (
                        <div key={product.id} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all group">
                            <div className="flex justify-between items-start mb-4">
                                <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-all overflow-hidden border border-blue-100">
                                    {product.imagePath ? (
                                        <img src={`http://localhost:8080/uploads/${product.imagePath}`} alt={product.name} className="w-full h-full object-cover" />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center">
                                            <ShoppingCart size={24} />
                                        </div>
                                    )}
                                </div>
                                <span className="px-2.5 py-1 bg-gray-100 text-gray-600 text-xs font-bold rounded-lg uppercase">
                                    {product.category}
                                </span>
                            </div>

                            <h3 className="text-xl font-bold text-gray-800 mb-1">{product.name}</h3>
                            <p className="text-gray-500 text-sm mb-4 line-clamp-2 h-10">{product.description}</p>

                            <div className="flex items-end justify-between">
                                <div>
                                    <p className="text-xs text-gray-400 font-medium uppercase">Price</p>
                                    <p className="text-2xl font-bold text-gray-900">PKR {product.price}</p>
                                </div>

                                {quantityInCart === 0 ? (
                                    <button
                                        onClick={() => addToCart(product)}
                                        className="p-2 bg-gray-50 text-blue-600 rounded-lg hover:bg-blue-600 hover:text-white transition-all font-medium flex items-center gap-2"
                                    >
                                        <Plus size={18} />
                                        Add
                                    </button>
                                ) : (
                                    <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-1">
                                        <button onClick={() => removeFromCart(product)} className="p-1 hover:bg-white rounded shadow-sm text-gray-600"><Minus size={16} /></button>
                                        <span className="font-bold text-gray-800 w-4 text-center">{quantityInCart}</span>
                                        <button onClick={() => addToCart(product)} className="p-1 hover:bg-white rounded shadow-sm text-blue-600"><Plus size={16} /></button>
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Mobile Cart Sticky Footer */}
            {Object.keys(cart).length > 0 && (
                <div className="md:hidden fixed bottom-6 left-4 right-4 bg-gray-900 text-white p-4 rounded-2xl shadow-xl flex items-center justify-between z-50 animate-in slide-in-from-bottom-4">
                    <div>
                        <p className="text-xs text-gray-400 uppercase font-bold">Total</p>
                        <p className="text-lg font-bold">PKR {getCartTotal().toFixed(2)}</p>
                    </div>
                    <button
                        onClick={handleCheckout}
                        disabled={submitting}
                        className="px-6 py-2 bg-blue-500 text-white font-bold rounded-xl"
                    >
                        Checkout
                    </button>
                </div>
            )}

            <OrderConfirmationModal
                isOpen={showConfirmModal}
                onClose={() => setShowConfirmModal(false)}
                onConfirm={handleConfirmOrder}
                cart={cart}
                products={products}
                total={getCartTotal()}
            />

            <PaymentGatewayModal
                isOpen={showPaymentModal}
                onClose={() => setShowPaymentModal(false)}
                onPaymentSuccess={handlePaymentSuccess}
                amount={getCartTotal()}
            />

            <StatusModal
                isOpen={showSuccessModal}
                onClose={() => setShowSuccessModal(false)}
                title="Order Placed Successfully!"
                message="Your water delivery has been scheduled. Check 'My Orders' for tracking."
                type="success"
                confirmText="Great!"
            />
        </div>
    );
};

export default OrderWater;