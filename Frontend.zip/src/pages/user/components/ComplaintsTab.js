import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, AlertCircle, CheckCircle, Clock, Loader } from 'lucide-react';
import api from '../../../services/api';
import StatusModal from '../../../components/StatusModal';

const ComplaintsTab = () => {
    const [complaints, setComplaints] = useState([]);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [notification, setNotification] = useState(null);

    const [formData, setFormData] = useState({
        type: 'WATER_SHORTAGE',
        subject: '',
        description: ''
    });

    const [modal, setModal] = useState({
        showConfirm: false,
        showSuccess: false,
        error: ''
    });

    useEffect(() => {
        fetchComplaints();
    }, []);

    const fetchComplaints = async () => {
        try {
            const response = await api.get('/user/complaints');
            setComplaints(response.data.data || []);
        } catch (error) {
            console.error('Failed to load complaints', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.subject.trim()) {
            alert('Please enter a complaint subject');
            return;
        }

        if (!formData.description.trim()) {
            setModal(prev => ({ ...prev, error: 'Please enter a complaint description' }));
            return;
        }

        setModal(prev => ({ ...prev, showConfirm: true }));
    };

    const confirmSubmit = async () => {
        setModal(prev => ({ ...prev, showConfirm: false }));
        setSubmitting(true);
        try {
            await api.post('/user/complaints', formData);

            setModal(prev => ({ ...prev, showSuccess: true }));

            // Reset form
            setFormData({
                type: 'WATER_SHORTAGE',
                subject: '',
                description: ''
            });

            // Refresh complaints list
            fetchComplaints();
        } catch (error) {
            console.error('Failed to submit complaint', error);
            setModal(prev => ({ ...prev, error: error.response?.data?.message || 'Failed to submit complaint' }));
        } finally {
            setSubmitting(false);
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'RESOLVED':
                return 'bg-green-100 text-green-700';
            case 'IN_PROGRESS':
                return 'bg-yellow-100 text-yellow-700';
            case 'OPEN':
            default:
                return 'bg-red-100 text-red-700';
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'RESOLVED':
                return <CheckCircle className="w-4 h-4" />;
            case 'IN_PROGRESS':
                return <Clock className="w-4 h-4" />;
            case 'OPEN':
            default:
                return <AlertCircle className="w-4 h-4" />;
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-20">
                <Loader className="w-8 h-8 text-blue-600 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div>
                <h1 className="text-2xl font-bold text-gray-800">Complaints & Support</h1>
                <p className="text-gray-500">Submit and track your complaints</p>
            </div>


            {/* Complaint Submission Form */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                    <MessageSquare className="w-5 h-5 text-blue-600" />
                    <h2 className="text-lg font-bold text-gray-800">Submit a Complaint</h2>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Complaint Type */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Complaint Type
                        </label>
                        <select
                            value={formData.type}
                            onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50"
                        >
                            <option value="WATER_SHORTAGE">Water Shortage</option>
                            <option value="LEAKAGE">Leakage</option>
                            <option value="BILLING_ISSUE">Billing Issue</option>
                            <option value="QUALITY_ISSUE">Quality Issue</option>
                            <option value="OTHER">Other</option>
                        </select>
                    </div>

                    {/* Subject */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Subject
                        </label>
                        <input
                            type="text"
                            value={formData.subject}
                            onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                            placeholder="Brief summary of your complaint"
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50"
                        />
                    </div>

                    {/* Description */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Description
                        </label>
                        <textarea
                            value={formData.description}
                            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                            placeholder="Describe your complaint in detail..."
                            rows={5}
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-gray-50"
                        />
                    </div>

                    {/* Submit Button */}
                    <button
                        type="submit"
                        disabled={submitting}
                        className="w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold rounded-xl hover:from-blue-700 hover:to-blue-800 transition shadow-lg shadow-blue-200 disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                        {submitting ? (
                            <>
                                <Loader className="w-5 h-5 animate-spin" />
                                Submitting...
                            </>
                        ) : (
                            <>
                                <Send className="w-5 h-5" />
                                Submit Complaint
                            </>
                        )}
                    </button>
                </form>
            </div>

            {/* Submitted Complaints */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-bold text-gray-800">Your Complaints</h2>
                    <button
                        onClick={fetchComplaints}
                        className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                    >
                        Refresh
                    </button>
                </div>

                {complaints.length === 0 ? (
                    <div className="text-center py-10">
                        <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                        <p className="text-gray-500">No complaints submitted yet</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {complaints.map((complaint) => (
                            <div
                                key={complaint.id}
                                className="p-5 bg-gray-50 rounded-2xl border border-gray-100 hover:border-blue-200 transition-all"
                            >
                                <div className="flex items-start justify-between mb-3">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-2">
                                            <span className="text-sm font-bold text-blue-600 uppercase tracking-wider">
                                                {complaint.type?.replace('_', ' ')}
                                            </span>
                                            <span className="text-xs text-gray-400">
                                                #{complaint.id}
                                            </span>
                                        </div>
                                        <p className="text-xs text-gray-500">
                                            Submitted on {new Date(complaint.createdAt).toLocaleDateString()} at {new Date(complaint.createdAt).toLocaleTimeString()}
                                        </p>
                                    </div>
                                    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-bold uppercase ${getStatusColor(complaint.status)}`}>
                                        {getStatusIcon(complaint.status)}
                                        {complaint.status}
                                    </span>
                                </div>

                                <div className="mb-3">
                                    <p className="text-sm font-semibold text-gray-700 mb-1">Description:</p>
                                    <p className="text-sm text-gray-600 leading-relaxed">
                                        {complaint.description}
                                    </p>
                                </div>

                                {complaint.resolutionNotes && (
                                    <div className="mt-4 pt-4 border-t border-gray-200">
                                        <p className="text-xs font-bold text-gray-500 uppercase mb-2 flex items-center gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600" />
                                            Admin Response:
                                        </p>
                                        <p className="text-sm text-green-700 bg-green-50 p-3 rounded-lg">
                                            {complaint.resolutionNotes}
                                        </p>
                                    </div>
                                )}

                                {complaint.status === 'IN_PROGRESS' && complaint.inProgressAt && (
                                    <div className="mt-3 text-xs text-gray-500">
                                        <Clock className="w-3 h-3 inline mr-1" />
                                        In progress since {new Date(complaint.inProgressAt).toLocaleDateString()}
                                    </div>
                                )}

                                {complaint.status === 'RESOLVED' && complaint.resolvedAt && (
                                    <div className="mt-3 text-xs text-green-600">
                                        <CheckCircle className="w-3 h-3 inline mr-1" />
                                        Resolved on {new Date(complaint.resolvedAt).toLocaleDateString()}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>

            <StatusModal
                isOpen={modal.showConfirm}
                onClose={() => setModal(prev => ({ ...prev, showConfirm: false }))}
                onConfirm={confirmSubmit}
                title="Submit Complaint?"
                message="Are you sure you want to submit this complaint? Our team will review it shortly."
                type="confirm"
                confirmText="Yes, Submit"
                cancelText="Review Again"
                showCancel={true}
            />

            <StatusModal
                isOpen={modal.showSuccess}
                onClose={() => setModal(prev => ({ ...prev, showSuccess: false }))}
                title="Complaint Submitted"
                message="Your complaint has been received. You can track its status in the history below."
                type="success"
                confirmText="Ok"
            />

            <StatusModal
                isOpen={!!modal.error}
                onClose={() => setModal(prev => ({ ...prev, error: '' }))}
                title="Error"
                message={modal.error}
                type="error"
                confirmText="Understood"
            />
        </div >
    );
};

export default ComplaintsTab;
