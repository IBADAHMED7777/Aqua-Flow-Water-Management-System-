import React, { useState, useEffect } from 'react';
import { CreditCard, Check, Clock, AlertCircle, Loader, Download } from 'lucide-react';
import api from '../../../services/api';
import StatusModal from '../../../components/StatusModal';

const BillingTab = () => {
    const [bills, setBills] = useState([]);
    const [loading, setLoading] = useState(true);
    const [payingBill, setPayingBill] = useState(null);
    const [modal, setModal] = useState({
        showSuccess: false,
        error: ''
    });

    useEffect(() => {
        fetchBills();
    }, []);

    const fetchBills = async () => {
        try {
            const response = await api.get('/user/bills');
            setBills(response.data.data || []);
        } catch (error) {
            console.error('Failed to load bills', error);
        } finally {
            setLoading(false);
        }
    };

    const handlePayment = async (billId) => {
        setPayingBill(billId);
        try {
            await api.post(`/user/bills/${billId}/pay`);
            setModal(prev => ({ ...prev, showSuccess: true }));
            fetchBills(); // Refresh the bills list
        } catch (error) {
            console.error('Payment failed', error);
            setModal(prev => ({ ...prev, error: error.response?.data?.message || 'Payment failed' }));
        } finally {
            setPayingBill(null);
        }
    };

    const downloadInvoice = async (orderId) => {
        try {
            // Create a temporary anchor to trigger download
            const response = await api.get(`/user/orders/${orderId}/invoice`, { responseType: 'blob' });
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `invoice_${orderId}.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            console.error('Download failed', error);
            alert('Failed to download invoice');
        }
    };

    const unpaidBills = bills.filter(bill => !bill.paid);
    const paidBills = bills.filter(bill => bill.paid);

    if (loading) {
        return (
            <div className="flex items-center justify-center py-20">
                <Loader className="w-8 h-8 text-blue-600 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800">Billing & Payments</h1>
                    <p className="text-gray-500">Manage your order payments</p>
                </div>
                <button
                    onClick={fetchBills}
                    className="px-4 py-2 text-sm text-blue-600 hover:text-blue-700 font-medium"
                >
                    Refresh
                </button>
            </div>


            {/* Unpaid Bills Section */}
            {unpaidBills.length > 0 && (
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-orange-200">
                    <div className="flex items-center gap-2 mb-4">
                        <AlertCircle className="w-5 h-5 text-orange-600" />
                        <h2 className="text-lg font-bold text-gray-800">Unpaid Orders</h2>
                        <span className="ml-auto px-3 py-1 bg-orange-100 text-orange-700 text-sm font-bold rounded-full">
                            {unpaidBills.length} pending
                        </span>
                    </div>

                    <div className="space-y-3">
                        {unpaidBills.map((bill) => (
                            <div key={bill.id} className="p-4 bg-orange-50 border border-orange-100 rounded-xl hover:shadow-md transition-all">
                                <div className="flex items-start justify-between gap-4">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-2">
                                            <span className="font-bold text-gray-800">Order #{bill.id}</span>
                                            <span className="px-2 py-0.5 bg-orange-200 text-orange-800 text-xs font-bold rounded uppercase">
                                                Unpaid
                                            </span>
                                        </div>

                                        <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                                            <div>
                                                <p className="text-gray-500 text-xs">Order Date</p>
                                                <p className="font-medium text-gray-700">
                                                    {new Date(bill.placedAt).toLocaleDateString()}
                                                </p>
                                            </div>
                                            <div>
                                                <p className="text-gray-500 text-xs">Order Time</p>
                                                <p className="font-medium text-gray-700">
                                                    {new Date(bill.placedAt).toLocaleTimeString()}
                                                </p>
                                            </div>
                                        </div>

                                        {/* Order Items */}
                                        <div className="mb-3">
                                            <p className="text-gray-500 text-xs mb-1">Products</p>
                                            <div className="space-y-1">
                                                {bill.items?.map((item, idx) => (
                                                    <div key={idx} className="text-sm text-gray-700">
                                                        • {item.product?.name} × {item.quantity} - PKR {item.subtotal?.toFixed(2)}
                                                    </div>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="flex items-center justify-between pt-3 border-t border-orange-200">
                                            <div>
                                                <p className="text-xs text-gray-500">Total Amount</p>
                                                <p className="text-2xl font-bold text-gray-900">PKR {bill.totalAmount?.toFixed(2)}</p>
                                            </div>
                                            <button
                                                onClick={() => handlePayment(bill.id)}
                                                disabled={payingBill === bill.id || (bill.paymentMethod !== 'ONLINE_PAYMENT' && bill.status !== 'DELIVERED')}
                                                className={`px-6 py-2.5 font-bold rounded-xl shadow-lg flex items-center gap-2 transition disabled:opacity-50 ${bill.paymentMethod === 'ONLINE_PAYMENT'
                                                    ? 'bg-gradient-to-r from-green-600 to-green-700 text-white hover:from-green-700 hover:to-green-800 shadow-green-200'
                                                    : 'bg-gray-100 text-gray-400 cursor-not-allowed shadow-none'
                                                    }`}
                                            >
                                                {payingBill === bill.id ? (
                                                    <>
                                                        <Loader className="w-4 h-4 animate-spin" />
                                                        Processing...
                                                    </>
                                                ) : (
                                                    <>
                                                        <CreditCard className="w-4 h-4" />
                                                        {bill.paymentMethod === 'ONLINE_PAYMENT' ? 'Pay Now' : 'Pay on Delivery'}
                                                    </>
                                                )}
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Paid Bills Section */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                    <Check className="w-5 h-5 text-green-600" />
                    <h2 className="text-lg font-bold text-gray-800">Payment History</h2>
                </div>

                {paidBills.length === 0 ? (
                    <div className="text-center py-10">
                        <CreditCard className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                        <p className="text-gray-500">No payment history yet</p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-gray-100">
                                    <th className="pb-3 pl-2">Order ID</th>
                                    <th className="pb-3">Order Date</th>
                                    <th className="pb-3">Products</th>
                                    <th className="pb-3">Amount</th>
                                    <th className="pb-3">Paid On</th>
                                    <th className="pb-3">Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50">
                                {paidBills.map((bill) => (
                                    <tr key={bill.id} className="text-sm text-gray-700 hover:bg-gray-50">
                                        <td className="py-3 pl-2 font-bold">#{bill.id}</td>
                                        <td className="py-3">
                                            <div>
                                                <p className="font-medium">{new Date(bill.placedAt).toLocaleDateString()}</p>
                                                <p className="text-xs text-gray-500">{new Date(bill.placedAt).toLocaleTimeString()}</p>
                                            </div>
                                        </td>
                                        <td className="py-3">
                                            <div className="max-w-xs">
                                                {bill.items?.slice(0, 2).map((item, idx) => (
                                                    <div key={idx} className="text-xs text-gray-600 truncate">
                                                        {item.product?.name} (×{item.quantity})
                                                    </div>
                                                ))}
                                                {bill.items?.length > 2 && (
                                                    <div className="text-xs text-gray-400">+{bill.items.length - 2} more</div>
                                                )}
                                            </div>
                                        </td>
                                        <td className="py-3 font-semibold">PKR {bill.totalAmount?.toFixed(2)}</td>
                                        <td className="py-3 text-xs text-gray-500">
                                            {bill.paidAt ? new Date(bill.paidAt).toLocaleDateString() : 'N/A'}
                                        </td>
                                        <td className="py-3">
                                            <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full">
                                                <Check className="w-3 h-3" />
                                                Paid
                                            </span>
                                            <button
                                                onClick={() => downloadInvoice(bill.id)}
                                                className="flex items-center gap-1 text-xs text-blue-600 font-bold hover:underline mt-1"
                                            >
                                                <Download className="w-3 h-3" /> PDF
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* Empty State */}
            {bills.length === 0 && (
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                    <div className="text-center py-20">
                        <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-bold text-gray-800 mb-2">No Bills Yet</h3>
                        <p className="text-gray-500">Your order bills will appear here once you place orders.</p>
                    </div>
                </div>
            )}

            <StatusModal
                isOpen={modal.showSuccess}
                onClose={() => setModal(prev => ({ ...prev, showSuccess: false }))}
                title="Payment Successful"
                message="Your payment has been processed. You can download the invoice from your payment history."
                type="success"
                confirmText="Great!"
            />

            <StatusModal
                isOpen={!!modal.error}
                onClose={() => setModal(prev => ({ ...prev, error: '' }))}
                title="Payment Failed"
                message={modal.error}
                type="error"
                confirmText="Try Again"
            />
        </div>
    );
};

export default BillingTab;
