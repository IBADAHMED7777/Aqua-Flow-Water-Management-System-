import React, { useState, useEffect } from 'react';
import { AlertCircle, Clock, CheckCircle, Loader } from 'lucide-react';
import DashboardHome from './components/DashboardHome';
import Customers from './components/Customers';
import Employees from './components/Employees';
import Billing from './components/Billing';
import Complaints from './components/Complaints';
import Orders from './components/Orders';
import Inventory from './components/Inventory';
import ActivityLogs from './components/ActivityLogs';
import ErrorBoundary from '../../components/ErrorBoundary';
import AuthGuard from '../../components/AuthGuard';
import { adminService } from '../../services/adminService';
import Sidebar from '../../components/Sidebar';
import Header from '../../components/Header';

const MainDashboardLayout = () => {
    const [activeTab, setActiveTab] = useState('dashboard');
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    // Core Data State
    const [stats, setStats] = useState(null);
    const [revenueData, setRevenueData] = useState([]);
    const [employees, setEmployees] = useState([]);

    // UI State
    const [billGenerationStatus, setBillGenerationStatus] = useState('idle');
    const [selectedEmployee, setSelectedEmployee] = useState('');
    const [scheduleDate, setScheduleDate] = useState('');
    const [scheduleArea, setScheduleArea] = useState('');
    const [notification, setNotification] = useState(null);

    useEffect(() => {
        let isMounted = true;

        const loadData = async () => {
            try {
                const [statsData, revenue, empData] = await Promise.all([
                    adminService.fetchDashboardStats(),
                    adminService.fetchRevenueTrend(),
                    adminService.fetchEmployees(0, 100) // Fetch for dropdown
                ]);

                if (isMounted) {
                    setStats(statsData);
                    setRevenueData(revenue);
                    setEmployees(empData.content || []);
                    setIsLoading(false);
                }
            } catch (err) {
                if (isMounted) {
                    console.error("Dashboard load error", err);
                    setError("Failed to load dashboard data. Ensure backend is running.");
                    setIsLoading(false);
                }
            }
        };

        loadData();
        const intervalId = setInterval(loadData, 30000);

        const handleResize = () => {
            if (window.innerWidth < 1024) {
                setIsSidebarOpen(false);
            } else {
                setIsSidebarOpen(true);
            }
        };

        handleResize();
        window.addEventListener('resize', handleResize);

        return () => {
            isMounted = false;
            clearInterval(intervalId);
            window.removeEventListener('resize', handleResize);
        };
    }, []);

    const handleGenerateBills = async () => {
        setBillGenerationStatus('processing');
        showNotification('Bill generation started in background...', 'info');

        try {
            const date = new Date();
            await adminService.generateMonthlyBills(date.getMonth() + 1, date.getFullYear());
            setBillGenerationStatus('completed');
            showNotification('Monthly bills generation started successfully!', 'success');
            setTimeout(() => setBillGenerationStatus('idle'), 3000);
        } catch (err) {
            setBillGenerationStatus('idle');
            showNotification('Failed to generate bills', 'error');
        }
    };

    const handleAssignSchedule = async () => {
        if (!selectedEmployee || !scheduleDate || !scheduleArea) {
            showNotification('Please fill all fields', 'error');
            return;
        }

        showNotification('Assigning schedule...', 'info');
        try {
            await adminService.assignSchedule({
                employeeId: selectedEmployee,
                date: scheduleDate,
                area: scheduleArea
            });
            showNotification('Schedule assigned successfully', 'success');
            setSelectedEmployee('');
            setScheduleDate('');
            setScheduleArea('');
        } catch (err) {
            showNotification('Failed to assign schedule', 'error');
        }
    };

    const showNotification = (message, type) => {
        setNotification({ message, type });
        setTimeout(() => setNotification(null), 3000);
    };

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-PK', {
            style: 'currency',
            currency: 'PKR',
            minimumFractionDigits: 0
        }).format(amount);
    };

    const renderContent = () => {
        switch (activeTab) {
            case 'dashboard':
                return stats ? <DashboardHome
                    stats={stats}
                    revenueData={revenueData}
                    employees={employees}
                    selectedEmployee={selectedEmployee}
                    setSelectedEmployee={setSelectedEmployee}
                    billGenerationStatus={billGenerationStatus}
                    handleGenerateBills={handleGenerateBills}
                    scheduleDate={scheduleDate}
                    setScheduleDate={setScheduleDate}
                    scheduleArea={scheduleArea}
                    setScheduleArea={setScheduleArea}
                    handleAssignSchedule={handleAssignSchedule}
                    formatCurrency={formatCurrency}
                /> : null;
            case 'inventory':
                return <Inventory />;
            case 'orders':
                return <Orders showNotification={showNotification} />;
            case 'customers':
                return <Customers showNotification={showNotification} />;
            case 'employees':
                return <Employees showNotification={showNotification} />;
            case 'billing':
                return <Billing handleGenerateBills={handleGenerateBills} />;
            case 'complaints':
                return <Complaints showNotification={showNotification} />;
            case 'logs':
                return <ActivityLogs />;
            default:
                return stats ? <DashboardHome stats={stats} revenueData={revenueData} /> : null;
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center space-y-4">
                <Loader className="w-12 h-12 text-blue-600 animate-spin" />
                <p className="text-gray-500 font-medium">Loading Dashboard...</p>
            </div>
        );
    }

    if (error) {
        throw new Error(error); // Trigger Error Boundary
    }

    return (
        <div className="min-h-screen bg-gray-50 flex font-sans">
            <Sidebar
                role="ADMIN"
                isOpen={isSidebarOpen}
                setIsSidebarOpen={setIsSidebarOpen}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
            />

            <div className="flex-1 flex flex-col transition-all duration-300 min-w-0 h-screen overflow-hidden">
                <Header
                    isSidebarOpen={isSidebarOpen}
                    setIsSidebarOpen={setIsSidebarOpen}
                    activeTab={activeTab}
                />

                {/* Notification Toast */}
                {notification && (
                    <div className="fixed top-24 right-6 z-50 animate-in slide-in-from-right fade-in duration-300">
                        <div className={`px-5 py-4 rounded-xl shadow-xl flex items-center space-x-3 backdrop-blur-md border ${notification.type === 'success' ? 'bg-green-50/90 border-green-200 text-green-900' :
                            notification.type === 'error' ? 'bg-red-50/90 border-red-200 text-red-900' :
                                'bg-blue-50/90 border-blue-200 text-blue-900'
                            }`}>
                            <div className={`p-1.5 rounded-full ${notification.type === 'success' ? 'bg-green-100 text-green-600' :
                                notification.type === 'error' ? 'bg-red-100 text-red-600' :
                                    'bg-blue-100 text-blue-600'
                                }`}>
                                {notification.type === 'success' ? <CheckCircle className="w-4 h-4" /> :
                                    notification.type === 'error' ? <AlertCircle className="w-4 h-4" /> :
                                        <Clock className="w-4 h-4" />}
                            </div>
                            <div>
                                <h4 className="font-bold text-sm tracking-tight">{notification.type === 'success' ? 'Success' : notification.type === 'error' ? 'Error' : 'Info'}</h4>
                                <p className="text-xs font-medium opacity-90">{notification.message}</p>
                            </div>
                        </div>
                    </div>
                )}

                {/* Dashboard Content */}
                <main className="flex-1 overflow-y-auto p-4 md:p-8 max-w-[1920px] mx-auto w-full">
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                        {renderContent()}
                    </div>
                </main>
            </div>
        </div>
    );
};

const AdminDashboard = () => {
    return (
        <ErrorBoundary>
            <AuthGuard>
                <MainDashboardLayout />
            </AuthGuard>
        </ErrorBoundary>
    );
};

export default AdminDashboard;
