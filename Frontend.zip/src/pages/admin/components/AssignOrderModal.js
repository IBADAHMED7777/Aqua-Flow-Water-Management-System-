import React, { useState } from 'react';
import { X, User, Calendar, MapPin, Loader } from 'lucide-react';

const AssignOrderModal = ({ isOpen, onClose, order, employees, onAssign }) => {
    const [selectedEmployee, setSelectedEmployee] = useState('');
    const [scheduledDate, setScheduledDate] = useState(new Date().toISOString().split('T')[0]);
    const [routeInfo, setRouteInfo] = useState(order?.deliveryAddress || order?.user?.address || '');
    const [loading, setLoading] = useState(false);

    if (!isOpen) return null;

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!selectedEmployee || !scheduledDate) return;

        setLoading(true);
        try {
            await onAssign({
                orderId: order.id,
                employeeId: selectedEmployee,
                scheduledDate,
                routeInformation: routeInfo
            });
            onClose();
        } catch (error) {
            console.error('Assignment failed:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md border border-gray-100 overflow-hidden transform transition-all">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6 text-white flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-bold">Assign Delivery</h2>
                        <p className="text-blue-100 text-sm mt-0.5">Order #{order?.id}</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                        <X size={20} />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-5">
                    <div className="bg-blue-50/50 rounded-xl p-4 border border-blue-100">
                        <div className="flex justify-between items-center text-sm">
                            <span className="text-blue-700 font-medium">Customer</span>
                            <span className="text-gray-900 font-bold">{order?.user?.name}</span>
                        </div>
                        <div className="flex justify-between items-center text-sm mt-1">
                            <span className="text-blue-700 font-medium">Total Amount</span>
                            <span className="text-gray-900 font-bold">PKR {order?.totalAmount?.toLocaleString()}</span>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-2">
                                <User size={16} className="text-blue-500" />
                                Select Delivery Agent
                            </label>
                            <select
                                required
                                value={selectedEmployee}
                                onChange={(e) => setSelectedEmployee(e.target.value)}
                                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-gray-700"
                            >
                                <option value="">Choose an employee...</option>
                                {employees.map(emp => (
                                    <option key={emp.id} value={emp.id}>
                                        {emp.name} ({emp.phone || 'No phone'})
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-2">
                                <Calendar size={16} className="text-blue-500" />
                                Scheduled Date
                            </label>
                            <input
                                type="date"
                                required
                                min={new Date().toISOString().split('T')[0]}
                                value={scheduledDate}
                                onChange={(e) => setScheduledDate(e.target.value)}
                                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-gray-700"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-2">
                                <MapPin size={16} className="text-blue-500" />
                                Route / Sector (Optional)
                            </label>
                            <input
                                type="text"
                                value={routeInfo}
                                onChange={(e) => setRouteInfo(e.target.value)}
                                placeholder="e.g. Sector F-10, Main Street"
                                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-gray-700"
                            />
                        </div>
                    </div>

                    <div className="flex gap-3 pt-2">
                        <button
                            type="button"
                            onClick={onClose}
                            className="flex-1 py-3 px-4 border border-gray-200 text-gray-600 rounded-xl font-bold hover:bg-gray-50 transition-all"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={loading || !selectedEmployee}
                            className="flex-1 py-3 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-bold hover:translate-y-[-1px] shadow-lg shadow-blue-200 hover:shadow-xl transition-all disabled:opacity-50 disabled:transform-none flex items-center justify-center gap-2"
                        >
                            {loading ? <Loader className="animate-spin" size={18} /> : null}
                            Confirm Assignment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AssignOrderModal;