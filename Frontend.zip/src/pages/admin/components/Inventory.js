import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Search, Package, AlertCircle, X, Check } from 'lucide-react';
import { adminService } from '../../../services/adminService';

const Inventory = () => {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [formData, setFormData] = useState({
        name: '', category: 'BOTTLE', price: '', stockQuantity: '', description: '', active: true, imagePath: null
    });
    const [imageFile, setImageFile] = useState(null);
    const [imagePreview, setImagePreview] = useState(null);
    const [editingId, setEditingId] = useState(null);

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            const data = await adminService.getProducts();
            setProducts(data);
        } catch (error) {
            console.error('Error fetching products', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editingId) {
                await adminService.updateProduct(editingId, formData, imageFile);
            } else {
                await adminService.createProduct(formData, imageFile);
            }
            setIsModalOpen(false);
            setEditingId(null);
            setImageFile(null);
            setImagePreview(null);
            setFormData({ name: '', category: 'BOTTLE', price: '', stockQuantity: '', description: '', active: true, imagePath: null });
            fetchProducts();
        } catch (error) {
            console.error('Error saving product', error);
            alert('Failed to save product');
        }
    };

    const handleEdit = (product) => {
        setFormData({
            name: product.name,
            category: product.category,
            price: product.price,
            stockQuantity: product.stockQuantity,
            description: product.description,
            active: product.active,
            imagePath: product.imagePath
        });
        setEditingId(product.id);
        setImageFile(null);
        setImagePreview(null);
        setIsModalOpen(true);
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this product?')) {
            try {
                await adminService.deleteProduct(id);
                fetchProducts();
            } catch (error) {
                console.error('Error deleting product', error);
            }
        }
    };

    const filteredProducts = products.filter(p =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (loading) return <div className="p-8 text-center text-gray-500">Loading inventory...</div>;

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800">Inventory Management</h1>
                    <p className="text-gray-500">Manage products, stock, and pricing</p>
                </div>
                <button
                    onClick={() => {
                        setEditingId(null);
                        setImageFile(null);
                        setImagePreview(null);
                        setFormData({ name: '', category: 'BOTTLE', price: '', stockQuantity: '', description: '', active: true, imagePath: null });
                        setIsModalOpen(true);
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition flex items-center gap-2 shadow-lg shadow-blue-200"
                >
                    <Plus size={18} />
                    Add Product
                </button>
            </div>

            {/* Search and Filter Bar */}
            <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
                <Search className="text-gray-400 w-5 h-5" />
                <input
                    type="text"
                    placeholder="Search products..."
                    className="flex-1 bg-transparent border-none focus:ring-0 text-gray-700 placeholder-gray-400"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="bg-white border border-gray-100 rounded-xl shadow-sm overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">Product</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">Category</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">Price</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">Stock</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">Status</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                        {filteredProducts.map((product) => (
                            <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-lg bg-gray-100 flex-shrink-0 overflow-hidden border border-gray-100">
                                            {product.imagePath ? (
                                                <img src={`http://localhost:8080/uploads/${product.imagePath}`} alt="" className="w-full h-full object-cover" />
                                            ) : (
                                                <div className="w-full h-full flex items-center justify-center text-gray-300">
                                                    <Package size={20} />
                                                </div>
                                            )}
                                        </div>
                                        <div>
                                            <p className="font-semibold text-gray-800">{product.name}</p>
                                            <p className="text-xs text-gray-500 truncate max-w-[200px]">{product.description}</p>
                                        </div>
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-600 text-xs font-medium border border-blue-100">
                                        {product.category}
                                    </span>
                                </td>
                                <td className="px-6 py-4 font-medium text-gray-700">PKR {product.price}</td>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-2">
                                        <Package size={16} className={product.stockQuantity < 10 ? 'text-red-500' : 'text-gray-400'} />
                                        <span className={product.stockQuantity < 10 ? 'text-red-600 font-bold' : 'text-gray-700'}>
                                            {product.stockQuantity}
                                        </span>
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    {product.active ? (
                                        <span className="text-green-600 text-xs font-bold flex items-center gap-1"><Check size={12} /> Active</span>
                                    ) : (
                                        <span className="text-gray-400 text-xs font-bold flex items-center gap-1"><X size={12} /> Inactive</span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <div className="flex items-center justify-end gap-2">
                                        <button onClick={() => handleEdit(product)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"><Edit2 size={16} /></button>
                                        <button onClick={() => handleDelete(product.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"><Trash2 size={16} /></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        {filteredProducts.length === 0 && (
                            <tr>
                                <td colSpan="6" className="p-8 text-center text-gray-500">No products found</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
                    <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
                        <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                            <h3 className="text-lg font-bold text-gray-800">{editingId ? 'Edit Product' : 'Add New Product'}</h3>
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
                        </div>
                        <form onSubmit={handleSubmit} className="p-6 space-y-4">
                            <div className="flex flex-col items-center mb-4">
                                <div className="w-24 h-24 rounded-xl bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden relative group">
                                    {(imagePreview || (formData.imagePath && `http://localhost:8080/uploads/${formData.imagePath}`)) ? (
                                        <img src={imagePreview || `http://localhost:8080/uploads/${formData.imagePath}`} alt="Preview" className="w-full h-full object-cover" />
                                    ) : (
                                        <Package size={32} className="text-gray-300" />
                                    )}
                                    <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                                        <Plus size={24} className="text-white" />
                                        <input type="file" className="hidden" accept="image/*" onChange={e => {
                                            const file = e.target.files[0];
                                            if (file) {
                                                setImageFile(file);
                                                setImagePreview(URL.createObjectURL(file));
                                            }
                                        }} />
                                    </label>
                                </div>
                                <p className="text-xs text-gray-400 mt-2">Product Image (Recommended 1:1)</p>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Product Name</label>
                                <input required className="input-field w-full border p-2 rounded-lg" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                                    <select className="input-field w-full border p-2 rounded-lg" value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value })}>
                                        <option value="BOTTLE">Bottle</option>
                                        <option value="TANKER">Tanker</option>
                                        <option value="DISPENSER">Dispenser</option>
                                        <option value="ACCESSORIES">Accessories</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Stock</label>
                                    <input type="number" required className="input-field w-full border p-2 rounded-lg" value={formData.stockQuantity} onChange={e => setFormData({ ...formData, stockQuantity: parseInt(e.target.value) })} />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Price (PKR)</label>
                                <input type="number" required className="input-field w-full border p-2 rounded-lg" value={formData.price} onChange={e => setFormData({ ...formData, price: parseFloat(e.target.value) })} />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                                <textarea className="input-field w-full border p-2 rounded-lg h-24" value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} />
                            </div>
                            <div className="flex items-center gap-2">
                                <input type="checkbox" id="active" checked={formData.active} onChange={e => setFormData({ ...formData, active: e.target.checked })} />
                                <label htmlFor="active" className="text-sm font-medium text-gray-700">Active Product</label>
                            </div>
                            <div className="pt-4 flex justify-end gap-3">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">Cancel</button>
                                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Save Product</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Inventory;
