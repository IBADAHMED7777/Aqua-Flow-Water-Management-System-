import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Users, Droplets, DollarSign, FileText, CheckCircle, Clock, Calendar, UserCheck, ArrowUpRight, AlertCircle } from 'lucide-react';
import DashboardCard from '../../../components/DashboardCard';

const DashboardHome = ({
    stats,
    revenueData,
    billGenerationStatus,
    handleGenerateBills,
    employees,
    selectedEmployee,
    setSelectedEmployee,
    scheduleDate,
    setScheduleDate,
    scheduleArea,
    setScheduleArea,
    handleAssignSchedule,
    formatCurrency
}) => {

    const complaintStats = stats ? [
        { name: 'Open', value: stats.complaintStats.open, color: '#EF4444' },
        { name: 'In Progress', value: stats.complaintStats.inProgress, color: '#F59E0B' },
        { name: 'Resolved', value: stats.complaintStats.resolved, color: '#22C55E' }
    ] : [];
    const CustomTooltip = ({ active, payload, label }) => {
        if (active && payload && payload.length) {
            return (
                <div className="bg-white p-4 rounded-xl shadow-xl border border-gray-100">
                    <p className="text-gray-500 text-xs font-semibold uppercase">{label}</p>
                    <p className="text-blue-600 font-bold text-lg mt-1">
                        {formatCurrency(payload[0].value)}
                    </p>
                </div>
            );
        }
        return null;
    };

    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            {/* KPI Cards Section */}
            <div>
                <h3 className="text-lg font-bold text-gray-800 mb-4 px-1">Overview</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <DashboardCard
                        title="Total Customers"
                        value={(stats?.totalCustomers || 0).toLocaleString()}
                        icon={<Users size={24} />}
                        trend={{ value: '12.5%', positive: true }}
                        color="blue"
                    />
                    <DashboardCard
                        title="Total Employees"
                        value={stats?.totalEmployees?.toLocaleString() || '0'}
                        icon={<UserCheck size={24} />}
                        color="cyan"
                    />
                    <DashboardCard
                        title="Active Connections"
                        value={(stats?.activeConnections || 0).toLocaleString()}
                        icon={<Droplets size={24} />}
                        trend={{ value: '5.2%', positive: true }}
                        color="green"
                    />
                    <DashboardCard
                        title="Monthly Revenue"
                        value={formatCurrency(stats.monthlyRevenue).replace('PKR', '')}
                        icon={<DollarSign size={24} />}
                        trend={{ value: '8.1%', positive: true }}
                        color="purple"
                    />
                    <DashboardCard
                        title="Pending Complaints"
                        value={complaintStats.find(c => c.name === 'Open')?.value || 0}
                        icon={<AlertCircle size={24} />}
                        trend={{ value: '2 New', positive: true }}
                        color="orange"
                    />
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Revenue Trend */}
                <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                    <div className="flex items-center justify-between mb-6">
                        <div>
                            <h3 className="text-lg font-bold text-gray-800">Revenue Analytics</h3>
                            <p className="text-sm text-gray-500">Income trend over the last 6 months</p>
                        </div>
                        <select className="bg-gray-50 border-none text-sm text-gray-600 font-medium py-2 px-4 rounded-lg focus:ring-0 cursor-pointer hover:bg-gray-100 transition-colors">
                            <option>Last 6 Months</option>
                            <option>Last Year</option>
                        </select>
                    </div>
                    <div className="h-[350px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={revenueData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                                <defs>
                                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#2563EB" stopOpacity={0.3} />
                                        <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F3F4F6" />
                                <XAxis
                                    dataKey="month"
                                    stroke="#9CA3AF"
                                    axisLine={false}
                                    tickLine={false}
                                    tick={{ fontSize: 12 }}
                                    dy={10}
                                />
                                <YAxis
                                    stroke="#9CA3AF"
                                    axisLine={false}
                                    tickLine={false}
                                    tick={{ fontSize: 12 }}
                                    tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
                                />
                                <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#2563EB', strokeWidth: 1, strokeDasharray: '4 4' }} />
                                <Area
                                    type="monotone"
                                    dataKey="revenue"
                                    stroke="#2563EB"
                                    strokeWidth={3}
                                    fillOpacity={1}
                                    fill="url(#colorRevenue)"
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Complaint Analytics */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col">
                    <h3 className="text-lg font-bold text-gray-800 mb-1">Complaint Distribution</h3>
                    <p className="text-sm text-gray-500 mb-8">Breakdown by current status</p>

                    <div className="flex-1 min-h-[250px] relative">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={complaintStats}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={90}
                                    paddingAngle={5}
                                    dataKey="value"
                                    cornerRadius={6}
                                >
                                    {complaintStats.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                                    ))}
                                </Pie>
                                <Tooltip
                                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                                />
                                <Legend verticalAlign="bottom" height={36} iconType="circle" />
                            </PieChart>
                        </ResponsiveContainer>
                        {/* Center Text Overlay */}
                        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none pb-8">
                            <span className="text-3xl font-bold text-gray-800">
                                {complaintStats.reduce((acc, curr) => acc + curr.value, 0)}
                            </span>
                            <span className="text-xs text-gray-400 uppercase font-medium tracking-wide">Total</span>
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Bill Generation */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all duration-300">
                    <div className="flex items-start justify-between mb-6">
                        <div>
                            <h3 className="text-lg font-bold text-gray-800">Bill Generation</h3>
                            <p className="text-sm text-gray-500 mt-1">Automated monthly billing process</p>
                        </div>
                        <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                            <FileText size={20} />
                        </div>
                    </div>

                    <div className="bg-gray-50 rounded-xl p-4 mb-6">
                        <div className="flex justify-between items-center text-sm mb-2">
                            <span className="text-gray-500">Next Cycle</span>
                            <span className="font-semibold text-gray-800">Feb 01, 2025</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full w-[75%]"></div>
                        </div>
                        <div className="text-right mt-1">
                            <span className="text-xs text-blue-600 font-medium">15 days remaining</span>
                        </div>
                    </div>

                    <button
                        onClick={handleGenerateBills}
                        disabled={billGenerationStatus === 'processing'}
                        className={`w-full py-3.5 px-4 rounded-xl font-semibold transition-all transform active:scale-[0.98] flex items-center justify-center space-x-2 ${billGenerationStatus === 'processing'
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : billGenerationStatus === 'completed'
                                ? 'bg-green-600 text-white shadow-lg shadow-green-200 hover:bg-green-700'
                                : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-200 hover:shadow-xl hover:translate-y-[-1px]'
                            }`}
                    >
                        {billGenerationStatus === 'processing' && (
                            <>
                                <Clock className="w-5 h-5 animate-spin" />
                                <span>Processing...</span>
                            </>
                        )}
                        {billGenerationStatus === 'completed' && (
                            <>
                                <CheckCircle className="w-5 h-5" />
                                <span>Generated Successfully</span>
                            </>
                        )}
                        {billGenerationStatus === 'idle' && (
                            <>
                                <FileText className="w-5 h-5" />
                                <span>Run Manual Generation</span>
                            </>
                        )}
                    </button>
                </div>

                {/* Employee Schedule Assignment */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all duration-300">
                    <div className="flex items-start justify-between mb-6">
                        <div>
                            <h3 className="text-lg font-bold text-gray-800">Quick Assign</h3>
                            <p className="text-sm text-gray-500 mt-1">Schedule deliveries for agents</p>
                        </div>
                        <div className="p-3 bg-purple-50 text-purple-600 rounded-xl">
                            <Calendar size={20} />
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div>
                            <select
                                value={selectedEmployee}
                                onChange={(e) => setSelectedEmployee(e.target.value)}
                                className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-purple-500/20 text-gray-700 transition-all font-medium"
                            >
                                <option value="">Select Delivery Agent</option>
                                {employees.map(emp => (
                                    <option key={emp.id} value={emp.id}>
                                        {emp.name} ({emp.status})
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <input
                                type="date"
                                value={scheduleDate}
                                onChange={(e) => setScheduleDate(e.target.value)}
                                className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-purple-500/20 text-gray-700 transition-all font-medium"
                            />
                            <input
                                type="text"
                                value={scheduleArea}
                                onChange={(e) => setScheduleArea(e.target.value)}
                                placeholder="Area / Sector"
                                className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-purple-500/20 text-gray-700 transition-all font-medium"
                            />
                        </div>

                        <button
                            onClick={handleAssignSchedule}
                            className="w-full bg-white border-2 border-purple-100 text-purple-700 py-3.5 px-4 rounded-xl font-bold hover:bg-purple-50 hover:border-purple-200 transition-all transform active:scale-[0.98] flex items-center justify-center space-x-2"
                        >
                            <UserCheck className="w-5 h-5" />
                            <span>Confirm Assignment</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};


export default DashboardHome;
