import React, { useState, useEffect, useCallback } from 'react';
import { CheckCircle, MessageSquare, ArrowRightCircle } from 'lucide-react';
import DataTable from './DataTable';
import { adminService } from '../../../services/adminService';
import StatusModal from '../../../components/StatusModal';

const Complaints = ({ showNotification }) => {
    const [activeTab, setActiveTab] = useState('customer'); // customer | employee
    const [complaints, setComplaints] = useState([]);
    const [page, setPage] = useState(0);
    const [size] = useState(10);
    const [totalPages, setTotalPages] = useState(0);
    const [totalElements, setTotalElements] = useState(0);

    // Modal State
    const [modal, setModal] = useState({
        show: false,
        type: 'success',
        title: '',
        message: '',
        showInput: false,
        inputValue: '',
        onConfirm: null,
        confirmText: 'Confirm'
    });

    const fetchComplaints = useCallback(async () => {
        try {
            let data;
            if (activeTab === 'customer') {
                data = await adminService.fetchCustomerComplaints(page, size);
            } else {
                data = await adminService.fetchEmployeeComplaints(page, size);
            }
            setComplaints(data.content);
            setTotalPages(data.totalPages);
            setTotalElements(data.totalElements);
        } catch (error) {
            showNotification('Failed to fetch complaints', 'error');
        }
    }, [page, size, activeTab, showNotification]);

    useEffect(() => {
        fetchComplaints();
    }, [fetchComplaints]);

    const handleResolveComplaint = async (id) => {
        setModal({
            show: true,
            type: 'confirm',
            title: 'Resolve Complaint?',
            message: 'Are you sure you want to mark this complaint as resolved?',
            showInput: false,
            confirmText: 'Yes, Resolve',
            onConfirm: async () => {
                try {
                    await adminService.resolveComplaint(id, "Resolved by Admin");
                    setModal({
                        show: true,
                        type: 'success',
                        title: 'Resolved',
                        message: 'Complaint resolved successfully!',
                        confirmText: 'Ok'
                    });
                    fetchComplaints();
                } catch (error) {
                    showNotification('Failed to resolve complaint', 'error');
                }
            }
        });
    };

    const handleMarkInProgress = async (id) => {
        try {
            await adminService.markComplaintInProgress(id);
            showNotification('Complaint marked as In Progress!', 'success');
            fetchComplaints();
        } catch (error) {
            showNotification('Failed to mark complaint in progress', 'error');
        }
    };

    const handleSendMessage = (id) => {
        setModal({
            show: true,
            type: 'info',
            title: 'Send Message',
            message: 'Type a message to the employee/customer regarding this issue:',
            showInput: true,
            inputValue: '',
            confirmText: 'Send Message',
            onConfirm: async (message) => {
                if (!message?.trim()) {
                    showNotification('Please enter a message', 'error');
                    return;
                }
                try {
                    await adminService.sendMessageToComplainant(id, message);
                    setModal({
                        show: true,
                        type: 'success',
                        title: 'Sent',
                        message: 'Message sent successfully!',
                        confirmText: 'Great'
                    });
                } catch (error) {
                    showNotification('Failed to send message', 'error');
                }
            }
        });
    };

    const getPriorityColor = (priority) => {
        switch (priority) {
            case 'URGENT': return 'text-red-600 bg-red-50 border-red-100';
            case 'HIGH': return 'text-orange-600 bg-orange-50 border-orange-100';
            default: return 'text-blue-600 bg-blue-50 border-blue-100';
        }
    };

    const columns = [
        {
            header: 'Ticket ID',
            key: 'complaintNo',
            sortable: true,
            render: (item) => (
                <div className="flex flex-col">
                    <span className="font-mono font-medium text-gray-900">{item.complaintNo}</span>
                    <span className="text-[10px] text-gray-400">{item.date}</span>
                </div>
            )
        },
        {
            header: 'Issue',
            key: 'type',
            render: (item) => (
                <div>
                    <div className="text-sm font-medium text-gray-900">{item.type.replace(/_/g, ' ')}</div>
                    <div className="text-xs text-gray-500 max-w-[200px] truncate" title={item.description}>{item.description}</div>
                </div>
            )
        },
        {
            header: 'Customer',
            key: 'customer',
            sortable: true,
            render: (item) => (
                <div>
                    <div className="text-sm text-gray-900">{item.customer}</div>
                    <span className="text-[10px] px-1.5 py-0.5 bg-gray-100 text-gray-500 rounded border border-gray-200">{item.zone}</span>
                </div>
            )
        },
        {
            header: 'Priority',
            key: 'priority',
            sortable: true,
            render: (item) => (
                <span className={`px-2 py-1 rounded text-[10px] font-bold border ${getPriorityColor(item.priority)}`}>
                    {item.priority}
                </span>
            )
        },
        {
            header: 'Status',
            key: 'status',
            sortable: true,
            render: (item) => (
                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${item.status === 'RESOLVED'
                    ? 'bg-green-50 text-green-700 border border-green-100'
                    : item.status === 'IN_PROGRESS'
                        ? 'bg-yellow-50 text-yellow-700 border border-yellow-100'
                        : 'bg-red-50 text-red-700 border border-red-100'
                    }`}>
                    {item.status === 'RESOLVED' && <CheckCircle size={10} />}
                    {item.status}
                </span>
            )
        },
        {
            header: 'Actions',
            key: 'actions',
            render: (item) => (
                <div className="flex justify-end space-x-2">
                    {item.status === 'OPEN' && (
                        <button
                            onClick={() => handleMarkInProgress(item.id)}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-xs font-medium transition shadow-sm hover:shadow flex items-center space-x-1"
                            title="Mark In Progress"
                        >
                            <ArrowRightCircle size={14} />
                            <span>Start</span>
                        </button>
                    )}

                    <button
                        onClick={() => handleSendMessage(item.id)}
                        className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg text-xs font-medium transition shadow-sm hover:shadow flex items-center space-x-1 border border-gray-200"
                        title="Message Customer"
                    >
                        <MessageSquare size={14} />
                    </button>

                    {item.status !== 'RESOLVED' && (
                        <button
                            onClick={() => handleResolveComplaint(item.id)}
                            className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-lg text-xs font-medium transition shadow-sm hover:shadow flex items-center space-x-1"
                            title="Resolve"
                        >
                            <CheckCircle size={14} />
                            <span>Resolve</span>
                        </button>
                    )}
                </div>
            )
        }
    ];

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-gray-800">Complaint Center</h2>
                    <p className="text-sm text-gray-500">Track and resolve customer issues</p>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex space-x-4 border-b border-gray-200">
                <button
                    className={`pb-2 px-4 font-medium transition-colors ${activeTab === 'customer' ? 'border-b-2 border-purple-600 text-purple-600' : 'text-gray-500 hover:text-gray-700'}`}
                    onClick={() => setActiveTab('customer')}
                >
                    Customer Complaints
                </button>
                <button
                    className={`pb-2 px-4 font-medium transition-colors ${activeTab === 'employee' ? 'border-b-2 border-purple-600 text-purple-600' : 'text-gray-500 hover:text-gray-700'}`}
                    onClick={() => setActiveTab('employee')}
                >
                    Employee Complaints
                </button>
            </div>

            <DataTable
                title={activeTab === 'customer' ? 'Customer Complaints' : 'Employee-Assigned Complaints'}
                subtitle={activeTab === 'customer' ? 'Unassigned complaints from customers' : 'Complaints assigned to employees'}
                data={complaints}
                columns={columns}
                searchPlaceholder="Search complaints..."
                hideExport={true}
                pagination={{
                    currentPage: page,
                    totalPages: totalPages,
                    totalItems: totalElements,
                    onPageChange: setPage
                }}
            />

            <StatusModal
                isOpen={modal.show}
                onClose={() => setModal(prev => ({ ...prev, show: false }))}
                type={modal.type}
                title={modal.title}
                message={modal.message}
                showInput={modal.showInput}
                inputValue={modal.inputValue}
                onInputChange={(val) => setModal(prev => ({ ...prev, inputValue: val }))}
                onConfirm={() => modal.onConfirm ? modal.onConfirm(modal.inputValue) : setModal(prev => ({ ...prev, show: false }))}
                confirmText={modal.confirmText}
                showCancel={modal.type === 'confirm' || modal.showInput}
            />
        </div>
    );
};

export default Complaints;