import React, { useState, useEffect, useCallback } from 'react';
import { Eye, MoreVertical } from 'lucide-react';
import DataTable from './DataTable';
import { adminService } from '../../../services/adminService';

const Customers = ({ showNotification }) => {
    const [customers, setCustomers] = useState([]);
    const [page, setPage] = useState(0);
    const [size] = useState(10);
    const [totalPages, setTotalPages] = useState(0);
    const [totalElements, setTotalElements] = useState(0);

    const fetchCustomers = useCallback(async () => {
        try {
            const data = await adminService.fetchUsers(page, size);
            setCustomers(data.content);
            setTotalPages(data.totalPages);
            setTotalElements(data.totalElements);
        } catch (error) {
            showNotification('Failed to fetch customers', 'error');
        }
    }, [page, size, showNotification]);

    useEffect(() => {
        fetchCustomers();
    }, [fetchCustomers]);

    // Define columns for the DataTable
    const columns = [
        {
            header: 'Customer',
            key: 'name',
            sortable: true,
            render: (item) => (
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-100 to-blue-200 rounded-full flex items-center justify-center font-bold text-blue-700 shadow-sm">
                        {item?.name?.charAt(0) || 'U'}
                    </div>
                    <div>
                        <div className="font-semibold text-gray-900">{item?.name || 'Unknown'}</div>
                        <div className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full inline-block mt-0.5">{item?.connection || 'N/A'}</div>
                    </div>
                </div>
            )
        },
        {
            header: 'Contact Info',
            key: 'email',
            render: (item) => (
                <div>
                    <div className="text-sm text-gray-700">{item.email}</div>
                    <div className="text-xs text-gray-500">{item.phone}</div>
                </div>
            )
        },
        {
            header: 'Zone',
            key: 'zone',
            sortable: true,
            render: (item) => (
                <span className="px-3 py-1 bg-purple-50 text-purple-700 rounded-full text-xs font-semibold border border-purple-100">
                    {item?.zone || 'N/A'}
                </span>
            )
        },
        {
            header: 'Status',
            key: 'status',
            sortable: true,
            render: (item) => (
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${(item?.status || 'INACTIVE') === 'ACTIVE'
                    ? 'bg-green-50 text-green-700 border-green-100'
                    : 'bg-red-50 text-red-700 border-red-100'
                    }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${(item?.status || 'INACTIVE') === 'ACTIVE' ? 'bg-green-500' : 'bg-red-500'}`}></span>
                    {item?.status || 'INACTIVE'}
                </span>
            )
        },
        {
            header: 'Due Amount',
            key: 'due',
            sortable: true,
            render: (item) => (
                <span className={`font-bold ${(item?.due || 0) > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    PKR {(item?.due || 0).toLocaleString()}
                </span>
            )
        },
        {
            header: 'Actions',
            key: 'actions',
            render: (item) => (
                <div className="flex items-center justify-end gap-2">
                    <button
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="View Details"
                    >
                        <Eye size={18} />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-lg transition-colors">
                        <MoreVertical size={18} />
                    </button>
                </div>
            )
        }
    ];

    return (
        <DataTable
            title="Customer Management"
            subtitle="Manage customer connections and tracking"
            data={customers}
            columns={columns}
            searchPlaceholder="Search customers..."
            pagination={{
                currentPage: page,
                totalPages: totalPages,
                totalItems: totalElements,
                onPageChange: setPage
            }}
        />
    );
};

export default Customers;
