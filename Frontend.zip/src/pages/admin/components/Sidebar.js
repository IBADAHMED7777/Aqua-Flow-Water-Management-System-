import React from 'react';
import { Users, Droplets, FileText, UserCheck, AlertCircle, ShoppingCart, LogOut, LayoutDashboard, ChevronRight, X } from 'lucide-react';

const Sidebar = ({ isOpen, setIsSidebarOpen, activeTab, setActiveTab }) => {

    const menuGroups = [
        {
            title: 'Management',
            items: [
                { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
                { id: 'orders', label: 'Orders', icon: ShoppingCart },
                { id: 'customers', label: 'Customers', icon: UserCheck },
                { id: 'employees', label: 'Employees', icon: Users },
            ]
        },
        {
            title: 'Finance',
            items: [
                { id: 'billing', label: 'Billing & Invoices', icon: FileText },
            ]
        },
        {
            title: 'Support',
            items: [
                { id: 'complaints', label: 'Complaints', icon: AlertCircle },
            ]
        }
    ];

    return (
        <>
            {/* Mobile Overlay */}
            {isOpen && (
                <div
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
                    onClick={() => setIsSidebarOpen(false)}
                />
            )}

            {/* Sidebar Container */}
            <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-72 bg-slate-900 text-slate-300 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 flex flex-col border-r border-slate-800 shadow-xl`}>

                {/* Logo Section */}
                <div className="p-6 border-b border-slate-800 bg-slate-950/50">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                            <div className="p-2 bg-blue-600/20 rounded-lg">
                                <Droplets className="w-6 h-6 text-blue-500" />
                            </div>
                            <div>
                                <h1 className="text-xl font-bold tracking-tight text-white">Aqua Flow</h1>
                                <p className="text-[10px] uppercase tracking-wider text-blue-500 font-bold">Admin Portal</p>
                            </div>
                        </div>
                        <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden text-slate-400 hover:text-white transition-colors">
                            <X size={24} />
                        </button>
                    </div>
                </div>

                {/* Navigation */}
                <nav className="flex-1 overflow-y-auto py-6 px-4 space-y-8">
                    {menuGroups.map((group, groupIndex) => (
                        <div key={groupIndex}>
                            <h3 className="px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
                                {group.title}
                            </h3>
                            <div className="space-y-1">
                                {group.items.map((item) => {
                                    const Icon = item.icon;
                                    const isActive = activeTab === item.id;

                                    return (
                                        <button
                                            key={item.id}
                                            onClick={() => {
                                                setActiveTab(item.id);
                                                if (window.innerWidth < 1024) setIsSidebarOpen(false);
                                            }}
                                            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden ${isActive
                                                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40'
                                                : 'hover:bg-slate-800 hover:text-white'
                                                }`}
                                        >
                                            <div className="flex items-center gap-3 relative z-10">
                                                <Icon className={`w-5 h-5 transition-colors ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-blue-400'}`} />
                                                <span className="font-medium">{item.label}</span>
                                            </div>
                                            {isActive && (
                                                <ChevronRight className="w-4 h-4 text-blue-200" />
                                            )}
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                    ))}
                </nav>

                {/* User Profile / Logout */}
                <div className="p-4 border-t border-slate-800 bg-slate-950/30">
                    <button className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-slate-800 transition-colors group text-left">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center text-sm font-bold text-white shadow-lg ring-2 ring-slate-800 group-hover:ring-slate-700 transition-all">
                            AD
                        </div>
                        <div className="flex-1 overflow-hidden">
                            <p className="font-semibold text-sm text-white truncate">Admin User</p>
                            <p className="text-xs text-slate-500 truncate group-hover:text-slate-400 transition-colors">admin@aquaflow.pk</p>
                        </div>
                        <LogOut className="w-5 h-5 text-slate-500 group-hover:text-red-400 transition-colors" />
                    </button>
                </div>
            </aside>
        </>
    );
};

export default Sidebar;
