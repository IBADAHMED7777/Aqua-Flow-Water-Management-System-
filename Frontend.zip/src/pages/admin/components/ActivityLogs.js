import React, { useState, useEffect } from 'react';
import { Clock, Shield, User, FileText, Settings } from 'lucide-react';
import DataTable from './DataTable';
import { adminService } from '../../../services/adminService';

const ActivityLogs = () => {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLogs = async () => {
            try {
                const data = await adminService.fetchActivityLogs();
                // Map backend structure if needed
                // Backend returns List<AdminActivityLog>: { id, admin: {name, role}, action, entityType, entityId, details, ipAddress, timestamp }
                // Frontend columns expects: { action, user, role, ip, date, status }
                // I need to map it.

                const mappedLogs = data.map(log => ({
                    id: log.id,
                    action: log.action,
                    user: log.admin?.name || 'System',
                    role: log.admin?.role || 'SYSTEM',
                    ip: log.ipAddress,
                    date: new Date(log.timestamp).toLocaleString(),
                    status: 'SUCCESS', // Backend doesn't store status unless I add it. For now assume success.
                    details: log.details
                }));
                setLogs(mappedLogs);
            } catch (error) {
                console.error("Failed to fetch logs", error);
            } finally {
                setLoading(false);
            }
        };

        fetchLogs();
    }, []);

    const getActionIcon = (action) => {
        if (action.includes('Login')) return <User size={14} />;
        if (action.includes('System')) return <Settings size={14} />;
        if (action.includes('Bill')) return <FileText size={14} />;
        if (action.includes('Security')) return <Shield size={14} />;
        return <Clock size={14} />;
    };

    const columns = [
        {
            header: 'Action',
            key: 'action',
            sortable: true,
            render: (item) => (
                <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-gray-100 rounded-md text-gray-500">
                        {getActionIcon(item.action)}
                    </div>
                    <div>
                        <span className="font-medium text-gray-700 block">{item.action}</span>
                        <span className="text-xs text-gray-400">{item.details}</span>
                    </div>
                </div>
            )
        },
        {
            header: 'User',
            key: 'user',
            sortable: true,
            render: (item) => (
                <div>
                    <div className="text-sm font-medium text-gray-900">{item.user}</div>
                    <div className="text-[10px] text-gray-500">{item.role}</div>
                </div>
            )
        },
        {
            header: 'IP Address',
            key: 'ip',
            render: (item) => <span className="font-mono text-xs text-gray-500">{item.ip}</span>
        },
        {
            header: 'Timestamp',
            key: 'date',
            sortable: true,
            render: (item) => <span className="text-sm text-gray-600">{item.date}</span>
        },
        {
            header: 'Status',
            key: 'status',
            sortable: true,
            render: (item) => (
                <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${item.status === 'SUCCESS' ? 'bg-green-50 text-green-700 border-green-100' :
                    item.status === 'FAILED' ? 'bg-red-50 text-red-700 border-red-100' :
                        'bg-yellow-50 text-yellow-700 border-yellow-100'
                    }`}>
                    {item.status}
                </span>
            )
        }
    ];

    if (loading) {
        return <div className="p-8 text-center text-gray-500">Loading logs...</div>;
    }

    return (
        <DataTable
            title="System Activity Logs"
            subtitle="Monitor user actions and system events"
            data={logs}
            columns={columns}
            searchPlaceholder="Search logs..."
        />
    );
};

export default ActivityLogs;
