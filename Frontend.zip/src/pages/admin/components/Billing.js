import React, { useState, useEffect } from 'react';
import { Plus, Download, Search, CheckCircle, AlertCircle } from 'lucide-react';
import { adminService } from '../../../services/adminService';
import StatusModal from '../../../components/StatusModal';

const Billing = ({ handleGenerateBills }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [statusFilter, setStatusFilter] = useState('ALL');
    const [bills, setBills] = useState([]); // For invoices tab: orders
    const [page] = useState(0);
    const [size] = useState(50);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('invoices'); // invoices | salaries

    // Salary State
    const [employees, setEmployees] = useState([]);
    const [salaryStats, setSalaryStats] = useState({});
    const [selectedEmployeeForSalary, setSelectedEmployeeForSalary] = useState(null);
    const [unpaidEarnings, setUnpaidEarnings] = useState([]);
    const [processingSalary, setProcessingSalary] = useState(false);

    // Modal State
    const [modal, setModal] = useState({
        show: false,
        type: 'success',
        title: '',
        message: '',
        onConfirm: null
    });

    useEffect(() => {
        if (activeTab === 'invoices') {
            fetchBills();
        } else {
            fetchEmployees();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, activeTab]);

    const fetchEmployees = async () => {
        try {
            setLoading(true);
            const data = await adminService.fetchEmployees(0, 100);
            setEmployees(data.content);
        } catch (error) {
            console.error("Failed to fetch employees", error);
        } finally {
            setLoading(false);
        }
    };

    const handleSelectEmployee = async (empId) => {
        try {
            setLoading(true);
            const earnings = await adminService.getUnpaidEarnings(empId);
            setUnpaidEarnings(earnings);
            setSelectedEmployeeForSalary(empId);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handlePaySalary = async () => {
        if (!selectedEmployeeForSalary || unpaidEarnings.length === 0) return;

        try {
            setProcessingSalary(true);
            // Pay all displayed unpaid earnings
            const earningIds = unpaidEarnings.map(e => e.id);
            await adminService.paySalary({
                employeeId: selectedEmployeeForSalary,
                earningIds: earningIds
            });

            setModal({
                show: true,
                type: 'success',
                title: 'Salary Paid',
                message: 'Salary assigned successfully! Slip has been generated.',
                onConfirm: () => setModal(prev => ({ ...prev, show: false }))
            });

            // Refresh
            handleSelectEmployee(selectedEmployeeForSalary);
        } catch (error) {
            setModal({
                show: true,
                type: 'error',
                title: 'Payment Failed',
                message: 'Internal server error occurred while processing salary payment.',
                onConfirm: () => setModal(prev => ({ ...prev, show: false }))
            });
        } finally {
            setProcessingSalary(false);
        }
    };

    const fetchBills = async () => {
        try {
            setLoading(true);
            // Fetch orders for the invoices tab
            const data = await adminService.fetchOrders(page, size);
            setBills(data.content);
        } catch (error) {
            console.error("Failed to fetch orders", error);
        } finally {
            setLoading(false);
        }
    };

    const displayBills = bills;

    const filteredBills = displayBills.filter(order => {
        const customerName = order.user?.name || '';
        const orderId = order.id?.toString() || '';

        return (statusFilter === 'ALL' || order.status === statusFilter) &&
            (orderId.includes(searchQuery.toLowerCase()) ||
                customerName.toLowerCase().includes(searchQuery.toLowerCase()));
    });

    if (loading) {
        return <div className="p-8 text-center text-gray-500">Loading bills...</div>;
    }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-gray-800">Billing & Salaries</h2>
                    <p className="text-sm text-gray-500">Manage invoices and employee payroll</p>
                </div>
                {activeTab === 'invoices' && (
                    <div className="flex gap-3">
                        <button
                            onClick={handleGenerateBills}
                            className="bg-purple-600 text-white px-6 py-2.5 rounded-lg hover:bg-purple-700 flex items-center gap-2 transition-all shadow-lg shadow-purple-200 transform active:scale-95"
                        >
                            <Plus size={18} />
                            Generate Monthly Bills
                        </button>
                    </div>
                )}
            </div>

            {/* Tabs */}
            <div className="flex space-x-4 border-b border-gray-200">
                <button
                    className={`pb-2 px-4 font-medium transition-colors ${activeTab === 'invoices' ? 'border-b-2 border-purple-600 text-purple-600' : 'text-gray-500 hover:text-gray-700'}`}
                    onClick={() => setActiveTab('invoices')}
                >
                    Client Invoices
                </button>
                <button
                    className={`pb-2 px-4 font-medium transition-colors ${activeTab === 'salaries' ? 'border-b-2 border-purple-600 text-purple-600' : 'text-gray-500 hover:text-gray-700'}`}
                    onClick={() => setActiveTab('salaries')}
                >
                    Employee Salaries
                </button>
            </div>

            {activeTab === 'invoices' ? (
                <>
                    <div className="bg-white rounded-xl shadow-md p-4 border border-gray-100">
                        {/* Search and Filters */}
                        <div className="flex flex-col md:flex-row gap-4">
                            <div className="flex-1 relative">
                                <Search className="absolute left-3 top-3 text-gray-400" size={20} />
                                <input
                                    type="text"
                                    placeholder="Search orders..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500"
                                />
                            </div>
                            <div className="flex gap-2">
                                <select
                                    value={statusFilter}
                                    onChange={(e) => setStatusFilter(e.target.value)}
                                    className="px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500"
                                >
                                    <option value="ALL">All Status</option>
                                    <option value="PLACED">Placed</option>
                                    <option value="DELIVERED">Delivered</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead className="bg-gray-50 border-b border-gray-100">
                                    <tr>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Order ID</th>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Customer</th>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Date</th>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Amount</th>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Status</th>
                                        <th className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {displayBills.map(order => (
                                        <tr key={order.id} className="hover:bg-purple-50/50">
                                            <td className="px-6 py-4 font-medium">#{order.id}</td>
                                            <td className="px-6 py-4">
                                                <div>
                                                    <div className="font-medium">{order.user?.name || 'N/A'}</div>
                                                    <div className="text-xs text-gray-500">{order.user?.phone || ''}</div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-gray-600">
                                                {order.placedAt ? new Date(order.placedAt).toLocaleDateString() : 'N/A'}
                                            </td>
                                            <td className="px-6 py-4 font-bold">PKR {order.totalAmount?.toLocaleString() || 0}</td>
                                            <td className="px-6 py-4">
                                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${order.status === 'DELIVERED'
                                                    ? 'bg-green-100 text-green-700'
                                                    : order.status === 'PLACED'
                                                        ? 'bg-yellow-100 text-yellow-700'
                                                        : 'bg-blue-100 text-blue-700'
                                                    }`}>
                                                    {order.status}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <button
                                                    onClick={async () => {
                                                        try {
                                                            const response = await adminService.fetchOrderInvoicePdf(order.id);
                                                            const url = window.URL.createObjectURL(new Blob([response]));
                                                            const link = document.createElement('a');
                                                            link.href = url;
                                                            link.setAttribute('download', `invoice_${order.id}.pdf`);
                                                            document.body.appendChild(link);
                                                            link.click();
                                                            link.remove();
                                                        } catch (error) {
                                                            console.error("PDF Download failed", error);
                                                            alert("Failed to download invoice PDF");
                                                        }
                                                    }}
                                                    className="text-purple-600 hover:text-purple-800 text-sm font-medium"
                                                >
                                                    Invoice PDF
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </>
            ) : (
                <div className="flex gap-6">
                    {/* Employee List */}
                    <div className="w-1/3 bg-white rounded-xl shadow-md border border-gray-100 p-4">
                        <h3 className="font-bold text-lg mb-4">Employees</h3>
                        <div className="space-y-2">
                            {employees.map(emp => (
                                <div
                                    key={emp.id}
                                    onClick={() => handleSelectEmployee(emp.id)}
                                    className={`p-3 rounded-lg cursor-pointer flex justify-between items-center transition-colors ${selectedEmployeeForSalary === emp.id ? 'bg-purple-50 border-purple-200 border' : 'hover:bg-gray-50 border border-transparent'}`}
                                >
                                    <div>
                                        <div className="font-medium">{emp.name}</div>
                                        <div className="text-xs text-gray-500">{emp.email}</div>
                                    </div>
                                    <div className="text-xs bg-gray-100 px-2 py-1 rounded">Rate: {emp.paymentRate}</div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Salary Details */}
                    <div className="flex-1 bg-white rounded-xl shadow-md border border-gray-100 p-6">
                        {selectedEmployeeForSalary ? (
                            <>
                                <h3 className="font-bold text-lg mb-4">Unpaid Earnings</h3>
                                {unpaidEarnings.length > 0 ? (
                                    <>
                                        <div className="space-y-2 mb-6 max-h-60 overflow-y-auto">
                                            {unpaidEarnings.map(earning => (
                                                <div key={earning.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                                    <div>
                                                        <div className="text-sm font-medium">Delivery #{earning.deliverySchedule?.id}</div>
                                                        <div className="text-xs text-gray-500">{new Date(earning.earnedAt).toLocaleDateString()}</div>
                                                    </div>
                                                    <div className="font-bold text-green-600">PKR {earning.earningAmount}</div>
                                                </div>
                                            ))}
                                        </div>

                                        <div className="flex justify-between items-center pt-4 border-t border-gray-200">
                                            <div>
                                                <p className="text-sm text-gray-500">Total Payable</p>
                                                <p className="text-2xl font-bold">PKR {unpaidEarnings.reduce((sum, e) => sum + e.earningAmount, 0)}</p>
                                            </div>
                                            <button
                                                onClick={handlePaySalary}
                                                disabled={processingSalary}
                                                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 font-bold shadow-lg shadow-green-200 transition-all active:scale-95 disabled:opacity-50"
                                            >
                                                {processingSalary ? 'Processing...' : 'Pay Salary & Generate Slip'}
                                            </button>
                                        </div>
                                    </>
                                ) : (
                                    <div className="text-center py-10 text-gray-500">No unpaid earnings found for this employee.</div>
                                )}
                            </>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-full text-gray-400">
                                <Search size={48} className="mb-2 opacity-20" />
                                <p>Select an employee to view earnings</p>
                            </div>
                        )}
                    </div>
                </div>
            )}

            <StatusModal
                isOpen={modal.show}
                onClose={() => setModal(prev => ({ ...prev, show: false }))}
                type={modal.type}
                title={modal.title}
                message={modal.message}
                onConfirm={modal.onConfirm || (() => setModal(prev => ({ ...prev, show: false })))}
            />
        </div>
    );
};

export default Billing;