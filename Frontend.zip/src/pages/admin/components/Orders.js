import React, { useState, useEffect, useCallback } from 'react';
import { CheckCircle, XCircle, Truck, Clock } from 'lucide-react';
import DataTable from './DataTable';
import { adminService } from '../../../services/adminService';
import AssignOrderModal from './AssignOrderModal';
import StatusModal from '../../../components/StatusModal';

const Orders = ({ showNotification }) => {
    const [orders, setOrders] = useState([]);
    const [employees, setEmployees] = useState([]);
    const [page, setPage] = useState(0);
    const [size] = useState(10);
    const [totalPages, setTotalPages] = useState(0);
    const [totalElements, setTotalElements] = useState(0);
    const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
    const [orderToAssign, setOrderToAssign] = useState(null);

    // Modal State
    const [modal, setModal] = useState({
        show: false,
        type: 'success',
        title: '',
        message: ''
    });

    const fetchOrders = useCallback(async () => {
        try {
            const data = await adminService.fetchOrders(page, size);
            setOrders(data.content);
            setTotalPages(data.totalPages);
            setTotalElements(data.totalElements);
        } catch (error) {
            showNotification('Failed to fetch orders', 'error');
        }
    }, [page, size, showNotification]);

    const fetchEmployees = useCallback(async () => {
        try {
            const data = await adminService.fetchEmployees(0, 100);
            setEmployees(data.content);
        } catch (error) {
            console.error('Failed to fetch employees');
        }
    }, []);

    useEffect(() => {
        fetchOrders();
        fetchEmployees();
    }, [fetchOrders, fetchEmployees]);

    const handleAssign = (order) => {
        setOrderToAssign(order);
        setIsAssignModalOpen(true);
    };

    const handleAssignSubmit = async (assignmentData) => {
        try {
            await adminService.assignSchedule(assignmentData);
            setModal({
                show: true,
                type: 'success',
                title: 'Assigned Successfully',
                message: 'The delivery schedule has been assigned to the employee.'
            });
            fetchOrders();
        } catch (error) {
            showNotification('Failed to assign order', 'error');
            throw error;
        }
    };

    const handleUpdateOrderStatus = async (id, status) => {
        try {
            await adminService.updateOrderStatus(id, status);
            showNotification(`Order status updated to ${status}`, 'success');
            fetchOrders();
        } catch (error) {
            showNotification('Failed to update status', 'error');
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'DELIVERED': return 'bg-green-50 text-green-700 border-green-100';
            case 'CANCELLED': return 'bg-red-50 text-red-700 border-red-100';
            case 'OUT_FOR_DELIVERY': return 'bg-blue-50 text-blue-700 border-blue-100';
            case 'CONFIRMED': return 'bg-purple-50 text-purple-700 border-purple-100';
            default: return 'bg-yellow-50 text-yellow-700 border-yellow-100';
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'DELIVERED': return <CheckCircle size={14} className="mr-1.5" />;
            case 'CANCELLED': return <XCircle size={14} className="mr-1.5" />;
            case 'OUT_FOR_DELIVERY': return <Truck size={14} className="mr-1.5" />;
            case 'CONFIRMED': return <CheckCircle size={14} className="mr-1.5" />;
            default: return <Clock size={14} className="mr-1.5" />;
        }
    };

    const columns = [
        {
            header: 'Order ID',
            key: 'id',
            sortable: true,
            render: (item) => <span className="font-mono text-gray-900 font-medium">#{item.id}</span>
        },
        {
            header: 'Customer',
            key: 'user',
            sortable: true,
            render: (item) => (
                <div>
                    <div className="text-sm font-medium text-gray-900">{item.user?.name || 'Unknown'}</div>
                    <div className="text-xs text-gray-500">{item.user?.phone || 'No phone'}</div>
                </div>
            )
        },
        {
            header: 'Date',
            key: 'placedAt',
            sortable: true,
            render: (item) => <span className="text-gray-600">{item.placedAt ? new Date(item.placedAt).toLocaleDateString() : 'N/A'}</span>
        },
        {
            header: 'Total',
            key: 'totalAmount',
            sortable: true,
            render: (item) => <span className="font-bold text-gray-800">PKR {(item.totalAmount || 0).toLocaleString()}</span>
        },
        {
            header: 'Payment',
            key: 'paymentMethod',
            sortable: true,
            render: (item) => (
                <span className="text-xs font-semibold text-gray-600 bg-gray-100 px-2 py-1 rounded">
                    {(item.paymentMethod || 'COD').replace(/_/g, ' ')}
                </span>
            )
        },
        {
            header: 'Status',
            key: 'status',
            sortable: true,
            render: (item) => (
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(item.status)}`}>
                    {getStatusIcon(item.status)}
                    {(item.status || 'PENDING').replace(/_/g, ' ')}
                </span>
            )
        },
        {
            header: 'Actions',
            key: 'actions',
            render: (item) => (
                <div className="flex justify-end gap-2">
                    {item.status === 'PLACED' && (
                        <>
                            <button
                                onClick={() => handleAssign(item)}
                                className="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-xs font-medium transition shadow-sm hover:shadow"
                            >
                                Assign
                            </button>
                            <button
                                onClick={() => handleUpdateOrderStatus(item.id, 'CANCELLED')}
                                className="px-3 py-1 bg-white border border-red-200 text-red-600 rounded-lg hover:bg-red-50 text-xs font-medium transition"
                            >
                                Cancel
                            </button>
                        </>
                    )}
                    {/* Admin cannot Ship or Deliver anymore */}
                </div>
            )
        }
    ];

    return (
        <>
            <DataTable
                title="Order Management"
                subtitle="Track and manage water delivery orders"
                data={orders}
                columns={columns}
                searchPlaceholder="Search by Order ID or Customer..."
                pagination={{
                    currentPage: page,
                    totalPages: totalPages,
                    totalItems: totalElements,
                    onPageChange: setPage
                }}
            />

            {orderToAssign && (
                <AssignOrderModal
                    isOpen={isAssignModalOpen}
                    onClose={() => {
                        setIsAssignModalOpen(false);
                        setOrderToAssign(null);
                    }}
                    order={orderToAssign}
                    employees={employees}
                    onAssign={handleAssignSubmit}
                />
            )}

            <StatusModal
                isOpen={modal.show}
                onClose={() => setModal(prev => ({ ...prev, show: false }))}
                type={modal.type}
                title={modal.title}
                message={modal.message}
                confirmText="Ok"
            />
        </>
    );
};

export default Orders;