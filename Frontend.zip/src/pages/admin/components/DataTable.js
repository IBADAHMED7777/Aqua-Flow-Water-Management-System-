import React, { useState, useMemo } from 'react';
import { Search, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, Filter, Download } from 'lucide-react';

const DataTable = ({
    columns,
    data,
    title,
    subtitle,
    actions,
    searchPlaceholder = "Search...",
    pagination,
    hideExport = false
}) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 7;

    const handleSort = (key) => {
        let direction = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const filteredData = useMemo(() => {
        if (pagination) return data; // Server-side filtering assumed
        return data.filter(item =>
            Object.values(item).some(value =>
                String(value).toLowerCase().includes(searchQuery.toLowerCase())
            )
        );
    }, [data, searchQuery, pagination]);

    const sortedData = useMemo(() => {
        if (pagination) return filteredData; // Server-side sorting assumed
        let sortableItems = [...filteredData];
        if (sortConfig.key !== null) {
            sortableItems.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) {
                    return sortConfig.direction === 'asc' ? -1 : 1;
                }
                if (a[sortConfig.key] > b[sortConfig.key]) {
                    return sortConfig.direction === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [filteredData, sortConfig, pagination]);

    const isServerSide = !!pagination;
    const totalPagesCount = isServerSide ? pagination.totalPages : Math.ceil(sortedData.length / itemsPerPage);
    const displayData = isServerSide ? data : sortedData.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );

    const handlePageChange = (newPage) => {
        if (isServerSide) {
            pagination.onPageChange(newPage - 1); // 0-indexed for server
        } else {
            setCurrentPage(newPage);
        }
    };

    const currentDisplayPage = isServerSide ? pagination.currentPage + 1 : currentPage;

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-xl font-bold text-gray-800 tracking-tight">{title}</h2>
                    {subtitle && <p className="text-sm text-gray-500 mt-0.5">{subtitle}</p>}
                </div>
                {actions}
            </div>

            {/* Controls */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-1.5 flex flex-col md:flex-row gap-2">
                <div className="flex-1 relative group">
                    <Search className="absolute left-3.5 top-3 text-gray-400 group-focus-within:text-blue-500 transition-colors" size={20} />
                    <input
                        type="text"
                        placeholder={searchPlaceholder}
                        value={searchQuery}
                        onChange={(e) => {
                            setSearchQuery(e.target.value);
                            if (isServerSide && pagination.onSearch) pagination.onSearch(e.target.value);
                        }}
                        className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border border-transparent rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-200 transition-all text-sm"
                    />
                </div>
                <div className="flex gap-2">
                    <button className="px-4 py-2.5 bg-gray-50 hover:bg-white hover:shadow-md border border-gray-100 rounded-xl flex items-center gap-2 text-gray-600 transition-all text-sm font-medium">
                        <Filter size={18} />
                        Filter
                    </button>
                    {!hideExport && (
                        <button className="px-4 py-2.5 bg-gray-50 hover:bg-white hover:shadow-md border border-gray-100 rounded-xl flex items-center gap-2 text-gray-600 transition-all text-sm font-medium">
                            <Download size={18} />
                            Export
                        </button>
                    )}
                </div>
            </div>

            {/* Table */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-50/50 border-b border-gray-100">
                            <tr>
                                {columns.map((column, index) => (
                                    <th
                                        key={index}
                                        onClick={() => {
                                            if (column.sortable) {
                                                handleSort(column.key);
                                                if (isServerSide && pagination.onSort) pagination.onSort(column.key);
                                            }
                                        }}
                                        className={`px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider ${column.sortable ? 'cursor-pointer hover:bg-gray-100 hover:text-gray-700 transition-colors select-none' : ''}`}
                                    >
                                        <div className="flex items-center gap-2">
                                            {column.header}
                                            {column.sortable && (
                                                <div className="flex flex-col">
                                                    <ChevronUp size={8} className={sortConfig.key === column.key && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'} />
                                                    <ChevronDown size={8} className={sortConfig.key === column.key && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'} />
                                                </div>
                                            )}
                                        </div>
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                            {displayData.length > 0 ? (
                                displayData.map((item, rowIndex) => (
                                    <tr key={rowIndex} className="hover:bg-blue-50/30 transition-colors group">
                                        {columns.map((column, colIndex) => (
                                            <td key={colIndex} className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                                {column.render ? column.render(item) : item[column.key]}
                                            </td>
                                        ))}
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={columns.length} className="px-6 py-12 text-center">
                                        <div className="flex flex-col items-center justify-center text-gray-400">
                                            <Filter size={32} className="mb-3 opacity-20" />
                                            <p className="text-sm font-medium">No results found matching your search</p>
                                        </div>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Pagination */}
                <div className="px-6 py-4 bg-gray-50/50 border-t border-gray-100 flex items-center justify-between">
                    <p className="text-sm text-gray-500">
                        Showing <span className="font-medium text-gray-800">{isServerSide ? (pagination.currentPage * itemsPerPage + 1) : ((currentPage - 1) * itemsPerPage + 1)}</span> to <span className="font-medium text-gray-800">{isServerSide ? (pagination.currentPage * itemsPerPage + displayData.length) : Math.min(currentPage * itemsPerPage, sortedData.length)}</span> of <span className="font-medium text-gray-800">{isServerSide ? pagination.totalItems : sortedData.length}</span> results
                    </p>
                    <div className="flex gap-2">
                        <button
                            onClick={() => handlePageChange(currentDisplayPage - 1)}
                            disabled={currentDisplayPage === 1}
                            className="p-2 rounded-lg hover:bg-white hover:shadow-sm border border-transparent hover:border-gray-200 text-gray-500 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                        >
                            <ChevronLeft size={18} />
                        </button>
                        <button
                            onClick={() => handlePageChange(currentDisplayPage + 1)}
                            disabled={currentDisplayPage === totalPagesCount || totalPagesCount === 0}
                            className="p-2 rounded-lg hover:bg-white hover:shadow-sm border border-transparent hover:border-gray-200 text-gray-500 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                        >
                            <ChevronRight size={18} />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DataTable;
