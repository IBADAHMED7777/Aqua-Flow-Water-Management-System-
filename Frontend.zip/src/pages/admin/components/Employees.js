import React, { useState, useEffect, useCallback } from 'react';
import { Edit, Plus, Trash2 } from 'lucide-react';
import DataTable from './DataTable';
import { adminService } from '../../../services/adminService';
import AddEmployeeModal from './AddEmployeeModal';
import EditEmployeeModal from './EditEmployeeModal';

const Employees = ({ showNotification }) => {
    const [employees, setEmployees] = useState([]);
    const [page, setPage] = useState(0);
    const [size] = useState(10);
    const [totalPages, setTotalPages] = useState(0);
    const [totalElements, setTotalElements] = useState(0);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [selectedEmployee, setSelectedEmployee] = useState(null);

    const fetchEmployees = useCallback(async () => {
        try {
            const data = await adminService.fetchEmployees(page, size);
            setEmployees(data.content);
            setTotalPages(data.totalPages);
            setTotalElements(data.totalElements);
        } catch (error) {
            showNotification('Failed to fetch employees', 'error');
        }
    }, [page, size, showNotification]);

    useEffect(() => {
        fetchEmployees();
    }, [fetchEmployees]);

    const handleAddSuccess = (message, type = 'success') => {
        showNotification(message, type);
        fetchEmployees(); // Refresh the list
    };

    const handleEdit = (employee) => {
        setSelectedEmployee(employee);
        setIsEditModalOpen(true);
    };

    const handleDelete = async (employeeId) => {
        if (!window.confirm('Are you sure you want to deactivate this employee?')) {
            return;
        }

        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`http://localhost:8080/api/admin/employees/${employeeId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                showNotification('Employee deactivated successfully', 'success');
                fetchEmployees();
            } else {
                showNotification('Failed to deactivate employee', 'error');
            }
        } catch (error) {
            showNotification('Failed to deactivate employee', 'error');
        }
    };

    // Add Employee Button
    const actions = (
        <button
            onClick={() => setIsAddModalOpen(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2 transition-all shadow-lg shadow-blue-200 text-sm font-medium transform active:scale-95"
        >
            <Plus size={16} />
            Add Employee
        </button>
    );

    const columns = [
        {
            header: 'Employee',
            key: 'name',
            sortable: true,
            render: (item) => (
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center font-bold text-slate-600 border border-slate-200">
                        {item?.name?.charAt(0) || 'E'}
                    </div>
                    <div>
                        <div className="font-semibold text-gray-900">{item?.name || 'Unknown'}</div>
                        <div className="text-xs text-gray-500">{item?.email || 'N/A'}</div>
                    </div>
                </div>
            )
        },
        {
            header: 'Role',
            key: 'role',
            sortable: true,
            render: (item) => (
                <span className="px-2.5 py-1 bg-gray-100 text-gray-700 rounded-lg text-xs font-medium border border-gray-200">
                    {item?.role || 'EMPLOYEE'}
                </span>
            )
        },
        {
            header: 'Status',
            key: 'status',
            sortable: true,
            render: (item) => (
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${(item?.status || 'Available') === 'Available'
                    ? 'bg-green-50 text-green-700 border border-green-100'
                    : 'bg-yellow-50 text-yellow-700 border border-yellow-100'
                    }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${(item?.status || 'Available') === 'Available' ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
                    {item?.status || 'Available'}
                </span>
            )
        },
        {
            header: 'Phone',
            key: 'phone',
            render: (item) => <span className="text-gray-600 font-mono text-xs">{item?.phone || 'N/A'}</span>
        },
        {
            header: 'Actions',
            key: 'actions',
            render: (item) => (
                <div className="flex items-center justify-end gap-2">
                    <button
                        onClick={() => handleEdit(item)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit Employee"
                    >
                        <Edit size={16} />
                    </button>
                    <button
                        onClick={() => handleDelete(item.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete Employee"
                    >
                        <Trash2 size={16} />
                    </button>
                </div>
            )
        }
    ];

    return (
        <>
            <AddEmployeeModal
                isOpen={isAddModalOpen}
                onClose={() => setIsAddModalOpen(false)}
                onSuccess={handleAddSuccess}
            />

            <EditEmployeeModal
                isOpen={isEditModalOpen}
                onClose={() => {
                    setIsEditModalOpen(false);
                    setSelectedEmployee(null);
                }}
                onSuccess={handleAddSuccess}
                employee={selectedEmployee}
            />

            <DataTable
                title="Employee Directory"
                subtitle="Manage delivery agents and support staff"
                data={employees}
                columns={columns}
                actions={actions}
                searchPlaceholder="Search employees..."
                pagination={{
                    currentPage: page,
                    totalPages: totalPages,
                    totalItems: totalElements,
                    onPageChange: setPage
                }}
            />
        </>
    );
};

export default Employees;
