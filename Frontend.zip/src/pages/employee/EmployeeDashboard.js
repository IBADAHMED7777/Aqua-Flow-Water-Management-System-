
import React, { useState, useEffect } from 'react';
import Sidebar from '../../components/Sidebar';
import Header from '../../components/Header';
import DashboardCard from '../../components/DashboardCard';
import { employeeService } from '../../services/employeeService';
import MySchedules from './components/MySchedules';

import ReportIssue from './components/ReportIssue';
import Salaries from './components/Salaries';
import StatusModal from '../../components/StatusModal';
import confetti from 'canvas-confetti';
import { Loader, Truck, AlertCircle, Package, CheckCircle, Banknote, Wallet, FileText } from 'lucide-react';

const EmployeeDashboard = () => {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('dashboard');
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [salaryNotification, setSalaryNotification] = useState(null);

    useEffect(() => {
        fetchDashboardData();
        checkSalaryNotifications();
    }, []);

    const fetchDashboardData = async () => {
        try {
            const data = await employeeService.getDashboardStats();
            setStats(data);
        } catch (error) {
            console.error('Error fetching dashboard stats:', error);
        } finally {
            setLoading(false);
        }
    };

    const checkSalaryNotifications = async () => {
        try {
            const notifications = await employeeService.getUnreadNotifications();
            const salaryNotify = notifications.find(n => n.type === 'SALARY');

            if (salaryNotify) {
                setSalaryNotification(salaryNotify);

                // Play sound cue
                const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3');
                audio.play().catch(e => console.log('Audio play failed', e));

                // Confetti Effect
                confetti({
                    particleCount: 150,
                    spread: 70,
                    origin: { y: 0.6 }
                });
            }
        } catch (error) {
            console.error('Error checking notifications:', error);
        }
    };

    const handleCloseSalaryModal = async () => {
        if (salaryNotification) {
            try {
                await employeeService.markNotificationAsRead(salaryNotification.id);
            } catch (error) {
                console.error('Error marking notification as read:', error);
            }
        }
        setSalaryNotification(null);
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center space-y-4">
                <Loader className="w-12 h-12 text-blue-600 animate-spin" />
                <p className="text-gray-500 font-medium">Loading Dashboard...</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 flex font-sans">
            <Sidebar
                role="EMPLOYEE"
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                isOpen={isSidebarOpen}
                setIsSidebarOpen={setIsSidebarOpen}
            />

            <div className="flex-1 flex flex-col transition-all duration-300 min-w-0 h-screen overflow-hidden">
                <Header
                    isSidebarOpen={isSidebarOpen}
                    setIsSidebarOpen={setIsSidebarOpen}
                    activeTab={activeTab}
                />

                <main className="flex-1 overflow-y-auto p-4 md:p-8 max-w-[1920px] mx-auto w-full">
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                        {activeTab === 'dashboard' && (
                            <>
                                <div className="mb-8">
                                    <h1 className="text-2xl font-bold text-gray-800">Welcome Back</h1>
                                    <p className="text-gray-500">Here's what's happening today.</p>
                                </div>

                                {stats && (
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                                        <DashboardCard
                                            title="Pending Deliveries"
                                            value={stats.pendingSchedules}
                                            icon={<Package size={24} />}
                                            color="blue"
                                        />
                                        <DashboardCard
                                            title="Completed Today"
                                            value={stats.completedToday}
                                            icon={<CheckCircle size={24} />}
                                            color="green"
                                        />
                                        <DashboardCard
                                            title="Daily Earnings"
                                            value={`PKR ${stats.dailyEarnings?.toFixed(2) || '0.00'} `}
                                            icon={<Banknote size={24} />}
                                            color="purple"
                                        />
                                        <DashboardCard
                                            title="Monthly Earnings"
                                            value={`PKR ${stats.monthlyEarnings?.toFixed(2) || '0.00'} `}
                                            icon={<Wallet size={24} />}
                                            color="orange"
                                        />
                                    </div>
                                )}

                                <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                                    <h3 className="text-lg font-bold text-gray-800 mb-4">Quick Actions</h3>
                                    <div className="flex gap-4">
                                        <button
                                            className="px-6 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition font-medium shadow-lg shadow-blue-200 flex items-center gap-2"
                                            onClick={() => setActiveTab('schedules')}
                                        >
                                            <Truck size={18} />
                                            View Assignments
                                        </button>
                                        <button
                                            className="px-6 py-2.5 bg-white text-gray-700 border border-gray-200 rounded-xl hover:bg-gray-50 transition font-medium flex items-center gap-2"
                                            onClick={() => setActiveTab('issues')}
                                        >
                                            <AlertCircle size={18} />
                                            Report an Issue
                                        </button>
                                    </div>
                                </div>

                                <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mt-6">
                                    <h3 className="text-lg font-bold text-gray-800 mb-4">Salary & Docs</h3>
                                    <button
                                        className="px-6 py-2.5 bg-white text-gray-700 border border-gray-200 rounded-xl hover:bg-gray-50 transition font-medium flex items-center gap-2 w-full md:w-auto"
                                        onClick={() => setActiveTab('salaries')}
                                    >
                                        <FileText size={18} />
                                        View Salary Slips
                                    </button>
                                </div>
                            </>
                        )}


                        {activeTab === 'schedules' && <MySchedules />}
                        {activeTab === 'issues' && <ReportIssue />}
                        {activeTab === 'salaries' && <Salaries />}
                    </div>
                </main>
            </div >

            <StatusModal
                isOpen={!!salaryNotification}
                onClose={handleCloseSalaryModal}
                title="Congratulations!"
                message="congratulations the admin appreciates the your hard work. Your salary slip has been generated!"
                type="success"
                confirmText="Thank You!"
            />
        </div >
    );
};

export default EmployeeDashboard;

