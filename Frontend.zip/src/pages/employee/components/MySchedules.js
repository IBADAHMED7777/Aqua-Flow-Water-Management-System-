import React, { useState, useEffect } from 'react';
import { employeeService } from '../../../services/employeeService';
import { CheckCircle } from 'lucide-react';

const MySchedules = () => {
    const [schedules, setSchedules] = useState([]);
    const [loading, setLoading] = useState(true);
    const [completingId, setCompletingId] = useState(null);
    const [reading, setReading] = useState('');

    useEffect(() => {
        loadSchedules();
    }, []);

    const loadSchedules = async () => {
        try {
            const data = await employeeService.getMySchedules();
            setSchedules(data);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handleStart = async (id) => {
        try {
            await employeeService.startDelivery(id);
            loadSchedules();
        } catch (error) {
            alert('Failed to start delivery');
        }
    };

    const handleComplete = async (id) => {
        setCompletingId(id);
    };

    const submitCompletion = async () => {
        try {
            if (reading) {
                await employeeService.submitMeterReading(completingId, parseFloat(reading));
            }
            await employeeService.completeDelivery(completingId);
            setCompletingId(null);
            setReading('');
            loadSchedules();
        } catch (error) {
            alert('Failed to complete delivery');
        }
    }

    return (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2">
                My Schedules
            </h3>
            {schedules.length === 0 ? (
                <p className="text-center py-12 text-gray-400">No schedules assigned.</p>
            ) : (
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead>
                            <tr className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-gray-100">
                                <th className="pb-3 pl-2">Date</th>
                                <th className="pb-3">Route</th>
                                <th className="pb-3">Customer</th>
                                <th className="pb-3">Payment</th>
                                <th className="pb-3">Status</th>
                                <th className="pb-3 text-right pr-2">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                            {schedules.map(schedule => (
                                <tr key={schedule.id} className="text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                    <td className="py-4 pl-2 font-medium">{schedule.scheduledDate}</td>
                                    <td className="py-4">{schedule.routeInformation || 'N/A'}</td>
                                    <td className="py-4 font-medium text-gray-900">{schedule.order?.user?.name || 'Unknown'}</td>
                                    <td className="py-4 text-xs font-semibold text-gray-600">
                                        {schedule.order?.paymentMethod || 'COD'}
                                    </td>
                                    <td className="py-4">
                                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${schedule.status === 'COMPLETED' ? 'bg-green-100 text-green-700' :
                                            schedule.status === 'IN_PROGRESS' ? 'bg-yellow-100 text-yellow-700' :
                                                'bg-blue-100 text-blue-700'
                                            }`}>
                                            {schedule.status}
                                        </span>
                                    </td>
                                    <td className="py-4 text-right pr-2">
                                        {schedule.status === 'PENDING' && (
                                            <button
                                                className="px-3 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700 transition shadow-sm"
                                                onClick={() => handleStart(schedule.id)}
                                            >
                                                Start
                                            </button>
                                        )}
                                        {schedule.status === 'IN_PROGRESS' && (
                                            <button
                                                className="px-3 py-1.5 bg-green-600 text-white text-xs font-bold rounded-lg hover:bg-green-700 transition shadow-sm"
                                                onClick={() => handleComplete(schedule.id)}
                                            >
                                                Complete
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {completingId && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-200">
                    <div className="bg-white p-6 rounded-2xl shadow-xl w-96 border border-gray-100 transform scale-100 transition-all text-center">
                        <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                            <CheckCircle size={32} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">Delivery Successful</h3>
                        <p className="text-gray-500 mb-6">Order has been marked as delivered.</p>

                        <div className="flex gap-3">
                            <button
                                className="flex-1 px-4 py-2.5 bg-green-600 text-white font-bold rounded-xl hover:bg-green-700 shadow-lg shadow-green-200 transition-all"
                                onClick={submitCompletion}
                            >
                                Done
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default MySchedules;
