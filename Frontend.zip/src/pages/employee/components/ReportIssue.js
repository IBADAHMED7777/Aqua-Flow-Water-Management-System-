import React, { useState, useEffect } from 'react';
import { employeeService } from '../../../services/employeeService';
import { AlertCircle, MapPin, Clock, CheckCircle } from 'lucide-react';
import StatusModal from '../../../components/StatusModal';

const ReportIssue = () => {
    const [formData, setFormData] = useState({
        type: 'LEAKAGE',
        description: '',
        location: ''
    });
    const [submitting, setSubmitting] = useState(false);
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);

    // Modal State
    const [modal, setModal] = useState({
        show: false,
        type: 'success',
        title: '',
        message: ''
    });

    useEffect(() => {
        fetchHistory();
    }, []);

    const fetchHistory = async () => {
        try {
            const data = await employeeService.getMyComplaints();
            setHistory(data || []);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            await employeeService.reportIssue(formData.type, formData.description, formData.location);
            setModal({
                show: true,
                type: 'success',
                title: 'Report Sent!',
                message: 'Your report has been submitted successfully. The admin will review it shortly.'
            });
            setFormData({ type: 'LEAKAGE', description: '', location: '' });
            fetchHistory();
        } catch (error) {
            setModal({
                show: true,
                type: 'error',
                title: 'Submission Failed',
                message: 'There was an error sending your report. Please try again later.'
            });
        } finally {
            setSubmitting(false);
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'RESOLVED': return 'bg-green-100 text-green-700';
            case 'IN_PROGRESS': return 'bg-yellow-100 text-yellow-700';
            default: return 'bg-red-100 text-red-700';
        }
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <AlertCircle className="text-red-500" />
                    Report Field Issue
                </h3>
                <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Issue Type</label>
                        <select
                            className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all bg-gray-50 hover:bg-white"
                            value={formData.type}
                            onChange={e => setFormData({ ...formData, type: e.target.value })}
                        >
                            <option value="LEAKAGE">Pipe Leakage</option>
                            <option value="WATER_SHORTAGE">Supply Interruption</option>
                            <option value="QUALITY_ISSUE">Water Quality</option>
                            <option value="OTHER">Other</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Location / Address</label>
                        <div className="relative">
                            <MapPin className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                            <input
                                required
                                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                                value={formData.location}
                                onChange={e => setFormData({ ...formData, location: e.target.value })}
                                placeholder="Street, Area, or Landmark"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Description</label>
                        <textarea
                            required
                            className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all min-h-[120px]"
                            value={formData.description}
                            onChange={e => setFormData({ ...formData, description: e.target.value })}
                            placeholder="Describe the issue in detail..."
                        />
                    </div>

                    <div className="pt-2">
                        <button
                            type="submit"
                            disabled={submitting}
                            className="w-full px-6 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-200 transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                        >
                            {submitting ? 'Submitting...' : 'Submit Report'}
                        </button>
                    </div>
                </form>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex flex-col max-h-[600px]">
                <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <Clock className="text-blue-500" />
                    Report History
                </h3>

                <div className="flex-1 overflow-y-auto pr-2 space-y-4">
                    {loading ? (
                        <p className="text-center text-gray-500 py-10">Loading history...</p>
                    ) : history.length === 0 ? (
                        <div className="text-center py-10 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                            <p className="text-gray-400">No issues reported yet.</p>
                        </div>
                    ) : (
                        history.map(item => (
                            <div key={item.id} className="p-4 rounded-xl bg-gray-50 border border-gray-100 hover:border-blue-200 transition-colors">
                                <div className="flex justify-between items-start mb-2">
                                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">#{item.complaintNo || item.id}</span>
                                    <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase ${getStatusColor(item.status)}`}>
                                        {item.status}
                                    </span>
                                </div>
                                <h4 className="font-bold text-gray-800 text-sm mb-1">{item.type.replace('_', ' ')}</h4>
                                <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                                <p className="text-xs text-gray-400">
                                    {new Date(item.createdAt).toLocaleString()}
                                </p>

                                {item.resolutionNotes && (
                                    <div className="mt-3 pt-3 border-t border-gray-200/50">
                                        <p className="text-xs font-bold text-gray-500 mb-1 flex items-center gap-1">
                                            <CheckCircle className="w-3 h-3 text-green-500" />
                                            Admin Reply
                                        </p>
                                        <p className="text-sm text-gray-700 bg-white p-2 rounded-lg border border-gray-100 italic">
                                            "{item.resolutionNotes}"
                                        </p>
                                    </div>
                                )}
                            </div>
                        ))
                    )}
                </div>
            </div>

            <StatusModal
                isOpen={modal.show}
                onClose={() => setModal(prev => ({ ...prev, show: false }))}
                type={modal.type}
                title={modal.title}
                message={modal.message}
                confirmText="Ok"
            />
        </div>
    );
};

export default ReportIssue;
