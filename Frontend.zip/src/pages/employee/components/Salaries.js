import React, { useState, useEffect } from 'react';
import { employeeService } from '../../../services/employeeService'; // Updated import
import { Loader, Download, FileText, Calendar } from 'lucide-react';

const Salaries = () => {
    const [payments, setPayments] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchSalaries = async () => {
            try {
                // Use employeeService instead of direct api call
                const data = await employeeService.getMySalaries();
                setPayments(data || []);
            } catch (error) {
                console.error("Failed to fetch salaries", error);
            } finally {
                setLoading(false);
            }
        };
        fetchSalaries();
    }, []);

    const handleDownload = async (id, periodStart) => {
        try {
            const blob = await employeeService.downloadSalarySlip(id);
            const url = window.URL.createObjectURL(new Blob([blob]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `salary_slip_${periodStart}.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            console.error("Download failed", error);
            alert("Failed to download salary slip");
        }
    };

    if (loading) return (
        <div className="flex items-center justify-center p-12">
            <Loader className="w-8 h-8 text-blue-600 animate-spin" />
        </div>
    );

    return (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2">
                <FileText className="text-purple-600" />
                Salary History (Payslips)
            </h3>

            {payments.length === 0 ? (
                <div className="text-center py-10 text-gray-500 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                    <FileText className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                    No salary records found yet.
                </div>
            ) : (
                <div className="space-y-3">
                    {payments.map(payment => (
                        <div key={payment.id} className="p-5 bg-gray-50 rounded-2xl hover:bg-purple-50/50 transition border border-gray-100 group">
                            <div className="flex flex-col md:flex-row justify-between gap-4">
                                <div className="flex gap-4 items-start">
                                    <div className="w-12 h-12 rounded-2xl bg-purple-100 flex items-center justify-center text-purple-600 font-bold shrink-0">
                                        {new Date(payment.periodStart).toLocaleString('default', { month: 'short' })}
                                    </div>
                                    <div className="space-y-1">
                                        <p className="font-bold text-gray-800 text-base">Salary Disbursement</p>
                                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-500">
                                            <div className="flex items-center gap-1">
                                                <Calendar className="w-3.5 h-3.5 text-purple-500" />
                                                <span>{payment.periodStart} to {payment.periodEnd}</span>
                                            </div>
                                            <div className="flex items-center gap-1">
                                                <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                                                <span className="capitalize">{payment.paymentMethod?.toLowerCase().replace('_', ' ') || 'Direct Deposit'}</span>
                                            </div>
                                        </div>
                                        <p className="text-[11px] text-gray-400">Transaction Date: {new Date(payment.paymentDate).toLocaleDateString()}</p>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 border-t md:border-t-0 md:border-l border-gray-200 pt-4 md:pt-0 md:pl-8">
                                    <div className="text-right md:text-left">
                                        <p className="text-[10px] uppercase tracking-wider font-bold text-gray-400 mb-0.5">Earnings</p>
                                        <p className="text-sm font-bold text-gray-700">PKR {(payment.basicSalary + (payment.allowances || 0)).toLocaleString()}</p>
                                    </div>
                                    <div className="text-right md:text-left">
                                        <p className="text-[10px] uppercase tracking-wider font-bold text-gray-400 mb-0.5">Deductions</p>
                                        <p className="text-sm font-bold text-red-600">PKR {payment.deductions?.toLocaleString() || '0'}</p>
                                    </div>
                                    <div className="col-span-2 md:col-span-1 flex flex-col items-end justify-center">
                                        <p className="text-[10px] uppercase tracking-wider font-bold text-purple-500 mb-0.5">Net Paid</p>
                                        <p className="font-black text-gray-900 text-xl leading-none mb-2">PKR {payment.amount?.toLocaleString()}</p>
                                        <button
                                            onClick={() => handleDownload(payment.id, payment.periodStart)}
                                            className="text-xs text-purple-600 font-bold hover:text-purple-700 flex items-center gap-1 transition-colors bg-purple-100/50 px-3 py-1 rounded-full"
                                        >
                                            <Download size={13} /> PDF Slip
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default Salaries;
