import React, { useState, useEffect } from 'react';
import { employeeService } from '../../../services/employeeService';

const MyEarnings = () => {
    const [earnings, setEarnings] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const load = async () => {
            try {
                const data = await employeeService.getMyEarnings();
                setEarnings(data || []);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        load();
    }, []);

    if (loading) return <div>Loading earnings...</div>;

    return (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-gray-800 mb-6">Earnings History</h3>
            <div className="overflow-x-auto">
                <table className="w-full">
                    <thead>
                        <tr className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-gray-100">
                            <th className="pb-3 pl-2">Date</th>
                            <th className="pb-3">Delivery Ref</th>
                            <th className="pb-3">Amount</th>
                            <th className="pb-3">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                        {earnings.map(e => (
                            <tr key={e.id} className="text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                <td className="py-4 pl-2 font-medium">{new Date(e.earnedAt).toLocaleDateString()}</td>
                                <td className="py-4 text-gray-500">Schedule #{e.deliverySchedule?.id}</td>
                                <td className="py-4 font-bold text-gray-900">PKR {e.earningAmount}</td>
                                <td className="py-4">
                                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${e.paid ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                        {e.paid ? 'PAID' : 'UNPAID'}
                                    </span>
                                </td>
                            </tr>
                        ))}
                        {earnings.length === 0 && (
                            <tr><td colSpan="4" className="text-center py-12 text-gray-400">No earnings found.</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default MyEarnings;
