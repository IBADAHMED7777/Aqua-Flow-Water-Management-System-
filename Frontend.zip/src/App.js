import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminDashboard from './pages/admin/AdminDashboard';
import EmployeeDashboard from './pages/employee/EmployeeDashboard';
import UserDashboard from './pages/user/UserDashboard';
import { authService } from './services/authService';

import WaterEffect from './components/WaterEffect';
import ErrorBoundary from './components/ErrorBoundary';

function App() {
    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        if (params.get('fresh') === 'true') {
            authService.logout();
            // Remove the param from URL without refreshing to avoid infinite loop
            // or just redirect to clean login
            window.location.href = '/login';
        }
    }, []);

    const user = authService.getCurrentUser();

    return (
        <ErrorBoundary>
            <Router>
                <WaterEffect />
                <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />

                    {/* Admin Routes */}
                    <Route
                        path="/admin/dashboard"
                        element={
                            <ProtectedRoute allowedRole="ADMIN">
                                <AdminDashboard />
                            </ProtectedRoute>
                        }
                    />

                    {/* Employee Routes */}
                    <Route
                        path="/employee/dashboard"
                        element={
                            <ProtectedRoute allowedRole="EMPLOYEE">
                                <EmployeeDashboard />
                            </ProtectedRoute>
                        }
                    />

                    {/* User Routes */}
                    <Route
                        path="/user/dashboard"
                        element={
                            <ProtectedRoute allowedRole="USER">
                                <UserDashboard />
                            </ProtectedRoute>
                        }
                    />

                    {/* Default redirect */}
                    <Route
                        path="/"
                        element={
                            user ? (
                                <Navigate
                                    to={
                                        user.role === 'ADMIN'
                                            ? '/admin/dashboard'
                                            : user.role === 'EMPLOYEE'
                                                ? '/employee/dashboard'
                                                : '/user/dashboard'
                                    }
                                    replace
                                />
                            ) : (
                                <Navigate to="/login" replace />
                            )
                        }
                    />
                </Routes>
            </Router>
        </ErrorBoundary>
    );
}

export default App;
